/*
---------------------------------------------------- CH Control Box LCD ---------------------------------------------------------
Display extension for the Waveshare ESP32-S3-LCD-1.3 (ST7789 240x240)
Author: mameise (display extension), based on CH Control Box by jogger86 & mameise
License: Same as the CH Control Box: free to use, modify and distribute, as long as the original developers are mentioned.

The display runs in its own FreeRTOS task on core 0 with low priority.
The control logic in loop() (core 1) is not slowed down by the display:
loop() only copies a small status struct (lcd_publish) and picks up settings changes (lcd_take_setting).
---------------------------------------------------------------------------------------------------------------------------------
*/
#pragma once

#include <LovyanGFX.hpp>
#ifndef LCDUI_HOST
#include <Preferences.h>
#endif
#include "lcd_fonts.h"

#define LCD_UI_VERSION "LCD 1.1.2"

#ifndef lcd_battery_display
#define lcd_battery_display 1//1=Battery symbol in the status bar and warning when low
#endif
#ifndef battery_low_sleep
#define battery_low_sleep 1//1=Deep sleep when the battery is empty
#endif

//------------------------------------------------------------------------------------------------------------------------------------
// Board pins Waveshare ESP32-S3-LCD-1.3 (fixed on the board, do not change)
//------------------------------------------------------------------------------------------------------------------------------------
#define LCD_PIN_SCLK 40
#define LCD_PIN_MOSI 41
#define LCD_PIN_CS   39
#define LCD_PIN_DC   38
#define LCD_PIN_RST  42
#define LCD_PIN_BL   20

//------------------------------------------------------------------------------------------------------------------------------------
// Data exchange between loop() and display task
//------------------------------------------------------------------------------------------------------------------------------------
struct LcdChannel
{
  bool active=false;        //Channel calibrated/used
  bool signal=false;        //PWM pulses arriving right now
  long raw=0;               //Measured pulse in microseconds
  long pre=0;               //Prescaled value (-1000..1000 analog, 0..n digital)
  long steps=0;             //0=analog, >0 number of discrete steps
  long cal_min=0, cal_max=0, neu_min=0, neu_max=0;
  bool toggle_btn=false;    //Discrete channel reacts on edges only
  long expo=0;              //Expo factor -1000..1000
};

struct LcdTele
{
  uint32_t ms=0;
  bool bt_connected=false;
  bool rx_seen=false;
  LcdChannel ch[4];
  int cal_step_ext=0;       //0=no calibration, 1..6 calibration step
  int cal_presses=0;        //Short presses counted in step 6
  bool cal_btn=false;       //CAL button pressed right now (BOOT or external)
  bool btn_boot=false;      //BOOT button pressed
  bool btn_cal=false;       //External CAL button pressed
  bool btn_cal_inverted=false; //External CAL button was closed at start and is inverted
  uint32_t cal_hold_ms=0;   //How long the CAL button is held
  bool turbo=false;         //Turbo sent to the app
  bool reverse_pulse=false; //Reverse button press sent to the app
  bool reverse_hold=false;  //Old reverse (brake+throttle) active
  bool c_launch=false, c_light=false, c_motor=false, c_menu=false, c_turbo=false, c_reverse=false;
  int use_combos=2;
  int combo_speed=0;        //-1 slow, 0 medium, 1 fast
  bool combined_tr=false;   //Turbo/Reverse on one 3-position switch
  uint32_t sleep_left_ms=0; //Time until deep sleep, 0=not counting
  uint32_t activity_ms=0;   //Last time something changed on the inputs
};

enum LcdSettingId { LCD_SET_NONE=0, LCD_SET_COMBOS=1, LCD_SET_SPEED=2, LCD_SET_EXPO_STEER=3, LCD_SET_EXPO_THROTTLE=4 };

#ifndef LCDUI_HOST
//------------------------------------------------------------------------------------------------------------------------------------
// LovyanGFX device for the board
//------------------------------------------------------------------------------------------------------------------------------------
class LGFX_WS13 : public lgfx::LGFX_Device
{
  lgfx::Panel_ST7789 _panel;
  lgfx::Bus_SPI _bus;
  lgfx::Light_PWM _light;
public:
  LGFX_WS13(void)
  {
    {
      auto cfg=_bus.config();
      cfg.spi_host=SPI2_HOST;
      cfg.spi_mode=0;
      cfg.freq_write=40000000;
      cfg.freq_read=16000000;
      cfg.spi_3wire=true;
      cfg.use_lock=true;
      cfg.dma_channel=SPI_DMA_CH_AUTO;
      cfg.pin_sclk=LCD_PIN_SCLK;
      cfg.pin_mosi=LCD_PIN_MOSI;
      cfg.pin_miso=-1;
      cfg.pin_dc=LCD_PIN_DC;
      _bus.config(cfg);
      _panel.setBus(&_bus);
    }
    {
      auto cfg=_panel.config();
      cfg.pin_cs=LCD_PIN_CS;
      cfg.pin_rst=LCD_PIN_RST;
      cfg.pin_busy=-1;
      cfg.memory_width=240;
      cfg.memory_height=320;
      cfg.panel_width=240;
      cfg.panel_height=240;
      cfg.offset_x=0;
      cfg.offset_y=0;
      cfg.offset_rotation=0;
      cfg.readable=false;
      cfg.invert=true;
      cfg.rgb_order=false;
      cfg.dlen_16bit=false;
      cfg.bus_shared=false;
      _panel.config(cfg);
    }
    {
      auto cfg=_light.config();
      cfg.pin_bl=LCD_PIN_BL;
      cfg.invert=false;
      cfg.freq=12000;
      cfg.pwm_channel=7;
      _light.config(cfg);
      _panel.setLight(&_light);
    }
    setPanel(&_panel);
  }
};
#endif

//------------------------------------------------------------------------------------------------------------------------------------
// Texts (German / English). Short on purpose.
//------------------------------------------------------------------------------------------------------------------------------------
enum LcdTxt {
  T_BT_ON, T_BT_OFF, T_RX_NONE, T_RX_HINT, T_GAS, T_BRAKE, T_CENTER,
  T_CHIP_TURBO, T_CHIP_REV, T_CHIP_LIGHT, T_CHIP_MOTOR, T_CHIP_LAUNCH, T_CHIP_MENU,
  T_CHANNELS, T_CH_STEER, T_CH_THROTTLE, T_CH_TURBO, T_CH_REVERSE, T_NOSIG, T_TOGGLE,
  T_INFO, T_I_NAME, T_I_FW, T_I_COMBOS, T_I_SPEED, T_I_EXPO, T_I_BAT, T_I_UPTIME, T_I_SWITCH, T_NOBAT, T_OK_HINT,
  T_SETTINGS, T_M_BRIGHT, T_M_OFF, T_M_ROT, T_M_MIRROR, T_M_LANG, T_M_COMBOS, T_M_SPEED, T_M_EXPO_S, T_M_EXPO_T, T_M_BACK,
  T_NEVER, T_OFF, T_ON, T_LANG,
  T_CMB_ALL, T_CMB_NOTURBO, T_CMB_SOME, T_CMB_LIGHT,
  T_SPD_SLOW, T_SPD_MED, T_SPD_FAST,
  T_EXPO_OFF, T_EXPO_SOFT, T_EXPO_PROG,
  T_CAL, T_STEP,
  T_CAL1_T, T_CAL1, T_CAL2_T, T_CAL2, T_CAL3_T, T_CAL3, T_CAL4_T, T_CAL4, T_CAL5_T, T_CAL5, T_CAL6_T, T_CAL6,
  T_CAL_PRESSES, T_CAL_RESET,
  T_HOLD_CAL, T_HOLD_SAVE, T_SAVED, T_FACTORY,
  T_SLEEP_IN, T_SLEEP, T_SLEEP_HINT, T_BLOCKED,
  T_BAT_LOW, T_BAT_EMPTY, T_BAT_CHARGE,
  T_I_BUTTONS, T_B_NEXT,
  T_COUNT
};

static const char* const LCD_TXT_DE[T_COUNT] = {
  "Verbunden", "Suche Handy", "Kein Empfänger", "Empfänger an Pin 1 bis 4", "Gas", "Bremse", "Mitte",
  "Turbo", "Rückw.", "Licht", "Motor", "Launch", "Menü",
  "Kanäle", "Lenkung", "Gas/Bremse", "Turbo", "Rückwärts", "kein Signal", "Umschalter",
  "Info", "Name", "Firmware", "Kombos", "Kombo-Tempo", "Expo L / G", "Akku", "Laufzeit", "Turbo/Rückw.", "kein Akku", "OK: Einstellungen",
  "Einstellungen", "Helligkeit", "Display aus", "Drehen", "Spiegeln (Prisma)", "Sprache", "Kombos", "Kombo-Tempo", "Expo Lenkung", "Expo Gas", "Zurück",
  "nie", "aus", "an", "Deutsch",
  "Alle", "Ohne Turbo", "Turbo, Launch, Licht", "Nur Licht",
  "Langsam", "Mittel", "Schnell",
  "Aus", "Weich", "Progressiv",
  "Kalibrierung", "Schritt",
  "Endanschläge", "Alle Hebel bis zum Anschlag bewegen und alle Schalter umlegen. Dann CAL kurz drücken.",
  "Mittelstellung", "Hebel loslassen, Sender leicht schütteln. Taste 4x drücken = Umschalter. Dann CAL kurz.",
  "Totzone Anschlag", "Optional Hebel leicht auslenken. Sonst einfach CAL kurz.",
  "Totzone Mitte", "Optional Hebel leicht auslenken. Sonst einfach CAL kurz.",
  "Richtung", "Voll Gas und voll rechts lenken, dann loslassen. Dann CAL kurz.",
  "Testen", "Alles ausprobieren. CAL lang halten speichert.",
  "CAL kurz gedrückt", "20x = Werkseinstellungen",
  "Kalibrierung startet", "Speichern", "Gespeichert", "Werkseinstellungen",
  "Schlafmodus in", "Schlafmodus", "Zum Aufwecken Reset drücken", "Nicht während der Kalibrierung",
  "Akku fast leer", "Akku leer", "Bitte aufladen",
  "Tasten", "Weiter"
};

static const char* const LCD_TXT_EN[T_COUNT] = {
  "Connected", "Pairing", "No receiver", "Receiver to pin 1 to 4", "Throttle", "Brake", "Center",
  "Turbo", "Reverse", "Light", "Motor", "Launch", "Menu",
  "Channels", "Steering", "Throttle", "Turbo", "Reverse", "no signal", "Toggle",
  "Info", "Name", "Firmware", "Combos", "Combo speed", "Expo S / T", "Battery", "Uptime", "Turbo/Rev.", "no battery", "OK: settings",
  "Settings", "Brightness", "Screen off", "Rotate", "Mirror (prism)", "Language", "Combos", "Combo speed", "Expo steering", "Expo throttle", "Back",
  "never", "off", "on", "English",
  "All", "No turbo", "Turbo, launch, light", "Light only",
  "Slow", "Medium", "Fast",
  "Off", "Soft", "Progressive",
  "Calibration", "Step",
  "End stops", "Move all sticks to the end stops and flip all switches. Then press CAL short.",
  "Center", "Release sticks, shake the remote a little. Press a button 4x to make it a toggle. Then CAL short.",
  "End stop deadzone", "Optional: move sticks slightly. Otherwise just CAL short.",
  "Center deadzone", "Optional: move sticks slightly. Otherwise just CAL short.",
  "Direction", "Full throttle and full right, then release. Then CAL short.",
  "Test", "Try everything. Hold CAL long to save.",
  "CAL short presses", "20x = factory reset",
  "Calibration starts", "Saving", "Saved", "Factory reset",
  "Sleep in", "Sleep mode", "Press reset to wake up", "Not during calibration",
  "Battery low", "Battery empty", "Please charge",
  "Buttons", "Next"
};

//------------------------------------------------------------------------------------------------------------------------------------
// Internal state of the display module
//------------------------------------------------------------------------------------------------------------------------------------
namespace lcdui
{
#ifndef LCDUI_HOST
  static LGFX_WS13 lcd;
  static LGFX_Sprite spr(&lcd);
#else
  struct HostLcd { void setBrightness(int){} void setRotation(int){} void sleep(){} void wakeup(){} };
  static HostLcd lcd;
  static LGFX_Sprite spr;
#endif
  static bool ready=false;

  static lgfx::PointerWrapper wrapS, wrapM, wrapL, wrapXL;
  static lgfx::VLWfont fontS, fontM, fontL, fontXL;

  static portMUX_TYPE mux=portMUX_INITIALIZER_UNLOCKED;
  static LcdTele shared;         //Written by loop(), read by display task
  static LcdTele t;              //Local copy of the display task
  static volatile int pending_id=LCD_SET_NONE;
  static volatile long pending_val=0;
  static volatile bool sleep_request=false;
  static volatile bool sleep_done=false;

  static char bt_name[40]="CH Control Box";
  static char fw_name[40]="";
  static int pins[4]={0,0,0,0};
  static int pin_next=-1, pin_ok=-1, pin_cal=-1;

  //Settings of the display (stored in Preferences "lcd")
  static int set_bright=3;   //0..4 -> 20..100%
  static int set_off=0;      //0=never, 1=1min, 2=5min
  static int set_rot=0;      //0..3
  static int set_mirror=0;   //0/1
  static int set_lang=0;     //0=DE, 1=EN

  static int page=0;         //0=drive, 1=channels, 2=info
  static bool menu_open=false;
  static int menu_item=0;
  static uint32_t menu_last_ms=0;
  static bool screen_on=true;
  static uint32_t last_wake_ms=0;
  static uint32_t last_activity_seen=0;
  static int last_cal_step=0;
  static int last_cal_presses=0;
  static uint32_t toast_until=0;
  static int toast_txt=-1;
  static uint32_t reverse_flash_until=0;
  static uint32_t blocked_until=0;
  //Battery (measured in the display task)
  static int battery_mv=0;              //Smoothed battery voltage in mV
  static int battery_pct=-1;            //Shown charge in percent, -1 = no battery found
  static uint32_t battery_ms=0;
  static int bat_win_min=100000, bat_win_max=0;
  static uint32_t bat_win_start=0;
  static bool bat_unstable=true;        //Value jumps (no battery, only USB): hide the symbol
  static bool bat_seen_ok=false;        //A charged battery was seen since start (needed for the empty detection)
  static bool bat_low_warned=false;
  static uint32_t bat_empty_since=0;
  static volatile bool battery_empty=false;
  static volatile bool sleep_empty=false;

  //Colors (RGB565)
  static const uint16_t C_BG     = lgfx::color565(0x0B,0x0E,0x14);
  static const uint16_t C_PANEL  = lgfx::color565(0x18,0x1E,0x2A);
  static const uint16_t C_PANEL2 = lgfx::color565(0x24,0x2C,0x3C);
  static const uint16_t C_TEXT   = lgfx::color565(0xEC,0xEF,0xF4);
  static const uint16_t C_DIM    = lgfx::color565(0x80,0x8A,0x9C);
  static const uint16_t C_ACCENT = lgfx::color565(0x2E,0xC4,0xF1);
  static const uint16_t C_GREEN  = lgfx::color565(0x3D,0xDC,0x84);
  static const uint16_t C_RED    = lgfx::color565(0xFF,0x4D,0x5E);
  static const uint16_t C_AMBER  = lgfx::color565(0xFF,0xB0,0x20);
  static const uint16_t C_VIOLET = lgfx::color565(0xA7,0x8B,0xFA);
  static const uint16_t C_YELLOW = lgfx::color565(0xFF,0xE0,0x66);
  static const uint16_t C_BLACK  = lgfx::color565(0,0,0);

  static inline const char* tx(int id) { return set_lang==1 ? LCD_TXT_EN[id] : LCD_TXT_DE[id]; }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Buttons (optional, wired from GPIO to GND)
  //----------------------------------------------------------------------------------------------------------------------------------
  struct Btn
  {
    int pin=-1; bool state=false; bool last_raw=false; uint32_t change_ms=0; uint32_t down_ms=0; bool long_fired=false;
    bool ev_short=false; bool ev_long=false;
    void begin(int p) { pin=p; if(pin>=0) pinMode(pin, INPUT_PULLUP); }
    void update(uint32_t now)
    {
      ev_short=false; ev_long=false;
      if(pin<0) return;
      bool raw=(digitalRead(pin)==LOW);
      if(raw!=last_raw) { last_raw=raw; change_ms=now; }
      if(now-change_ms<30) return;                       //Debounce
      if(raw && !state) { state=true; down_ms=now; long_fired=false; }
      else if(!raw && state) { state=false; if(!long_fired && now-down_ms<700) ev_short=true; }
      if(state && !long_fired && now-down_ms>=700) { long_fired=true; ev_long=true; }
    }
  };
  static Btn btn_next, btn_ok;

  //----------------------------------------------------------------------------------------------------------------------------------
  // Settings storage
  //----------------------------------------------------------------------------------------------------------------------------------
  static void load_settings()
  {
    Preferences p;
    p.begin("lcd", true);
    set_bright=p.getInt("br", 3);
    set_off=p.getInt("off", 0);
    set_rot=p.getInt("rot", 0);
    set_mirror=p.getInt("mir", 0);
    set_lang=p.getInt("lang", 0);
    page=p.getInt("page", 0);
    p.end();
    set_bright=constrain(set_bright,0,4); set_off=constrain(set_off,0,2); set_rot=constrain(set_rot,0,3);
    set_mirror=constrain(set_mirror,0,1); set_lang=constrain(set_lang,0,1); page=constrain(page,0,2);
  }

  static void save_settings()
  {
    Preferences p;
    p.begin("lcd", false);
    p.putInt("br", set_bright); p.putInt("off", set_off); p.putInt("rot", set_rot);
    p.putInt("mir", set_mirror); p.putInt("lang", set_lang); p.putInt("page", page);
    p.end();
  }

  static uint8_t brightness_value() { static const uint8_t v[5]={40,80,130,190,255}; return v[constrain(set_bright,0,4)]; }
  static void apply_rotation() { lcd.setRotation((set_rot & 3) + (set_mirror ? 4 : 0)); }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Drawing helpers
  //----------------------------------------------------------------------------------------------------------------------------------
  static void font(lgfx::VLWfont& f) { spr.setFont(&f); }

  static void text(const char* s, int x, int y, uint16_t col, lgfx::VLWfont& f, textdatum_t d)
  {
    font(f); spr.setTextColor(col); spr.setTextDatum(d); spr.drawString(s, x, y);
  }

  //Word wrap for smooth fonts. Returns the y position after the last line.
  static int text_wrap(const char* s, int x, int y, int w, int line_h, uint16_t col, lgfx::VLWfont& f)
  {
    font(f); spr.setTextColor(col); spr.setTextDatum(textdatum_t::top_left);
    char line[96]; line[0]=0;
    const char* p=s;
    while(*p)
    {
      const char* e=p; while(*e && *e!=' ') e++;
      char word[48]; int n=min((int)(e-p), 47); memcpy(word,p,n); word[n]=0;
      char test[144];
      if(line[0]) snprintf(test,sizeof(test),"%s %s",line,word); else snprintf(test,sizeof(test),"%s",word);
      if(spr.textWidth(test)>w && line[0]) { spr.drawString(line,x,y); y+=line_h; snprintf(line,sizeof(line),"%s",word); }
      else snprintf(line,sizeof(line),"%s",test);
      p=e; while(*p==' ') p++;
    }
    if(line[0]) { spr.drawString(line,x,y); y+=line_h; }
    return y;
  }

  static void pill(int x, int y, int w, int h, const char* s, bool on, uint16_t col)
  {
    if(on) { spr.fillRoundRect(x,y,w,h,h/2,col); text(s, x+w/2, y+h/2+1, C_BLACK, fontS, textdatum_t::middle_center); }
    else { spr.fillRoundRect(x,y,w,h,h/2,C_PANEL); text(s, x+w/2, y+h/2+1, C_DIM, fontS, textdatum_t::middle_center); }
  }

  static void progress(int x, int y, int w, int h, float f, uint16_t col)
  {
    f=constrain(f,0.0f,1.0f);
    spr.fillRoundRect(x,y,w,h,h/2,C_PANEL2);
    int fw=(int)(w*f); if(fw>=h) spr.fillRoundRect(x,y,fw,h,h/2,col);
  }

  static bool any_signal() { for(int i=0;i<4;i++) if(t.ch[i].signal) return true; return false; }

  //Bluetooth symbol (simple rune), 10x16
  static void bt_icon(int x, int y, uint16_t col)
  {
    spr.drawLine(x+5,y,x+5,y+15,col);
    spr.drawLine(x+5,y,x+9,y+4,col); spr.drawLine(x+9,y+4,x+1,y+11,col);
    spr.drawLine(x+5,y+15,x+9,y+11,col); spr.drawLine(x+9,y+11,x+1,y+4,col);
  }

  //Charge in percent from the voltage of a 1S LiPo / Li-Ion cell (small load)
  static int battery_percent(int mv)
  {
    static const int16_t v[]={3300,3500,3610,3670,3710,3750,3800,3850,3920,4000,4100,4180};
    static const int8_t  p[]={   0,   5,  10,  20,  30,  40,  50,  60,  70,  80,  90, 100};
    const int n=sizeof(v)/sizeof(v[0]);
    if(mv<=v[0]) return 0;
    if(mv>=v[n-1]) return 100;
    for(int i=1;i<n;i++) if(mv<v[i]) return p[i-1]+(int)((long)(mv-v[i-1])*(p[i]-p[i-1])/(v[i]-v[i-1]));
    return 100;
  }

  static uint16_t battery_color(int pct) { return pct<=15 ? C_RED : (pct<=30 ? C_AMBER : C_GREEN); }

  //Battery symbol 24x12 (body 22, nub 2)
  static void battery_icon(int x, int y, int pct, uint16_t col)
  {
    spr.drawRoundRect(x,y,22,12,3,C_DIM);
    spr.fillRect(x+22,y+3,2,6,C_DIM);
    int w=(18*constrain(pct,0,100)+50)/100;
    if(w>0) spr.fillRoundRect(x+2,y+2,w,8,1,col);
  }

  //New battery sample (mV). Smoothing, detection of a missing battery, low warning, empty detection
  static void battery_feed(int mv_raw, uint32_t now)
  {
    if(battery_mv==0) battery_mv=mv_raw; else battery_mv+= (mv_raw-battery_mv)/8;
    if(mv_raw<bat_win_min) bat_win_min=mv_raw;
    if(mv_raw>bat_win_max) bat_win_max=mv_raw;
    if(bat_win_start==0) bat_win_start=now;
    if(now-bat_win_start>=5000)
    {
      bat_unstable=(bat_win_max-bat_win_min)>250;
      bat_win_min=100000; bat_win_max=0; bat_win_start=now;
    }
    bool present=(battery_mv>2800) && !bat_unstable;
    if(!present) { battery_pct=-1; bat_empty_since=0; return; }
    if(battery_mv>=3500) bat_seen_ok=true;
    int p=battery_percent(battery_mv);
    if(battery_pct<0 || abs(p-battery_pct)>=2 || p==0 || p==100) battery_pct=p;
    if(battery_pct<=10 && !bat_low_warned) { bat_low_warned=true; toast_txt=T_BAT_LOW; toast_until=now+4000; }
    if(battery_pct>=20) bat_low_warned=false;
#if battery_low_sleep
    if(bat_seen_ok && battery_mv<3300) { if(bat_empty_since==0) bat_empty_since=now; if(now-bat_empty_since>=60000) battery_empty=true; }
    else bat_empty_since=0;
#endif
  }

  static void status_bar()
  {
    spr.fillRect(0,0,240,26,C_PANEL);
    bool blink=((t.ms/500)%2)==0;
    if(t.bt_connected) { bt_icon(8,5,C_ACCENT); text(tx(T_BT_ON), 24, 13, C_TEXT, fontS, textdatum_t::middle_left); }
    else { bt_icon(8,5, blink ? C_AMBER : C_DIM); text(tx(T_BT_OFF), 24, 13, C_AMBER, fontS, textdatum_t::middle_left); }

    //Receiver state
    bool sig=any_signal();
    uint16_t c = sig ? C_GREEN : C_RED;
#if lcd_battery_display
    bool bat=(battery_pct>=0);
#else
    bool bat=false;
#endif
    if(bat)
    {
      //Layout with battery: RC in the middle, battery on the right
      spr.fillCircle(156,13,4,c);
      text("RC", 148, 13, sig ? C_TEXT : C_RED, fontS, textdatum_t::middle_right);
      uint16_t bc=battery_color(battery_pct);
      bool show=!(battery_pct<=10 && ((t.ms/500)%2)==0);
      if(show) battery_icon(212,7,battery_pct,bc);
      char b[8]; snprintf(b,sizeof(b),"%d%%",battery_pct);
      text(b, 208, 13, battery_pct<=15 ? C_RED : C_TEXT, fontS, textdatum_t::middle_right);
    }
    else
    {
      spr.fillCircle(222,13,5,c);
      text("RC", 212, 13, sig ? C_TEXT : C_RED, fontS, textdatum_t::middle_right);
      //Page dots
      for(int i=0;i<3;i++) spr.fillCircle(150+i*10,13,(i==page)?3:2,(i==page)?C_TEXT:C_DIM);
    }
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Page 0: Drive view
  //----------------------------------------------------------------------------------------------------------------------------------
  static void steering_wheel(int cx, int cy, int r, float pct, bool live)
  {
    float ang=pct*0.9f;                                   //+-100% -> +-90 degrees
    uint16_t ring = live ? C_TEXT : C_DIM;
    uint16_t hub = live ? C_PANEL2 : C_PANEL;
    //Travel arc in the background and filled part
    spr.fillArc(cx,cy,r+10,r+6,180,360,C_PANEL);
    if(pct>1) spr.fillArc(cx,cy,r+10,r+6,270,270+ang,C_ACCENT);
    else if(pct<-1) spr.fillArc(cx,cy,r+10,r+6,270+ang,270,C_ACCENT);
    //Wheel
    spr.fillCircle(cx,cy,r,ring);
    spr.fillCircle(cx,cy,r-8,C_BG);
    float a=ang*PI/180.0f;
    //Spokes at 90 (left), 270 (right) and 180 (down) degrees relative to the top marker
    for(int k=0;k<3;k++)
    {
      float base = (k==0) ? PI : (k==1 ? 0.0f : PI/2.0f);   //left, right, down in screen coordinates
      float aa=base+a;
      int x1=cx+(int)(cosf(aa)*(r-6)); int y1=cy+(int)(sinf(aa)*(r-6));
      spr.drawWideLine(cx,cy,x1,y1,4,ring);
    }
    spr.fillCircle(cx,cy,14,hub);
    spr.fillCircle(cx,cy,5,ring);
    //Top marker
    float am=-PI/2.0f+a;
    int mx=cx+(int)(cosf(am)*(r-4)); int my=cy+(int)(sinf(am)*(r-4));
    spr.fillCircle(mx,my,5,live ? C_RED : C_DIM);
  }

  static void throttle_bar(int x, int y, int w, int h, float pct, bool live)
  {
    int cy=y+h/2;
    spr.fillRoundRect(x,y,w,h,6,C_PANEL);
    int half=h/2-3;
    if(pct>1)
    {
      int fh=(int)(half*pct/100.0f);
      spr.fillRoundRect(x+3,cy-fh,w-6,fh,4,live?C_GREEN:C_DIM);
    }
    else if(pct<-1)
    {
      int fh=(int)(half*(-pct)/100.0f);
      spr.fillRoundRect(x+3,cy,w-6,fh,4,live?C_RED:C_DIM);
    }
    spr.drawFastHLine(x-4,cy,w+8,C_DIM);
  }

  static void page_drive()
  {
    bool live=any_signal();
    float steer=t.ch[0].pre/10.0f;
    float thr=t.ch[1].pre/10.0f;

    steering_wheel(84,108,56,steer,live);

    char buf[24];
    if(steer>1) snprintf(buf,sizeof(buf),"R %d%%",(int)(steer+0.5f));
    else if(steer<-1) snprintf(buf,sizeof(buf),"L %d%%",(int)(-steer+0.5f));
    else snprintf(buf,sizeof(buf),"%s",tx(T_CENTER));
    text(buf,84,182,live?C_TEXT:C_DIM,fontM,textdatum_t::middle_center);

    text(tx(T_GAS),198,36,C_DIM,fontS,textdatum_t::middle_center);
    throttle_bar(184,46,28,124,thr,live);
    text(tx(T_BRAKE),198,180,C_DIM,fontS,textdatum_t::middle_center);
    if(thr>1) { snprintf(buf,sizeof(buf),"%d",(int)(thr+0.5f)); text(buf,178,64,C_GREEN,fontS,textdatum_t::middle_right); }
    else if(thr<-1) { snprintf(buf,sizeof(buf),"%d",(int)(-thr+0.5f)); text(buf,178,152,C_RED,fontS,textdatum_t::middle_right); }

    //Function chips
    bool rev = t.reverse_hold || (t.ms<reverse_flash_until);
    pill(4,196,74,19,tx(T_CHIP_TURBO),t.turbo,C_AMBER);
    pill(83,196,74,19,tx(T_CHIP_REV),rev,C_VIOLET);
    pill(162,196,74,19,tx(T_CHIP_LIGHT),t.c_light,C_YELLOW);
    pill(4,218,74,19,tx(T_CHIP_LAUNCH),t.c_launch,C_ACCENT);
    pill(83,218,74,19,tx(T_CHIP_MOTOR),t.c_motor,C_GREEN);
    pill(162,218,74,19,tx(T_CHIP_MENU),t.c_menu,C_TEXT);

    //Hint, if no receiver is connected
    if(!live)
    {
      spr.fillRoundRect(14,88,212,42,10,C_PANEL2);
      text(tx(T_RX_NONE),120,101,C_RED,fontM,textdatum_t::middle_center);
      text(tx(T_RX_HINT),120,119,C_DIM,fontS,textdatum_t::middle_center);
    }
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Page 1: Channels
  //----------------------------------------------------------------------------------------------------------------------------------
  static void channel_bar(int x, int y, int w, int h, const LcdChannel& c, long scale_min, long scale_max, bool show_range, bool show_neutral=true)
  {
    spr.fillRoundRect(x,y,w,h,h/2,C_PANEL2);
    auto px=[&](long us)->int { long v=constrain(us,scale_min,scale_max); return x+(int)((v-scale_min)*(long)(w-1)/(scale_max-scale_min)); };
    if(c.steps==0)
    {
      if(show_range && c.cal_max>c.cal_min) spr.fillRect(px(c.cal_min),y+2,max(1,px(c.cal_max)-px(c.cal_min)),h-4,lgfx::color565(0x1E,0x5A,0x70));
      if(show_neutral && c.neu_max>=c.neu_min && c.neu_min>0) spr.fillRect(px(c.neu_min),y+1,max(2,px(c.neu_max)-px(c.neu_min)),h-2,lgfx::color565(0x2A,0x7A,0x4E));
    }
    else
    {
      //Discrete channel: show the positions
      int n=c.steps+1;
      for(int i=0;i<n;i++)
      {
        int sx=x+4+i*(w-8)/max(1,n-1);
        spr.fillCircle(sx,y+h/2,3,(c.pre==i)?C_ACCENT:C_DIM);
      }
    }
    if(c.raw>0)
    {
      int mx=px(c.raw);
      spr.fillRoundRect(mx-2,y-3,5,h+6,2,c.signal?C_TEXT:C_RED);
    }
  }

  static void page_channels()
  {
    text(tx(T_CHANNELS),12,42,C_TEXT,fontL,textdatum_t::middle_left);
    static const int names[4]={T_CH_STEER,T_CH_THROTTLE,T_CH_TURBO,T_CH_REVERSE};
    for(int i=0;i<4;i++)
    {
      const LcdChannel& c=t.ch[i];
      int y=64+i*44;
      char buf[32];
      text(tx(names[i]),12,y+8,c.signal?C_TEXT:C_DIM,fontM,textdatum_t::middle_left);
      snprintf(buf,sizeof(buf),"Pin %d",pins[i]);
      font(fontM); int nw=spr.textWidth(tx(names[i]));
      text(buf,18+nw,y+9,C_DIM,fontS,textdatum_t::middle_left);
      if(c.signal) snprintf(buf,sizeof(buf),"%ld µs",c.raw); else snprintf(buf,sizeof(buf),"%s",tx(T_NOSIG));
      text(buf,228,y+8,c.signal?C_ACCENT:C_RED,fontS,textdatum_t::middle_right);
      long smin=900, smax=2100;
      if(c.cal_max>c.cal_min && c.cal_min>500) { smin=min(smin,c.cal_min-30); smax=max(smax,c.cal_max+30); }
      bool tog=(c.steps>0 && c.toggle_btn);
      channel_bar(12,y+22,tog?140:216,10,c,smin,smax,true);
      if(tog) text(tx(T_TOGGLE),228,y+27,C_AMBER,fontS,textdatum_t::middle_right);
    }
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Page 2: Info
  //----------------------------------------------------------------------------------------------------------------------------------
  static const char* combos_text(int uc)
  {
    if(uc>=2) return tx(T_CMB_ALL);
    if(uc<0) return tx(T_CMB_NOTURBO);
    if(uc==1) return tx(T_CMB_SOME);
    return tx(T_CMB_LIGHT);
  }

  static const char* speed_text(int s) { return s<0 ? tx(T_SPD_SLOW) : (s>0 ? tx(T_SPD_FAST) : tx(T_SPD_MED)); }

  static void expo_text(long e, char* out, size_t n)
  {
    if(e==0) snprintf(out,n,"%s",tx(T_EXPO_OFF));
    else if(e>0) snprintf(out,n,"%s %ld",tx(T_EXPO_SOFT),(e+5)/10);
    else snprintf(out,n,"%s %ld",tx(T_EXPO_PROG),(-e+5)/10);
  }

  static void info_row(int y, const char* k, const char* v)
  {
    text(k,12,y,C_DIM,fontS,textdatum_t::middle_left);
    text(v,228,y,C_TEXT,fontS,textdatum_t::middle_right);
    spr.drawFastHLine(12,y+11,216,C_PANEL);
  }

  static void page_info()
  {
    text(tx(T_INFO),12,42,C_TEXT,fontL,textdatum_t::middle_left);
    char a[24], b[24], buf[48];
    int y=66, dy=20;
    info_row(y,tx(T_I_NAME),bt_name); y+=dy;
    info_row(y,tx(T_I_FW),fw_name); y+=dy;
    info_row(y,tx(T_I_COMBOS),combos_text(t.use_combos)); y+=dy;
    info_row(y,tx(T_I_SPEED),speed_text(t.combo_speed)); y+=dy;
    expo_text(t.ch[0].expo,a,sizeof(a)); expo_text(t.ch[1].expo,b,sizeof(b));
    snprintf(buf,sizeof(buf),"%s / %s",a,b);
    info_row(y,tx(T_I_EXPO),buf); y+=dy;
    if(battery_pct>=0) snprintf(buf,sizeof(buf),"%d%%  %d.%02d V",battery_pct,battery_mv/1000,(battery_mv%1000)/10); else snprintf(buf,sizeof(buf),"%s",tx(T_NOBAT));
    info_row(y,tx(T_I_BAT),buf); y+=dy;
    uint32_t s=t.ms/1000;
    snprintf(buf,sizeof(buf),"%02lu:%02lu:%02lu",(unsigned long)(s/3600),(unsigned long)((s/60)%60),(unsigned long)(s%60));
    info_row(y,tx(T_I_UPTIME),buf); y+=dy;
    //Live state of the buttons: green = pressed
    text(tx(T_I_BUTTONS),12,y,C_DIM,fontS,textdatum_t::middle_left);
    {
      const char* names[4]={"BOOT", t.btn_cal_inverted ? "CAL*" : "CAL", tx(T_B_NEXT), "OK"};
      bool on[4]={t.btn_boot, t.btn_cal, btn_next.state, btn_ok.state};
      bool used[4]={true, pin_cal>=0, pin_next>=0, pin_ok>=0};
      font(fontS);
      int x=228;
      for(int i=3;i>=0;i--)
      {
        if(!used[i]) continue;
        int w=spr.textWidth(names[i])+6;
        x-=w;
        if(on[i]) spr.fillRoundRect(x,y-8,w,17,8,C_GREEN);
        text(names[i],x+w/2,y+1,on[i]?C_BLACK:C_DIM,fontS,textdatum_t::middle_center);
        x-=2;
      }
    }
    y+=dy;
    if(pin_ok>=0) text(tx(T_OK_HINT),120,230,C_DIM,fontS,textdatum_t::middle_center);
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Settings menu
  //----------------------------------------------------------------------------------------------------------------------------------
  enum { MI_BRIGHT, MI_OFF, MI_ROT, MI_MIRROR, MI_LANG, MI_COMBOS, MI_SPEED, MI_EXPO_S, MI_EXPO_T, MI_BACK, MI_COUNT };

  static void menu_value(int item, char* out, size_t n)
  {
    switch(item)
    {
      case MI_BRIGHT: snprintf(out,n,"%d%%",(set_bright+1)*20); break;
      case MI_OFF: snprintf(out,n,"%s", set_off==0 ? tx(T_NEVER) : (set_off==1 ? "1 min" : "5 min")); break;
      case MI_ROT: snprintf(out,n,"%d°",set_rot*90); break;
      case MI_MIRROR: snprintf(out,n,"%s",set_mirror ? tx(T_ON) : tx(T_OFF)); break;
      case MI_LANG: snprintf(out,n,"%s",tx(T_LANG)); break;
      case MI_COMBOS: snprintf(out,n,"%s",combos_text(t.use_combos)); break;
      case MI_SPEED: snprintf(out,n,"%s",speed_text(t.combo_speed)); break;
      case MI_EXPO_S: expo_text(t.ch[0].expo,out,n); break;
      case MI_EXPO_T: expo_text(t.ch[1].expo,out,n); break;
      default: out[0]=0; break;
    }
  }

  static void request_setting(int id, long val)
  {
    portENTER_CRITICAL(&mux);
    pending_id=id; pending_val=val;
    portEXIT_CRITICAL(&mux);
  }

  static long next_expo(long e)
  {
    //Order: off, soft 25..100, progressive 25..100, off
    static const long seq[9]={0,250,500,750,1000,-250,-500,-750,-1000};
    int idx=0; long best=100000;
    for(int i=0;i<9;i++) { long d=labs(seq[i]-e); if(d<best) { best=d; idx=i; } }
    return seq[(idx+1)%9];
  }

  static void menu_change(int item)
  {
    if(t.cal_step_ext!=0 && item>=MI_COMBOS && item<=MI_EXPO_T) { blocked_until=t.ms+1500; return; }
    switch(item)
    {
      case MI_BRIGHT: set_bright=(set_bright+1)%5; lcd.setBrightness(brightness_value()); save_settings(); break;
      case MI_OFF: set_off=(set_off+1)%3; save_settings(); break;
      case MI_ROT: set_rot=(set_rot+1)%4; apply_rotation(); save_settings(); break;
      case MI_MIRROR: set_mirror=!set_mirror; apply_rotation(); save_settings(); break;
      case MI_LANG: set_lang=!set_lang; save_settings(); break;
      case MI_COMBOS:
      {
        int uc=t.use_combos; int nv;
        if(uc>=2) nv=-1; else if(uc<0) nv=1; else if(uc==1) nv=0; else nv=2;
        request_setting(LCD_SET_COMBOS,nv); t.use_combos=nv; break;
      }
      case MI_SPEED:
      {
        int nv = (t.combo_speed<0) ? 0 : (t.combo_speed==0 ? 1 : -1);
        request_setting(LCD_SET_SPEED,nv); t.combo_speed=nv; break;
      }
      case MI_EXPO_S: { long nv=next_expo(t.ch[0].expo); request_setting(LCD_SET_EXPO_STEER,nv); t.ch[0].expo=nv; break; }
      case MI_EXPO_T: { long nv=next_expo(t.ch[1].expo); request_setting(LCD_SET_EXPO_THROTTLE,nv); t.ch[1].expo=nv; break; }
      case MI_BACK: menu_open=false; break;
    }
  }

  static void draw_menu()
  {
    text(tx(T_SETTINGS),12,42,C_TEXT,fontL,textdatum_t::middle_left);
    static const int labels[MI_COUNT]={T_M_BRIGHT,T_M_OFF,T_M_ROT,T_M_MIRROR,T_M_LANG,T_M_COMBOS,T_M_SPEED,T_M_EXPO_S,T_M_EXPO_T,T_M_BACK};
    const int visible=7, ih=24, y0=62;
    int first=constrain(menu_item-visible/2,0,MI_COUNT-visible);
    for(int i=first;i<first+visible && i<MI_COUNT;i++)
    {
      int y=y0+(i-first)*ih;
      bool sel=(i==menu_item);
      if(sel) spr.fillRoundRect(6,y,228,ih-2,8,C_PANEL2);
      text(tx(labels[i]),14,y+ih/2,sel?C_TEXT:C_DIM,fontS,textdatum_t::middle_left);
      char v[32]; menu_value(i,v,sizeof(v));
      text(v,226,y+ih/2,sel?C_ACCENT:C_DIM,fontS,textdatum_t::middle_right);
    }
    //Scroll indicator
    int sh=170*visible/MI_COUNT; int sy=y0+(170-sh)*first/max(1,MI_COUNT-visible);
    spr.fillRoundRect(236,sy,3,sh,1,C_PANEL2);
    if(t.ms<blocked_until)
    {
      spr.fillRoundRect(14,100,212,40,10,C_AMBER);
      text(tx(T_BLOCKED),120,120,C_BLACK,fontS,textdatum_t::middle_center);
    }
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Calibration screen
  //----------------------------------------------------------------------------------------------------------------------------------
  static void draw_calibration()
  {
    int st=constrain(t.cal_step_ext,1,6);
    spr.fillRect(0,0,240,30,t.cal_btn ? C_GREEN : C_AMBER);
    text(tx(T_CAL),10,15,C_BLACK,fontM,textdatum_t::middle_left);
    for(int i=1;i<=6;i++) spr.fillCircle(150+(i-1)*14,15,(i==st)?5:3,(i<=st)?C_BLACK:lgfx::color565(0x80,0x58,0x10));

    static const int titles[6]={T_CAL1_T,T_CAL2_T,T_CAL3_T,T_CAL4_T,T_CAL5_T,T_CAL6_T};
    static const int bodies[6]={T_CAL1,T_CAL2,T_CAL3,T_CAL4,T_CAL5,T_CAL6};
    char buf[48];
    snprintf(buf,sizeof(buf),"%s %d: %s",tx(T_STEP),st,tx(titles[st-1]));
    text(buf,10,44,C_TEXT,fontM,textdatum_t::middle_left);
    int y=text_wrap(tx(bodies[st-1]),10,58,220,16,C_DIM,fontS);

    //Live view of all channels
    static const int names[4]={T_CH_STEER,T_CH_THROTTLE,T_CH_TURBO,T_CH_REVERSE};
    int by=max(y+6,110);
    int rows_h = (st==6) ? 22 : 28;
    for(int i=0;i<4;i++)
    {
      const LcdChannel& c=t.ch[i];
      int ry=by+i*rows_h;
      text(tx(names[i]),10,ry+5,c.signal?C_TEXT:C_DIM,fontS,textdatum_t::middle_left);
      if(c.signal) snprintf(buf,sizeof(buf),"%ld",c.raw); else snprintf(buf,sizeof(buf),"%s",tx(T_NOSIG));
      text(buf,230,ry+5,c.signal?C_ACCENT:C_RED,fontS,textdatum_t::middle_right);
      channel_bar(96,ry+1,96,8,c,900,2100,true,st>=2);
      if(st>=2 && c.steps>0 && c.toggle_btn) spr.fillCircle(88,ry+5,3,C_AMBER);
    }

    if(st==6)
    {
      int py=by+4*rows_h+4;
      spr.fillRoundRect(6,py,228,236-py,8,C_PANEL);
      snprintf(buf,sizeof(buf),"%s: %d",tx(T_CAL_PRESSES),t.cal_presses);
      text(buf,14,py+10,C_TEXT,fontS,textdatum_t::middle_left);
      int uc; if(t.cal_presses>=15) uc=0; else if(t.cal_presses>=10) uc=1; else if(t.cal_presses>=5) uc=-1; else uc=2;
      if(t.cal_presses>=20) snprintf(buf,sizeof(buf),"%s",tx(T_FACTORY)); else snprintf(buf,sizeof(buf),"%s: %s",tx(T_I_COMBOS),combos_text(uc));
      text(buf,14,py+26,t.cal_presses>=20?C_RED:C_ACCENT,fontS,textdatum_t::middle_left);
    }

    //Hold progress for saving
    if(st==6 && t.cal_btn && t.cal_hold_ms>300)
    {
      spr.fillRoundRect(20,96,200,56,12,C_PANEL2);
      text(tx(T_HOLD_SAVE),120,114,C_TEXT,fontM,textdatum_t::middle_center);
      progress(36,132,168,10,t.cal_hold_ms/2500.0f,C_GREEN);
    }
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Overlays
  //----------------------------------------------------------------------------------------------------------------------------------
  static void overlays()
  {
    //CAL button held in normal mode: show progress until the calibration starts
    if(t.cal_step_ext==0 && t.cal_btn && t.cal_hold_ms>300)
    {
      spr.fillRoundRect(20,90,200,60,12,C_PANEL2);
      spr.drawRoundRect(20,90,200,60,12,C_AMBER);
      text(tx(T_HOLD_CAL),120,110,C_TEXT,fontM,textdatum_t::middle_center);
      progress(36,128,168,10,t.cal_hold_ms/5000.0f,C_AMBER);
    }
    //Sleep countdown
    if(t.sleep_left_ms>0 && t.sleep_left_ms<60000 && t.cal_step_ext==0)
    {
      char buf[40]; snprintf(buf,sizeof(buf),"%s %lu s",tx(T_SLEEP_IN),(unsigned long)(t.sleep_left_ms/1000));
      spr.fillRoundRect(20,30,200,24,12,C_AMBER);
      text(buf,120,42,C_BLACK,fontS,textdatum_t::middle_center);
    }
    //Toast after saving the calibration
    if(t.ms<toast_until && toast_txt>=0)
    {
      spr.fillRoundRect(30,96,180,48,12,(toast_txt==T_FACTORY || toast_txt==T_BAT_LOW)?C_AMBER:C_GREEN);
      text(tx(toast_txt),120,120,C_BLACK,fontM,textdatum_t::middle_center);
    }
  }

  static void draw_sleep_screen()
  {
    spr.fillScreen(C_BG);
    if(sleep_empty)
    {
      spr.drawRoundRect(88,62,58,28,6,C_RED); spr.fillRect(146,70,5,12,C_RED);
      text(tx(T_BAT_EMPTY),120,118,C_RED,fontL,textdatum_t::middle_center);
      text(tx(T_BAT_CHARGE),120,148,C_DIM,fontS,textdatum_t::middle_center);
    }
    else
    {
      text(tx(T_SLEEP),120,104,C_TEXT,fontL,textdatum_t::middle_center);
      text(tx(T_SLEEP_HINT),120,134,C_DIM,fontS,textdatum_t::middle_center);
    }
#ifndef LCDUI_HOST
    spr.pushSprite(0,0);
#endif
  }

  //----------------------------------------------------------------------------------------------------------------------------------
  // Display task
  //----------------------------------------------------------------------------------------------------------------------------------
  static void wake()
  {
    last_wake_ms=t.ms;
    if(!screen_on) { screen_on=true; lcd.wakeup(); lcd.setBrightness(brightness_value()); }
  }

  static void handle_input()
  {
    btn_next.update(t.ms); btn_ok.update(t.ms);
    bool any = btn_next.ev_short || btn_next.ev_long || btn_ok.ev_short || btn_ok.ev_long;

    //Activity on the RC inputs or calibration wakes the screen
    if(t.activity_ms!=last_activity_seen) { last_activity_seen=t.activity_ms; wake(); }
    if(t.cal_step_ext!=0 || t.cal_btn) wake();

    if(any)
    {
      bool was_off=!screen_on;
      wake();
      if(was_off) return;                         //First press only wakes the screen
      menu_last_ms=t.ms;
      if(menu_open)
      {
        if(btn_next.ev_short) menu_item=(menu_item+1)%MI_COUNT;
        if(btn_next.ev_long) menu_item=(menu_item+MI_COUNT-1)%MI_COUNT;
        if(btn_ok.ev_short) menu_change(menu_item);
        if(btn_ok.ev_long) menu_open=false;
      }
      else
      {
        if(btn_next.ev_short) { page=(page+1)%3; save_settings(); }
        if(btn_next.ev_long) { screen_on=false; lcd.setBrightness(0); lcd.sleep(); }
        if(btn_ok.ev_short && t.cal_step_ext==0) { menu_open=true; menu_item=0; }
      }
    }
    if(menu_open && t.ms-menu_last_ms>20000) menu_open=false;
    if(t.cal_step_ext!=0) menu_open=false;

    //Automatic screen off
    static const uint32_t off_ms[3]={0,60000,300000};
    if(screen_on && set_off>0 && t.ms-last_wake_ms>off_ms[set_off]) { screen_on=false; lcd.setBrightness(0); lcd.sleep(); }
  }

  static void track_events()
  {
    //Calibration finished -> toast
    if(last_cal_step==6 && t.cal_step_ext==0)
    {
      toast_txt = (last_cal_presses>=20) ? T_FACTORY : T_SAVED;
      toast_until=t.ms+2500;
    }
    last_cal_step=t.cal_step_ext;
    last_cal_presses=t.cal_presses;
    //Reverse button press is only 250 ms long, show it a bit longer
    if(t.reverse_pulse) reverse_flash_until=t.ms+900;
  }

  static void read_battery()
  {
    if(t.ms-battery_ms<250 && battery_ms!=0) return;
    battery_ms=t.ms;
#ifdef battery_adc_hw_pin
#if battery_adc_hw_pin>=0
    uint32_t sum=0;
    for(int i=0;i<4;i++) sum+=analogReadMilliVolts(battery_adc_hw_pin);
    battery_feed((int)((sum/4)*battery_divider_factor),t.ms);
#endif
#endif
  }

#ifndef LCDUI_HOST
  static void task(void*)
  {
    TickType_t wake_tick=xTaskGetTickCount();
    for(;;)
    {
      portENTER_CRITICAL(&mux);
      LcdTele copy=shared;
      portEXIT_CRITICAL(&mux);
      //Keep values of settings the user just changed until loop() has applied them
      int keep_combos=t.use_combos, keep_speed=t.combo_speed; long keep_e0=t.ch[0].expo, keep_e1=t.ch[1].expo;
      bool pend=(pending_id!=LCD_SET_NONE);
      t=copy;
      t.ms=millis();
      if(pend) { t.use_combos=keep_combos; t.combo_speed=keep_speed; t.ch[0].expo=keep_e0; t.ch[1].expo=keep_e1; }

      if(sleep_request)
      {
        draw_sleep_screen();
        vTaskDelay(pdMS_TO_TICKS(2000));
        lcd.setBrightness(0);
        lcd.sleep();
        sleep_done=true;
        for(;;) vTaskDelay(pdMS_TO_TICKS(1000));
      }

      handle_input();
      track_events();
      read_battery();

      if(screen_on)
      {
        spr.fillScreen(C_BG);
        if(t.cal_step_ext!=0) draw_calibration();
        else
        {
          status_bar();
          if(menu_open) draw_menu();
          else if(page==0) page_drive();
          else if(page==1) page_channels();
          else page_info();
        }
        overlays();
        spr.pushSprite(0,0);
      }
      //Frame time 40 ms. Always sleep at least 5 ms, so the idle task on core 0 is never starved (task watchdog)
      TickType_t used=xTaskGetTickCount()-wake_tick;
      TickType_t wait=(used<pdMS_TO_TICKS(35)) ? (pdMS_TO_TICKS(40)-used) : pdMS_TO_TICKS(5);
      vTaskDelay(wait);
      wake_tick=xTaskGetTickCount();
    }
  }
#endif
} // namespace lcdui

#ifndef LCDUI_HOST
//------------------------------------------------------------------------------------------------------------------------------------
// Public interface used by the main sketch
//------------------------------------------------------------------------------------------------------------------------------------

//Start display and display task. Call once in setup()
inline void lcd_begin(const char* bt_name, const char* fw_name, const int ch_pins[4], int pin_next, int pin_ok, int pin_cal=-1)
{
  lcdui::pin_cal=pin_cal;
  using namespace lcdui;
  snprintf(lcdui::bt_name,sizeof(lcdui::bt_name),"%s",bt_name);
  snprintf(lcdui::fw_name,sizeof(lcdui::fw_name),"%s",fw_name);
  for(int i=0;i<4;i++) pins[i]=ch_pins[i];
  lcdui::pin_next=pin_next; lcdui::pin_ok=pin_ok;
  btn_next.begin(pin_next); btn_ok.begin(pin_ok);
  load_settings();

  lcd.init();
  apply_rotation();
  lcd.setBrightness(0);
  lcd.fillScreen(C_BG);

  wrapS.set(FONT_S); fontS.loadFont(&wrapS);
  wrapM.set(FONT_M); fontM.loadFont(&wrapM);
  wrapL.set(FONT_L); fontL.loadFont(&wrapL);
  wrapXL.set(FONT_XL); fontXL.loadFont(&wrapXL);

  spr.setColorDepth(16);
  spr.setPsram(false);
  if(!spr.createSprite(240,240)) { spr.setPsram(true); spr.createSprite(240,240); }

  //Splash screen
  spr.fillScreen(C_BG);
  spr.fillRoundRect(40,60,160,8,4,C_ACCENT);
  spr.setFont(&fontL); spr.setTextColor(C_TEXT); spr.setTextDatum(textdatum_t::middle_center);
  spr.drawString("CH Control Box",120,100);
  spr.setFont(&fontS); spr.setTextColor(C_DIM);
  spr.drawString(lcdui::fw_name,120,128);
  spr.drawString("jogger86 & mameise",120,150);
  spr.pushSprite(0,0);
  lcd.setBrightness(brightness_value());

  last_wake_ms=millis();
  ready=true;
  xTaskCreatePinnedToCore(task,"lcd",8192,nullptr,1,nullptr,0);
}

//Hand over the actual state. Call cyclic in loop() (cheap, copies a small struct)
inline void lcd_publish(const LcdTele& t)
{
  if(!lcdui::ready) return;
  portENTER_CRITICAL(&lcdui::mux);
  lcdui::shared=t;
  portEXIT_CRITICAL(&lcdui::mux);
}

//Get a settings change made in the display menu. Returns true if there is one
inline bool lcd_take_setting(int& id, long& val)
{
  if(lcdui::pending_id==LCD_SET_NONE) return false;
  portENTER_CRITICAL(&lcdui::mux);
  id=lcdui::pending_id; val=lcdui::pending_val; lcdui::pending_id=LCD_SET_NONE;
  portEXIT_CRITICAL(&lcdui::mux);
  return true;
}

//Show the sleep screen and switch the display off. Blocks max. 3 seconds
//True, if the battery is empty for one minute (then the sketch goes to deep sleep)
inline bool lcd_battery_empty() { return lcdui::battery_empty; }

inline void lcd_enter_sleep(bool battery_empty=false)
{
  if(!lcdui::ready) return;
  lcdui::sleep_empty=battery_empty;
  lcdui::sleep_request=true;
  uint32_t start=millis();
  while(!lcdui::sleep_done && millis()-start<3000) delay(10);
}
#endif

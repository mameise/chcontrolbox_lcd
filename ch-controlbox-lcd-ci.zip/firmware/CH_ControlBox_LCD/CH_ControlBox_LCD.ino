/*
---------------------------------------------------- CH Control Box -------------------------------------------------------------
The first and best solution for converting your RC control into a BT device, especially designed for work with Carrera Hybrid (R)
---------------------------------------------------------------------------------------------------------------------------------
(Rights in name belong to Carrera, name used mentioned to showcase what we use it for. This also applies for other mentioed names in this code)

Software Version:
CH_ControlBox_v1-6-0_LCD-1-1-1 (Waveshare ESP32-S3-LCD-1.3)

Software Changelog:
CH_ControlBox_v1-6-0_LCD-1-1-1: Bluetooth fix (09.10.2026, mameise)
1) Bugfix:      With NimBLE-Arduino 2.x the box did not send its name while advertising. Phones did not list it.
                The name is now sent in the scan response (switch: bt_advertising_fix)
2) Bugfix:      After a disconnect the box advertises again, so the phone can reconnect without reset (switch: bt_advertising_fix)

CH_ControlBox_v1-6-0_LCD-1-1-0: Battery operation (09.10.2026, mameise)
1) Feature:     Battery symbol with charge in percent in the status bar, percent and voltage on the info page (switch: lcd_battery_display)
2) Feature:     Warning when the battery is low (10%), deep sleep when the battery is empty for one minute (switch: battery_low_sleep)
3) Feature:     Optional output rx_power_hw_pin for the EN pin of a 5V module: switches the receiver power off in deep sleep
4) Bugfix:      Battery voltage divider of the board is 100K/100K, factor 2.0 (was 3.0, voltage was shown too high)

CH_ControlBox_v1-6-0_LCD-1-0-0: Display edition for the Waveshare ESP32-S3-LCD-1.3 (08.10.2026, mameise)
1) Feature:     Support for the onboard 1.3" display (ST7789 240x240). See chapter 12 for all details.
                Drive view (steering wheel, throttle/brake, turbo, reverse, light, motor, launch control, menu),
                channel view (raw PWM values, calibration ranges, signal state) and info view
2) Feature:     Guided calibration on the display (step, short instruction, live values of all channels, save progress)
3) Feature:     Optional buttons: external CAL button (parallel to BOOT), NEXT button, OK button
4) Feature:     Settings menu on the display: brightness, screen off time, rotation, mirroring (prism case), language DE/EN,
                combos, combo speed, expo steering, expo throttle (combo/expo settings are stored like a calibration)
5) Feature:     Countdown on the display before deep sleep mode, sleep screen when entering deep sleep
6) Switch:      lcd_display_enabled 0 builds exactly the original behavior (same pins), see "ESP32 Pin Assignment"
7) Info:        The control logic (channels, combos, calibration, Bluetooth) is unchanged. The display runs in its own task on core 0.
8) Info:        USB controller mode is not possible on this board (USB is connected over a CH343 USB to UART chip)

CH_ControlBox_v1-6-0: DR!FT support & Implementation of additional features (15.12.2025)
1) CHANGE:      Implemented Support for DR!FT and Carrera Hybrid at the same Time
                For this re-arranged the Button Mapping of the simulated controller, to support both default settings
                Also changed the Reverse Combo and Reverse Button is now simulating a virtual Button instead of throttle+brake together
                But this also can be changed back (for the reverse-button) in calibration step 2, if the toggle button setting is applied to the reverse (Old reverse for Hybrid with brake and throttle at the same time)
        -> See chapter 5.3 for additional information!
2) Feature:     New Combo for toggling the light (Full Brake + 3x Full times from neutral steering to full right steering) (See chapter 7.4)
3) Feature:     New Combo for Starting and stopping the motor (Full Brake + 3x Full times from neutral steering to full right steering and after that full left steering) (See chapter 7.5)
4) Feature:     New Combo for toggling the menu  (Full Brake + 3x Full times from neutral steering to full left steering) (Only Carrera Hybrid -> Needs to be remapped, as the original button is not available See chapter 7.6)
5) Feature:     Feature to also deactivate these new combos partially in the last step. See Chapter 5.7.1
6) Feature:     Possibility to add exponential behavior for all analog channels in the last calibration step 6 -> Soft expo (Left/Brake + CAL) or progressive (Right/Throttle + CAL) (See chapter 5.7.0)
7) Feature:     Possibility to invert digital channels individually in calibration step 5, by just giving an input to the digital channels, which should be inverted (One Click/Switch is enough).
                Also possible for digital channels with more than 2 positions (See Chapter 5.6)
8) Feature:     If a 3 channel RC is used, channel 3 can be used for combining Turbo and Reverse, if this channel has more or equal than 3 digital positions/states (See chapter 2)
9) Improvement: Improvement/optimization of all combo readings to ensure no false readings

CH_ControlBox_v1-5-2: Implementation of additional improvements (25.04.2025)
1) Bugfix:      Fixed problem with iOS and the CH Control Box SW for sending a constant maximum right stick command to the left direction (bug in the used libraries),
                which leads in the new Carrera Hybrid App v1.0.34 to impossible driving, as the right stick is also used for steering starting this app version.

CH_ControlBox_v1-5: Implementation of additional improvements (25.01.2025)
1) Feature:     Added small filtering for the channels with a feature to overwrite the filter with fast or large movements. -> Values are now very smooth and still fast
2) Feature:     Added additional optional feature for only deactivating the Turbo Combo within the calibration routine in Step 6 (when doing 5 short presses on the CAL Button at the end)
3) Feature:     Possibility to invert the LED (In the "ESP32 Pin Assignment" section), if a negative Pin number was assigned (Useful for some boards)
4) Feature:     Possibility to select an RGB LED instead of a normal LED, depending on the hardware (In the "ESP32 Pin Assignment" section. Right now, color is still just BLUE)
5) Feature:     Possibility to choose between different X Box Controller Emulations (XBoxSeriesX->Used Before until v1-4 & XboxOneS->Used Now as standard->Seems to work more stable!)
6) Feature:     (EXPERIMENTAL) In case a ESP32 S3 or S2 board is used, it is possible to activate a parameter to allow you to connect the CH Control Box as a USB controller. (Right now it is only working on Android systems.->Can be activated in the "ESP32 Pin Assignment" section)
7) Improvement: Don't allow small analog values close to 0 and close to 100%. This fixes the reverse bug, which belongs to Android/iOS in combination with the very sensitive  Carrera Hybrid App for detecting reverse condition right now
8) Improvement: Improved internal treatment and timing of the Turbo Combo to reduce the chance for accidentally trigger it.
9) Improvement: By default, don't show the debug info's, as it will slow down the calibration process and you will get better calibration values without this!

CH_ControlBox_v1-4: Implementation of additional features before the big community release (06.12.2024)
1) Feature:     Implemented a new detection to go to a deep sleep mode in different conditions, to save about 1W energy, if the device is not used. (See new chapter 4.4)
2) Feature:     If turbo auto release is set, it is now also possible to release the turbo once for a short moment, when the steering wheel is turned slightly (See chapter 5.7)
3) Feature:     Possibility to set a minimum output, to cover deadzones coming for example from the Apps like Carrera Hybrid (See chapter 5)
4) Feature:     Added a unique generated device ID to the visible Bluetooth name. By this a device conflict is avoided as good as possible. And it is also easier to re-find your box.
5) Improvement: Increased security for the reverse combo, by only be able to activate it, when during the combo the steering is in neutral or close to neutral position. (See chapter 7.1)
6) Misc.:       Update of the manual section

CH_ControlBox_v1-3: Implementation of additional features (04.12.2024)
1) Feature:     Added a new optional calibration step (Step 5) to be able to set the correct channel inversion and additionally also limit the Bluetooth output signal (See chapter 5 of the manual)
2) Feature:     Possibility to select between 3 different Combo speeds (Slow, Medium (default) and Fast) in the calibration. (Also, in the new Step 5)
3) Improvement: Improved launch control start with turbo boost. By only turning the steering wheel slighly to start and afterwards activate turbo boost again
4) Improvement: Due to improvements of the internal interrupt routines, it is now possible to also support RC receivers with total PWM times << 20ms
5) Improvement: Just improved the timings of some LED blink codes a little bit. The blink code for Reverse, Turbo and Combo override have changed/improved.
6) Misc.:       Update of the manual section

CH_ControlBox_v1-2: First launched software version for the first community members to start beta testing (30.11.2024)
1) Feature:     When Turbo auto release is activated, it now will only be performed, when the throttle is once above 80%. This allows still the usage of launch control with physical buttons.
2) Feature:     Implement lots of additional LED blink codes for improved visualization (See chapter 6 in the manual)
3) Feature:     Possibility to turn off combos by pressing combinations with the CAL_BUTTON in the last calibration step. This setting will also be stored. (See chapter 5 in the manual)
4) Feature:     Possibility to release the combos, if the corresponding button is used/pressed, when a combo is active
5) Misc.:       Update of the manual section

CH_ControlBox_v1-1: First completely working software version (27.11.2024)
1) Feature:     Already contains all main software features to be able to control a Carrera Hybrid racer with a normal RC-control over an ESP32 board
2) To Do:       Version needs to be tested also by mameise into detail, before sending it to further community members
3) Misc.:       Implementation of the manual section


Software end user manual
---------------------------------------------------------------------------------------------------------------------------------

1) General Introduction
This Arduino program uses 4 channels of an RC Control (pistol-control or any other RC control including the receiver) that are connected to an ESP32
module to be used as Bluetooth controller. (See on the examples, which boards are tested)
Afterwards Steering, Throttle/Brake, Turbo boost & Reverse (especially designed for Carrera Hybrid (R)) are working after calibration out of the box.
In the best case your RC control has 2 analog channels for Steering & Throttle/Brake + 2 digital channels (Buttons/Switches) to be used for Turbo & Reverse.
If you don't have all/enough Channels on your RC control, you can just leave these pins on the Arduino unconnected.
This software is also able to Control the Launch Control, Turbo and Reverse of thew CH App with only 2 channel RC controls! Therefore, different combos are implemented in this software!

This software was written by jogger86 & mameise.
mameise: Selected the external necessary libraries and formed a first prototype, which was already working, but needed manual work to fit to different RC controls
jogger86: Rewrote the code and wrote all additional classes to implement additional features like LED indication, calibration routine, permanent storing and combos
You can contact them over the CH Players Discord server: https://discord.gg/e2XWuCpfJe

Used/Tested ESP32 Boards:
[TESTED] Diymore WROOM ESP32 USBC (Used by jogger86) (Select "ESP32 Dev Module" in Arduino IDE) -> No additional soldering necessary with this board
[TESTED] XIAO ESP32C3 (Used by mameise) (Select XIAO_ESP32C3 in Arduino)
[TESTED] Waveshare ESP32-S3 Mini (USED by jogger86 for the USB controller version (Android)) (Select “Waveshare ESP32-S3-Zero” in Arduino)
[TESTED] Diymore ESP32 S3 N16R8 USBC (Used by another for the USB controller version (Android) (Select “ESP32S3 Dev Module” in Arduino)

2) Hardware Preparation
Connect your hardware according to the information in the following chapters. Starting firmware 1.6.0 it is also possible to use a combined Turbo/Reverse hardware button configuration,
if you connect an RC channel with 3 or more positions to the turbo pin and leave the reverse pin open (Or in the best case connect it to an open ground pin of your RC receiver)
In this configuration, after performing the software calibration, one position of the button is turbo, in the middle there is nothing and on the other position is reverse. This can also inverted in the calibration.
(Very good valuable options for this are the Spectrum SLT3 remote controls, or the DX3 (more expensive). These are good options for Carrera Hybrid and for Dr!ft)

2.1) Connect your ESP32 Board according to the "ESP32 Pin Assignment" (find below) to your ESP32 board.
Depending on your board it might be necessary to adjust the pins in the section "ESP32 Pin Assignment". Also consider the LED and Button Pin.
But below you will also find some example boards with a working Pin Setup.

2.2) Example Connection to the board "Diymore WROOM ESP32 USBC"
If you don't want to solder additional hardware, you can use a board like "Diymore WROOM ESP32 USBC" (used by jogger86)
This board already has a working onboard LED and a working button for calibration.
Also you can Connect your RC Receiver channels to your board using 6x10cm Arduino jumper cables (female, female)
For this board you can connect the following pins (On this board all these pins are directly next to each other):
VIN(+5V)-> Any + pin of the RC -receiver
GND     -> Any - pin of the RC -receiver
D13     -> Turbo signal channel of your RC receiver
D12     -> Reverse signal channel of your RC receiver
D14     -> Throttle/Brake signal channel of your RC receiver
D27     -> Steering signal channel of your RC receiver

For this setup you can use (If not already set) the following Pins in the "ESP32 Pin Assignment" (find below in the code)
steering_hw_pin->27 | throttle_brake_hw_pin->14 | turbo_hw_pin->13 | reverse_hw_pin->12 | status_led_hw_pin->2 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->0 | use_usb_controler_support->0

2.3) Example Connection of board "XIAO ESP32C3" (Used by mameise's hardware)
As the hardware is completely build up, you only need to connect the cables to your channels and use the following pin assignment in the "ESP32 Pin Assignment" (find below in the code):
steering_hw_pin->2 | throttle_brake_hw_pin->3 | turbo_hw_pin->4 | reverse_hw_pin->5 | status_led_hw_pin->20 | internal_boot_button_hw_pin->9 | internal_led_is_rgb_led->0 | use_usb_controler_support->0

2.4) Example Connection of board "Waveshare ESP32-S3 Mini" (Is equal ESP32 S3 Supermini) (Used for USB support)
This board already has a working onboard RGB LED and a working button for calibration.
Also you can Connect your RC Receiver channels to your board using 6x10cm Arduino jumper cables (female, female)
For this board you can connect the following pins (On this board all these pins are close to each other):
+5V- > Any + pin of the RC -receiver
GND -> Any - pin of the RC -receiver
1   -> Turbo signal channel of your RC receiver
2   -> Reverse signal channel of your RC receiver
3   -> Throttle/Brake signal channel of your RC receiver
4   -> Steering signal channel of your RC receiver

For this setup you can use (If not already set) the following Pins in the "ESP32 Pin Assignment" (find below in the code)
steering_hw_pin->4 | throttle_brake_hw_pin->3 | turbo_hw_pin->1 | reverse_hw_pin->2 | status_led_hw_pin->21 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->1 | use_usb_controler_support->1

2.5) Example Connection of board "Diymore ESP32 S3 N16R8 USBC " (Also Used for USB support)
This board already has a working onboard RGB LED and a working button for calibration.
Also you can Connect your RC Receiver channels to your board using 6x10cm Arduino jumper cables (female, female)
For this board you can connect the following pins (On this board all these pins are close to each other):
GND- > Any - pin of the RC -receiver
5V -> Any + pin of the RC -receiver
14   -> Turbo signal channel of your RC receiver
13   -> Reverse signal channel of your RC receiver
12   -> Throttle/Brake signal channel of your RC receiver
11   -> Steering signal channel of your RC receiver

For this setup you can use (If not already set) the following Pins in the "ESP32 Pin Assignment" (find below in the code)
steering_hw_pin->11 | throttle_brake_hw_pin->12 | turbo_hw_pin->14 | reverse_hw_pin->13 | status_led_hw_pin->48 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->1 | use_usb_controler_support->1

3) Software Installation steps
Different steps are necessary to install the software on your ESP32 device. If you are familiar with this, you can skip this chapter.

3.1) Download and install Arduino IDE:
https://www.arduino.cc/en/software

3.2) Install mandatory libraries
You can download these libraries as ZIP and install them in Arduino over "Sketch"->"Include Library"->"Add ZIP Library..." and select the downloaded zip file. Other versions of these libraries might not work
Used/needed libraries to be installed on your computer: (In the best case use the librarie Zip files provided with this software, as they were tested!)
https://github.com/Mystfit/ESP32-BLE-CompositeHID?tab=readme-ov-file v0.3.0 was tested
https://github.com/h2zero/NimBLE-Arduino - v2.0.0 was tested
https://github.com/tomstewart89/Callback - v1.1 was tested
https://github.com/schnoog/Joystick_ESP32S2 - v0.9.5 was tested (Only if You like to activate USB controller support for ESP32 S2/S3)


3.3) Install/Flash the software on the ESP32
To install/flash the software, perform the following steps:

-Create a folder with the same name as the source code file (without extension) on your computer and put the file inside this new folder.
There mustn't be other *.ino files in the same folder!

-Attach the Arduino Board to your computer over USB cable

-Select your Arduino Board over "Tools"->"Board"...
If your board is not available, go to "Tools"->"Board"->"Boards Manager ..." and find and install your board there (Normally you need to install the "esp32 by Espressif Systems" board library)
IMPORTANT: It seems, that the newest board libraries are not compatible with the bluetooth and gampead libraries. The v3.0.7 was tested and is running!

-Select the COM port where you have attached your Arduino board to under "Tools"->"Port:"...
If you don't know which port to select, remove your Arduino board from USB again.
The port which disappears in this list is the correct one to be chosen after re-plug in again.

-Compile and upload the code to your Arduino board "Sketch"->"Upload" or just press the (->) Button on the top menu bar.
IMPORTANT: For some ESP32 Boards it is necessary to put the board in the Bootloader mode before the flashing.
Otherwise, you will get an error (Necessary for the ESP S2/S3) To do this press and hold the Boot (CAL) button.
After that shortly press the Reset (EN) Button on the board and then release the Boot (CAL) Button

-Wait until the code is compiled and downloaded. Initially this can take some minutes!!
Afterwards the code will automatically be downloaded to your board. You will see the writing process from 0 to 100%

-Now the software is flashed, and you can theoretically unplug the board.
But in the calibration process, the Arduino console "Tools"->"Serial Monitor" will also give you additional information useful for debugging
(You can also use a app like Android Gamepad Tester App to see what is going on during calibration)
Now you can also power up the board with a normal USB mains adapter. (Consider having enough power for powering the ESP and your RC receiver)


3.4) Alternative (Easy) Software Flashing with portable IDE
-As it turned out, that the software flashing can be quite complicated due to some special libraries and board dependencies, also a portable Arduino IDE will be provided inside a self-extracting zip file.

-This portable IDE already contains all necessary libraries and also the correct/compatible ESP32 board library version. This portable version can be used without installing the normal Arduino version.
It will also work in parallel, if already an Arduino version is installed. Beside the extracted files, it will not have any kind of influence on your system.
Of cause this portable version is much bigger compared to the source code itself.

-To use this software, start the file and choose a Folder with a short name close to a root folder like C:\Arduino (Due to long path+filenames in the portable Arduino IDE, the unzipping could otherwise result in an error)
In some cases, the system or your virus scanner will ask if you trust this file.

-After the extraction, you will find different *.bat files in the new folder. If you double click on one of these files, it will open the named CH ControlBox Software version for the named ESP32 board.
The software itself for different board names is always the same, but the pin assignment will be already properly set as suggested in this documentation. Of cause you can also still modify these pins.
(If the Arduino IDE is not opening up automatically the desired files, you need to start the arduino.exe manually in the Arduino Subfolder and open the desired software version,
which is located in the subfolder "..portable\sketchbook".)

-Now you need to select the correct board under "Werkzeuge->Board:->ESP 32 Arduino" In chapter 1 of this manual you will find the names of the boards which should be selected for the example boards.

-After that you need to go to "Werkzeuge->Port:" and select the COM port where you have attached your ESP32 Board to. If you don't know which port to choose,
you can disconnect the board first and check which comp port has disappeared from the list.

-Now you can klick on "Sketch->Hochladen" (STRG+U), which will compile the code (Can take several minutes!) and after hat upload the code.
If the upload fails, you should check the COM port and selected board again.
If it still fails, you might need to bring your board into the boot mode before flashing! (For ESP32 S3 boards for example) To do this press and hold the Boot (CAL) button.
After that shortly press the Reset (EN) Button on the board and then release the Boot (CAL) Button. After that you should be able to flash the board.

-After the flashing (Arduino IDE is showing 100%), your ECU Box is ready to be used.


4) Bluetooth connection and General Information
Activate Bluetooth on your smartphone and search for a new device with the name "CH Control Box". Connect to this device

4.1) Change Bluetooth device name (optional)
If you have trouble when multiple CH Control Boxes are used and your smartphone is not reacting to the correct one,
you can change the name of the device here in the software parametrization section below (bt_device_name). But normally this is not necessary.
And also by default a unique ID is added to the device name, so that the resulting device name is always different.

4.2) Test the Bluetooth device
You can always test device with applications like Gamepad Tester (Select Universal Mode),
which gives you indications which buttons and triggers are active on the gamepad.

4.3) Bluetooth trouble shooting
If you are able to connect the CH Control Box with your smartphnone, but you are not able to see signals in a Gamepad Tester app, or you are not able to drive your racer,
you should test to reboot your ESP32 board by pressing the "EN" button, if avialable, or disconnect from the mains and connect again.

4.4) Energy saving / Deep sleep mode
If the device is not used, there are different conditions, which will set the device into deep sleep mode
to save approximately 1W of standby energy and so reduce the consumption.
If the device is in the deep sleep mode, you can recover it by pressing the EN-button on the ESP32 development board,
or reconnecting again the board power supply.

Conditions to go to deep sleep mode:
 -1- If the RC receiver was never connected after the startup, after 5 minutes
 -2- If the RC receiver was connected after the startup at least once, and if all analog channels are in neutral position and all digital channels are not moved for 30 minutes
 -3- If the RC receiver was connected after the startup at least once, and if analog and digital channels are not moved for 45 minutes

 The times are predefined but could be adopted or completely deactivated in the parameter section of the code.
 INFORMATION: The deep sleep mode reduces the energy consumption of the ESP32 board, but not the consumption of the RC-receiver, so the remaining power consumption is depending on your RC-receiver!

4.5) USB connection (Experimental)
The CH ControlBox Version 1-5 and later also supports connecting the Box as USB gamepad to your Android phone or tablet. Apple devices are not supported right now for the USB version.
But Bluetooth mode is of course still working on iOS. As hardware you need an ESP32 S2 or S2 board to use USB mode, as described above.
Additionally, you need to install the "Joystick_ESP32S2" library, if not already performed and activate the USB support here in the code below the manual section in "ESP32 Pin Assignment".
After flashing the software to your board, USB support for android should work right out of the box.

5) Calibration Process
The calibration works with the Arduino serial monitor, a smartphone app like "gamepad tester" or even only with the LED.
But for the first time it is recommended to use an app showing you what is going on

The Calibration Stepps are controlled using the assigned Arduino board Button (Boot Button for the example boards).
In the following this will only be called CAL_BUTTON.

5.1) Start the calibration process
Hold the CAL_BUTTON 5 seconds and afterward the LED should turn on constantly with blink interruptions showing you the calibration step you are in (flash 1-6 times).
Then you can release the CAL_BUTTON. The calibration process will output information on the Console, if the ESP32 board is still connected to the Arduino IDE.
If you want to get extended information about the information seen on the screen, you need to press the CAL_BUTTON 10x (short press)
BEFORE starting the calibration process with a long Press on the CAL_BUTTON. Therefore, the time between the short presses doesn’t matter.

In both cases the calibration process will start:

5.2) Step 1 - Calibration of the Endstop values
Turn All analog Channels/Triggers until the endstops in all directions. And also push/toggle all buttons/switches to all possible positions of the RC-control which are assigned to this device.
Afterwards leave the triggers in the middle position again and push the CAL_BUTTON again but only with a short press.
(Light will go off for some milliseconds do signalize the next calibration step was started)

5.3) Step 2 - Calibration of the neutral zone + Setup for state or edge detection for discrete channels (like buttons)
Leave all analog triggers in the middle position. Maybe shake the RC control a little bit to cover the complete neutral zone of the analog channels.

In this step you can also decide if the buttons or discrete channels should act on the button state or on the rising edge of the button state.
By default, the channel will directly react on the button state.
If you want to react on the rising edge, you can klick minimum 4x on that button you want to react on the rising edges instead of the state.
After that push the CAL_BUTTON again but only a short press, to go to the next step

IMPORTANT CHANGE since v1.6.0:
For the Reverse Button this behavior is changed since v1.6.0, as now also Dr!ft by Sturmkind is supported, the whole mapping was adopted to support
both products (Dr!ft and Carrera Hybrid) So, normally (without this 4x klick/change) the reverse is now changed and send as a button, as Dr!ft only supports this
If you want to have the old behavior, use the previously described 4x Klick/Change of the reverse channel here in Step 2, to use the old behavior of the physical
reverse channel. The reverse Combo is always now simulating a Click button. This has the advantage that Dr!ft is always supported by this and also the reverse can't be
toggled while driving.

5.4) Step 3 - (optional) Calibrate the Endstop-Deadzone for analog channels
If you want to add an additional deadzone to the endstops of the analog channels, you can do this in this step for each analog channel separately.
If you don't want to do this, just leave the analog channels in the neutral zone without touching them and push the CAL_BUTTON to directly go to the next step.
If you want to add an additional Endstop deadzone, just pull the trigger slightly (For throttle/brake channel), or turn the Steeringwheel (for steering channel) slightly.
For example turning the steering wheel 5° and return to the neutral Zone (direction doesn’t matter) will add an 5° deadzone to the endstop of the positive and negative direction of the steering wheel.
(At the end it will not be measured in degrees, but it is easier to understand) The maximum input detected in this step will be used as the deadzone.
It will be individual for each channel.
If you have finished, push the CAL_BUTTON again but only a short press, to go to the next step

5.5) Step 4 - (optional) Calibrate the Neutral-Deadzone for analog channels
This step is working exactly like the step before, but in this step you will calibrate an additional symmetric neutral deadzone.
If you don't want to use this, leave all analog channels in complete neutral position and push the CAL_BUTTON to directly go to the next step.
If you want to add an extra deadzone to the neutral position, also use steering wheel and/or trigger to go to a maximum desired deadzone. The direction doesn’t matter.
At the end the deadzone will be symmetric applied.
After that leave all channels in neutral position again and push the CAL_BUTTON again but only a short press, to go to the next step

5.6) Step 5 - (optional) Set correct inversion for analog/digital channels, Limit Output, set minimum Output & Set Combo Times
In this step you can specify multiple optional settings. Leaving the trigger in neutral will proceed with default settings.

5.6.1) Set inversion
At first you can set the correct output direction (inversion) of analog channels. This is performed by pushing the analog channels to the expected positive direction (completely pull throttle or/and steer to the right)
Only the channels which you are touching are considered. All other channels will stay on default values.
Try to not go in the opposite direction after releasing the triggers/wheels to neutral, as this will also have an influence on additional options.

Digital Channels: Digital Channels also can be inverted, if the channel (which should be inverted) just gets an press/click/change in this step.
This works also for digital channels with more than two positions. If the digital channels are not pressed in this step, the channel will not be inverted.

All further options are only for analog channels:

5.6.2) Limit output channel (Additional option):
If you are not going to the maximum endstop in this step, you can limit the output values which are sent out as Bluetooth game controller.
For example, pull the throttle trigger only by 50 percent, will limit the maximum Bluetooth throttle signal to 50 percent.
By this you could limit the in-game power by the throttle for beginners. But consider, that also the other direction will be limited (in this example brake)
After that return to neutral position again.

5.6.3) Set a minimum output (Additional option):
If you want to use this step, it is important to also perform step 5.6.1 for this channel!
As Carrera Hybrid has internal dead zones for the throttle, brake & steering, you can here set a minimum output, as soon as the analog channels leave the neutral zone.
This can be set for each analog channel individually, by pushing the trigger or turning the steering wheel slightly in the opposite direction as performed in the inversion step 5.6.1.
So, for the throttle/brake channel it is the throttle direction and for the steering channel it is the left direction.
The more you go into this direction, the more minimum output will be added to this channel. After that return the channel to the neutral position again.
(You can also perform this step before step 5.6.1, if it is easier for you.)

5.6.4) Set different combo times (Additional option, only for throttle)
If you want to reduce or increase the combo times, it depends on the last throttle HOLDING position before pressing the CAL_BUTTON to go to the next step!

MEDIUM --> Standard times: Just leave the Throttle in neutral position before pressing the CAL_BUTTON
FAST --> Reduced by 20%:  Go to the maximum Throttle position, you set in step 5.6.2 (can also be a little bit less!) and hold it before pressing the CAL_BUTTON  (If you skipped 5.6.2 just go to the maximum)
SLOW --> Increased by 20%: Leave the throttle just a little bit in the positive direction, before/while pressing the CAL_BUTTON (For example 10% throttle)

5.6.4) Go to next step
Short press on the CAL_BUTTON to go to the next step.


5.7) Step 6 - Testing Step + Possibility to set a turbo auto release + Save Calibration permanently
In this step, all calibration values are collected. You can test the new values, before saving them. If you don't want to save the values, you can just reboot your ESP32 board.
To save the values, you need to hold down the CAL_BUTTON for 3 seconds again, and wait until the light is going off again/going to normal mode
If you hold the throttle trigger before and while pressing the CAL_BUTTON, the turbo button will (in game) be automatically released, when the throttle button is released.
This is useful for RC-controls which only have toggle buttons and so normally the turbo would be constantly on or off. If this is set, also when the turbo is activated,
the first short steering input will interrupt the turbo shortly. This is useful for starting with turbo after launch control. Also, this will be stored permanently until the next calibration.
Very special cases:
If you hold the throttle trigger at the end of the calibration process BETWEEN the neutral and the throttle maximum position and hold the CAL_BUTTON,
the neutral calibration for this channel will be completely removed & The turbo auto release is also active like described before (Normally not necessary-> Only for special cases)
If you hold the brake trigger at the end of the calibration process BETWEEN the neutral and the brake maximum position and hold the CAL_BUTTON,
the neutral calibration for this channel will be completely removed (Normally not necessary-> Only for special cases)

5.7.0) Add exponential part (For analog channels)
Also, in this calibration step 6 an exponential gain (EXPO) can be added for the analog channels individually (steering / throttle-brake). By default, no exponential gain is added.
It is possible to add soft exponential gain, or progressive exponential gain.
A soft setting will at first increase the output value slowly, but at the end faster.
A progressive setting will at first directly progressively increase the output, but close to the end-stops there is almost no output change

To add a soft setting, turn the steering wheel to the left, or push the brake. The more you go to the endstop, the more influence the EXPO will have. At the endstop, it will have a maximum influence.
Then hold this channel at this position and perform a short press on the CAL_BUTTON. This will store the setting, but only for the channel you have held before.

After that you can also do the same for the other analog channel (steering / throttle-brake)

You can alternatively add a progressive EXPO factor. This is identical like before, but you need to go to the right with the steering wheel, or to the throttle direction with the throttle trigger and press the CAL_BUTON.
You can also set for one analog channel a progressive EXPO setting and the other a soft EXPO setting.

If you want to set an EXPO factor to 0 again, you need to do the same as before but give a very small input to the steering/throttle trigger.
When doing a new calibration, initially, all EXPO factors are also set to 0 again.

IMPORTANT: All clicks on the CAL_BUTTON will already be counted for the next chapter, where combos can partially be deactivated!
But normally you only need 2-4 clicks, to set the EXPO correctly. Otherwise, you can at first find a good EXPO setting for you and then start the calibration again and directly set a perfect EXPO factor.

5.7.1) Deactivating Combos
If you push in the last Step (6) the CAL_BUTTON at least X SHORT times (time between presses doesen't matter) before pressing 1 long press.
->X represents the number of short presses of the CAL_BUTTON in calibration step 6 before pressing the CAL_BUTTON long time to finish the calibration:
 0<=X<5  times  ->  Turbo | Launch Control | Reverse | Light | Motor Start | Menue
 5<=X<10 times  ->        | Launch Control | Reverse | Light | Motor Start | Menue
10<=X<15 times  ->  Turbo | Launch Control |         | Light |             |
15<=X<20 times  ->        |                |         | Light |             |
20>=X    times  ->  FACTORY RESET OF ALL CALIBRATED VALUES

For example, pressing in step 6 the CAL_BUTTON six times, just the Turbo Combo will be deactivated. (Recommendation for Dr!ft, if hardware button is available)
Tip: Reaching the 5, 10 or 15 presses, will be indicated with one longer LED interruption.

5.7.2) Factory Reset
If you push in the last Step the CAL_BUTTON 20x short times or more instead of pressing 1 long press, the calibration values will be reset to factory default. (Normally not necessary)
After a software update normally also the old calibration values will be reused. But if you have problems after a software update, you should do the calibration again.

5.7) Quick Calibration Guide (Optional)
If you only want to calibrate the endstops and the neutral position, here is a quick guide for the calibration: (Please also consider the detailed explanation in chapter 5.1-5.7)
 -0- Long press on the CAL_BUTTON (5 seconds (Can also be 6 seconds, until the led turns on)) to start the calibration routine (LED will be on with blink codes indicating the calibration step (1-6))
 -1- Turn all analog channels to all endstops and return to neutral position. Also switch all digital switches to all positions. After that return to neutral and perform a short press on the CAL_BUTTON
 -2- In the second step just wait a short moment, shake your RC control a little bit without touching the triggers and after that perform a short press on the CAL_BUTTON again to go to the next step
 -3- Just perform a short press on the CAL_BUTTON again to skip this step (Additional symmetric Endstop Deadzone will be set to default)
 -4- Just perform a short press on the CAL_BUTTON again to skip this step (Additional symmetric Neutral Deadzone will be set to default)
 -5- If you also want to calibrate the correct direction of analog channels (optional, but recommended), go once to full throttle and also to full right.
     After that return to neutral position and perform a short press on the CAL_BUTTON again to go to the next step
 -6- In this step you can test all controls (COMBOS are not active in thi step) if everything is ok, leave all analog channels in neutral position and perform a long Press on the CAL_BUTTON (3 seconds)
After that the new calibration values are stored permanently and the LED is going back to normal mode.


6) LED Indication
The software uses beside the power LED the additional onboard LED on ESP32 boards, to indicate multipurpose functions. Some ESP boards only have the power LED.
If you then want to use the LED indication, you need to wire an external LED to one free digital output and set the pin mapping correctly.
->From here on the multipurpose LED will be just called LED.

6.1) Led Indication if no RC-receiver was connected
If no RC-receiver was connected at least once, the LED will be permanently off

6.2) Normal Mode LED behavior, when Bluetooth IS connected
The LED will react with a short blink impulse on each change for all connected channels.
Only if the channels are at the endstops or in the neutral position, the LED is off! As soon as you are out of the neutral position with one channel, the LED will start blinking or constantly be on,
as out of the neutral position there will be always changes detected, as these are at least analog values.
When you are in the neutral position or at the endstop again, no change will be detected anymore, and the LED is off again.
With this feature you can check, if the control box needs to be calibrated (See chapter 5),
because when the LED is flashing/ blinking in the neutral or endstop position, these positions are not well calibrated.
The LED will also show you if there is a change in the state of digital channels (buttons/switches).
But if the digital channels are causing reverse or turbo to be on, will do a cyclic short 1xblink interrupt
By this you can also see, if reverse or turbo are permanently on. So, this is NOT an indication for a needed recalibration.!
In a case when a COMBO is active (See chapter 7), the LED will flash 3 times in between as long as the COMBO is active.

6.3) Normal Mode LED behavior, when Bluetooth is NOT connected
The LED will behave exactly the same as described in 6.1), but in between the LED wil flash 6 times.

6.4) Calibration Mode LED behavior
In the calibration mode, there is no difference whether Bluetooth is connected or not regarding the LED behavior.
The LED will always be on but with a blink code showing you in which calibration step you are. (1 to 6 blinks)
Between the different calibration steps (See chapter 5) the LED will go off for one second, to signalize the transition to the next calibration step.
If the calibration process has finished, the LED will go back to normal mode again.


7) COMBOS - For enhanced or 2 channel control
Combos are actions performed with Throttle/Brake and/or Steering channel to have the possibility to also activate
Launch Control, Turbo Boost or Reverse with only these two channels.
If a combo is active, in the normal mode (when Bluetooth is connected) the LED will behave normally with a 3 times blink interruption.

7.1) Reverse Combo (Toggle between Reverse and Forward)
To activate the reverse combo, you need to perform a 3x "Click" with the brake stick or trigger from neutral (B0) to maximum braking (B100) condition:

Pre Condition: Just leave the brake to neutral (B0). Steering needs also be in neutral position (Max S-20 to S+20)
Perform Combo: B0->B100->B0->B100->B0->B100 -> Reverse will be activated or deactivated (Reverse will toggle after each Combo)
Release Combo: Perform the Combo again, as it will toggle between forward and reverse, but during the combo, steering eeds to be in neutral position.

7.2) Turbo Combo (Activates the Turbo boost)
To activate the turbo combo, you need to go to maximum throttle (T100) and then perform a short double "Click" with the throttle to the Endstop again.
During the double "Click" only perform short movements not going to neutral position so, T80 percent will be perfect as middle position.
Going close to the neutral position again will interrupt this combo!

Pre Condition: Just move the throttle to maximum throttle (T100)
Perform Combo: T100->T80->T100->T80->T100 -> Turbo will be activated and be active as long as you hold the throttle close to T100
Release Combo: Just release the throttle slightly (T80) is enough

Tip: If you are not at the maximum throttle (T100) before starting the combo, you can also do the same combo but as a 3x "click",
as this internally will also recognized as the correct combo.

7.3) Launch Control Combo (Special combination for activating launch control)
To activate the launch control combo, first hold the brake stick or trigger to the maximum position (B100).
While holding this position (B100) perform a 4x "click" with the steering wheel from steering wheel Endstop (S-100) to steering wheel endstop (S+100).
But you can also start with (S+100) if you like it more, as it will be both recognized. After releasing the steering to neutral,
you can use the throttle trigger for launch control. See the following steps for additional information:

Pre Condition: Just push and HOLD the Brake to the maximum endstop (B100)
Perform Combo STEP1: S-100->S+100->S-100->S+100 or S+100->S-100->S+100->S-100 Both combos will be recognized and activate the launch control.
Perform Combo STEP2: Return the steering to neutral again (S0)
Perform Combo STEP3: Now you can go from the maximum brake position (B100) to the maximum throttle position (T100).
                     As launch control is active, the vehicle will not start to drive and you can play with the throttle (But not too much, as it will completely stop launch control again)
Perform Combo STEP4: To be able to start the race with Turbo boost, you need to shortly interrupt the launch control. (This is optional, as you can also directly release the combo)
                     You can do this by steering for a short moment to a steering position out of the neutral position (S-20) or (S+-20) while still holding the throttle. This will start your racer with turbo boost
Release Combo: Just Release the throttle Trigger close to the neutral position (T30) for a short moment. This will finish or stop the complete combo process

7.4) Light Combo  (Toggle)
This Combo is available since v1.6.0. It toggles  the light by simulating a button press.
At first fully press the brake trigger. Then perform a 3 times klick with the steering wheel from neutral steering to right steering endstop.
It is important to always go from steering neutral to right steering maximum.

Pre Condition: Just push and HOLD the Brake to the maximum endstop (B100) (Steering is neutral)
Perform Combo: S0->S+100->S0->S+100->S0->S+100-> After that the light button will be simulated
Release Combo: If steering or brake will be released, the simulated button press is released again

7.5) Motor Start Combo (Toggle)
This Combo is available since v1.6.0. It toggles  starting/stopping the motor.
Do the same as for the light combo, but at the end after finishing this, turn the steering wheel fully to the left, while still pushing the brake.

Pre Condition: Just push and HOLD the Brake to the maximum endstop (B100) (Steering is neutral)
Perform Combo: S0->S+100->S0->S+100->S0->S+100->S-100 After that the motor start button will be simulated (Light will also switch on -> Good for Dr!ft)
Release Combo: If steering or brake will be released, the simulated button press is released again

7.6) Menue Combo  (Toggle, Only Carrera Hybrid)
This Combo is available since v1.6.0. It toggles  the Menue in the race by simulating a button press.
At first fully press the brake trigger. Then perform a 3 times klick with the steering wheel from neutral steering to left steering endstop.
It is important to always go from steering neutral to left steering maximum.

Pre Condition: Just push and HOLD the Brake to the maximum endstop (B100) (Steering is neutral)
Perform Combo: S0->S-100->S0->S-100->S0->S-100-> After that the menue button will be simulated
Release Combo: If steering or brake will be released, the simulated button press is released again

IMPORTANT: As the correct default button can't be simulated, another button is simulated instead. To be able to map this in Carrera Hybrid,
go to the settings, then at first perform the Menu Combo and release it and then click in the app on the button to change this mapping.
When requested to press the key, press the CAL_BUTTON a short time to trigger this button press once.

8) Adapter usage in the Carrera Hybrid App
To use the adapter for example Carrera Hybrid (R) connect the adapter before to your smartphone with Bluetooth.
In the App you need to enable "BRAKE + THROTTLE = REVERSE" (in the app settings) and also set the input mode in the settings to "EXTERNAL GAMEPAD"

Now you are ready to start a Carrera Hybrid (R) race and use any RC control, still having full control over the racer.


9) Credits
Credits go to following people for either creating the external used libraries or for initial idea support:
Mystfit
h2zero
tomstewart89
schnoog

If we forgot someone to mention please let me know, happy to add.
Without their work of them we could not have realized this incredible CH Control Box.


10) License
Our code is released without any kind of restrictions to use it, modify it, or distribute it, as long as the original developers are still mentioned inside the code.

11) Disclaimer
We are not responsible for any kind of damage to hardware or persons using this code.
We also are not responsible for the content of external links written down in these comments.

12) Display edition (Waveshare ESP32-S3-LCD-1.3)
This edition uses the onboard 1.3" display. The control logic is the same as described in chapters 1 to 8.

12.1) Wiring (left pin header from top: 5V, GND, 3V3, IO1, IO2, IO3, IO4, IO5 | right pin header from top: IO14 ... IO8, IO7)
5V  -> + of the RC receiver (only powered when the board is supplied over USB, not from the battery)
GND -> - of the RC receiver
IO4 -> Steering signal | IO3 -> Throttle/Brake signal | IO1 -> Turbo signal | IO2 -> Reverse signal
Optional buttons to GND (no resistor needed): IO5 = CAL (same as BOOT), IO7 = NEXT, IO8 = OK

12.2) Buttons
CAL/BOOT: as described in chapter 5 (the display shows each step, a short instruction and the live values of all channels)
NEXT short: next page (Drive, Channels, Info) | NEXT long: display off | In the menu: NEXT short = next item, NEXT long = previous item
OK short: open the settings menu / change the selected value | OK long: close the menu

12.3) Settings menu
Brightness, screen off time, rotation, mirroring (for the prism case), language (German/English),
combos (same as chapter 5.7.1), combo speed (same as chapter 5.6.4), expo steering and expo throttle (same as chapter 5.7.0).
Combo and expo settings are stored permanently like at the end of a calibration. The menu is blocked during the calibration.

12.4) Switch
"lcd_display_enabled 0" in the section "Display edition" below the pin assignment builds exactly the original behavior with the same pins.

12.5) Battery operation
The 5V pin of the board is connected directly to USB VBUS. It has no power from the battery.
For battery operation: 1S LiPo -> on/off switch -> battery plug of the board (MX1.25, check the polarity!) and in parallel to a 5V step up module.
The 5V module supplies the RC receiver (+ and -). The 5V pin of the board stays free. All GND are connected.
The board has no on/off switch. Charging over the USB-C of the board works only while the switch is on.
"lcd_battery_display 0" hides the battery symbol. "battery_low_sleep 0" disables the deep sleep at empty battery.
"rx_power_hw_pin": optional GPIO to the EN pin of the 5V module (if it has one). High while running, low in deep sleep.

12.6) Bluetooth
With NimBLE-Arduino 2.x the box did not send its name and did not advertise again after a disconnect.
"bt_advertising_fix 1" (default) fixes both. The phone shows the box as "CH Control Box <ID>".

Have fun and good race.
*/



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------- ESP32 Pin Assignment ------------- --> Can be changed by the user to fit your ESP32 board
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Here we define the pins of the ESP 32 Dev board this is Depending
//Different ESP32 Development boards can have different positions/namings of the pins. Normally when you buy these boards, you will also see a snapshot with the pinout
//Here some example boards and how to connect, which were used in build examples:
//[TESTED] Diymore WROOM ESP32 USBC (Used by jogger86 NO ADDITIONAL HARDWARE NEEDED) (VIN(5V), GND, D13, D12, D14, D27 are used and directly next to eachother) --> steering_hw_pin->27 | throttle_brake_hw_pin->14 | turbo_hw_pin->13 | reverse_hw_pin->12 | status_led_hw_pin->2 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->0 | use_usb_controler_support->0 --> In Arduino use "ESP32 Dev Module" board
//[TESTED] XIAO ESP32C3 (Used by mameise) (Like ESP32C3 module from Seeed Studio) (VIN(5V), GND, D2, D3, D4, D5 are used) --> steering_hw_pin->2 | throttle_brake_hw_pin->3 | turbo_hw_pin->4 | reverse_hw_pin->5 | status_led_hw_pin->20 | internal_boot_button_hw_pin->8 | internal_led_is_rgb_led->0 | use_usb_controler_support->0
//[TESTED] Waveshare ESP32-S3 Mini (=ESP32-S3 Supermini) USBC (Used by jogger86 NO ADDITIONAL HARDWARE NEEDED) (VIN(5V), GND, D1, D2, D3, D4 are used and close to eachother) --> steering_hw_pin->4 | throttle_brake_hw_pin->3 | turbo_hw_pin->1 | reverse_hw_pin->2 | status_led_hw_pin->21 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->1 | use_usb_controler_support->1 --> In Arduino use "Waveshare ESP32-S3-Zero" board
//[TESTED] Diymore ESP32 S3 N16R8 USBC (=ESP32 S3 N16R8) (Used by another user NO ADDITIONAL HARDWARE NEEDED) (GND, 5V, D14, D13, D12, D11 are used and close to eachother) --> steering_hw_pin->11 | throttle_brake_hw_pin->12 | turbo_hw_pin->14 | reverse_hw_pin->13 | status_led_hw_pin->48 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->1 | use_usb_controler_support->1 --> In Arduino use "“ESP32S3 Dev Module”" board
//[TESTED] Waveshare ESP32-S3-LCD-1.3 (Display edition, see chapter 12) (5V, GND, GPIO1, GPIO2, GPIO3, GPIO4 on the pin header) --> steering_hw_pin->4 | throttle_brake_hw_pin->3 | turbo_hw_pin->1 | reverse_hw_pin->2 | status_led_hw_pin->15 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->1 | use_usb_controler_support->0 --> In Arduino use "ESP32S3 Dev Module" board, Flash Size 16MB, PSRAM "OPI PSRAM"
#define steering_hw_pin 4//Digital Board Pin connected to the analog steering channel of the RC receiver
#define throttle_brake_hw_pin 3//Digital Board Pin connected to the analog throttle/brake channel of the RC receiver
#define turbo_hw_pin 1//Digital Board Pin connected to the digital channel used for turbo. Can be a butto nor switch of the RC receiver (can also be physically unconnected)
#define reverse_hw_pin 2//Digital Board Pin connected to the digital channel used for reverse setting. Can be a button or switch of the RC receiver (can also be physically unconnected)
#define status_led_hw_pin 15//Digital Board Pin of Onboard LED (Called LED in the documentation) -> A negative Value will invert the LED! (Waveshare ESP32-S3-LCD-1.3: RGB LED on GPIO15)
#define internal_boot_button_hw_pin 0//Digital Board Pin of Onboard boot button (Called CAL_BUTTON in the documentation)

#define internal_led_is_rgb_led 1//If the internal LED is a RGB LED, set this to 1 to get the LED working. Otherwise set to 0!
#define use_usb_controler_support 0//NOT POSSIBLE on the Waveshare ESP32-S3-LCD-1.3 (USB goes over a CH343 chip). Original description: Can only be activated for ESP32 S2 or S3 Boards!!! 0=Not activated (to be used for all other ESP32 boards), 1=USB and BT is activated, 2=Only USB is activated. IMPORTANT: The librarie Joystick_ESP32S2.h needs also be installed to ther Arduino IDE, if not already done!


#define bt_advertising_fix 1//1=Send the Bluetooth name while advertising and advertise again after a disconnect (needed with NimBLE-Arduino 2.x). 0=Original behavior

//------------- Display edition (Waveshare ESP32-S3-LCD-1.3) ------------- --> See chapter 12
#ifndef lcd_display_enabled
#define lcd_display_enabled 1//1=Display, menu and additional buttons are active. 0=Exactly the original behavior (display stays dark)
#endif
#define ext_cal_button_hw_pin 5//Optional external CAL button (to GND), works in parallel to the BOOT button. -1=not used
#define btn_next_hw_pin 7//Optional button NEXT (to GND): next page / next menu item. -1=not used
#define btn_ok_hw_pin 8//Optional button OK (to GND): open menu / change value. -1=not used
#define battery_adc_hw_pin 6//Battery voltage measurement of the board (fixed on the board)
#define battery_divider_factor 2.0//Voltage divider of the battery measurement (board: 100K/100K)
#define lcd_battery_display 1//1=Battery symbol with percent in the status bar and warning when low. 0=off
#define battery_low_sleep 1//1=Deep sleep when the battery is empty (protects the battery). 0=off
#define rx_power_hw_pin -1//Optional: GPIO to the EN pin of the 5V module of the receiver. High while running, low in deep sleep. -1=not used



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Needed libraries to be included at first in the Code (See above links for downloading!!)
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#include <BleConnectionStatus.h>//Don't change anything here
#if use_usb_controler_support>0
#include <Joystick_ESP32S2.h> // Don't change anything here v0.9.5 tested (USB Support only working for ESP32 S2 & S3 Boards)
#endif
#include <BleCompositeHID.h>//Don't change anything here v2.0.0 tested
#include <XboxGamepadDevice.h>//Don't change anything here v0.3.0 tested
#include <Preferences.h>//Don't change anything here
#if lcd_display_enabled
#include "lcd_ui.h"//Display edition. Needs the library LovyanGFX (v1.1.16 tested)
#endif



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Everything below normally don't needs to be changed or touched
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#define bt_device_name "CH Control Box"//"CH Control Box";//Name of the Bluetooth controller in Android or iOS.
#define bt_include_unique_id 1//Automatically include unique ID in the Bluetooth device name (0=Don't include the ID, 1=Include the ID)

#define used_xbox_controler_type 1//Indicates the simulated Bluetooth Xbox controller Type: 1=XboxOneSController (New standard) , 2=XboxSeriesXController (Used in Version before)

#define usb_device_name "CH Control Box USB"//"CH Control Box";//Name of the USB controller in Android or iOS.
#define usb_turbo_key 6//Gamepad Key Number of the USB Gamepad for Turbo
#define usb_reverse_key 7//Gamepad Key Number of the USB Gamepad for Reverse

//Specify if to run in debug mode
#define debug_active_mode 0//0= deactivate, 1= activate in calibration mode (only) if you have problems going through the calibration process, it might benecesarry to deactivate the debug mode

//Specify automatic deep sleep mode -> You can only wake up the system again, if you press the EN button, or repower the ESP. If your calibration is not properly, you might get problems to get into depp sleep mode.
//If set to 0, deep sleep mode is deactivated
#define time_to_deep_sleep_mode 30//Time in minutes, if no input is made and analog chanels are Completely in neutral for this time, deep sleep mode will be entered. If analog channels are not in neutral, but not moved, the detection is also enabled, but the time is increased by 15 minutes
#define time_to_deep_sleep_mode_initial 5//Time in minutes, directly after startup, if no RC receiver was connected to go to deep sleep mode. If it is set to 0, also the initial deep sleep mode detection is deactivated


//Specify the time for the combos (Not the complete combo time, but the time between the transitions) Can be increased or reduced during calibration by +-20%
//-> Not necesarry to be changed, only if you are a slow hand
#define combo_turbo_time 160//Time in miliseconds for the turbo combo between the transitions
#define combo_launch_control_time 290//Time in miliseconds for the launch control combo between the transitions
#define combo_reverse_time 240//Time in miliseconds for the reverse combo between the transitions

//Here you need to define how many steps your your digital switches of your RC controller have (1 step = 2 positions, 2 steps=3positions...)
//If not set correctly, the calibration routine will set the number of steps automatically
#define discrete_initial_button_steps 1 //Initial value for Nr. of steps of all buttons (1 step = 2 positions, 2 steps=3positions...) -> the calibration routine will set the number of steps correctly for each channel

//Initial calibration values for all channels (Can normally left as they are -> Will be set individual for all channels during calibration)
#define pwm_min_init_cal 1000//Initialization calibration for the min delta time (time in microseconds) -> Time were above the minimum is detected, used as initial calibration value for all channels 1000 is in general a good value
#define pwm_max_init_cal 2000//Initialization calibration for the max delta time (time in microseconds) -> Time were above the maximum is detected, used as initial calibration value for all channels 2000 is in general a good value
#define pwm_neutral_min_init_cal 1480//Initialization calibration for the neutral min time (time in microseconds)
#define pwm_neutral_max_init_cal 1520//Initialization calibration for the neutral max time (time in microseconds)

//Fix Deadzone for neutral and endstop position (Will be an additional offset to the time values even after calibration, to ensure to reach the endstop and neutral position)
//-->Normally no need to be changed. Only if the maximum/minimum or neutral can't be reached savely after calibration
#define pwm_minmax_deadzone 15//Min time in microseconds, which is used for PWM detection
#define pwm_neutral_deadzone 10//Max time in microseconds, which is used for PWM detection

//Maximum PWM length: Can normally left as it is. Normal RC PWM is 1000ms to 2000ms with total Length of 20000ms) -> So all valid signals should be in this range
#define pwm_min_time 500//Min time in microseconds, which is used for PWM detection
#define pwm_max_time 3000//Max time in microseconds, which is used for PWM detection

//Xbox Gamepad specific values (Normally no need to be changed)
#define steering_output_max 32767 //Max Value for steering to be send as Xbox Gamepad 32767 is the normal value
#define throttlebrake_output_max 1023 //Max Value for throttle and brake to be send as Xbox Gamepad 1023 is the normal value


//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Everything from here downwards should only be changed if you know what you are doing.
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Definition of own functions or classes
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


//This Class provides a general purpose approach generating timer functions based on the millis() system function. If parametrized, it can also use the micros() function and so all times are in microseconds
//The timer can be a Ton or Tof timer as known form Codesys
//The input is expected as a bool value.
//The outputs of the functions are boolean values, following the input as a Ton or Tof timer by a specified time delay
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class Timer //Class for setting up a TON timer according to the Codesys timer, but with additional features/informations
{
  private://Private Object part with private only access
    bool running=false;//Indication if timer is running
    bool output=false;//Output state of the block. Becomes 1, if the input is true and the et timer is equal to the pt timer
    bool input=false;//Output state of the block. Becomes 1, if the input is true and the et timer is equal to the pt timer
    bool input_rising=false;//Indicates, if the input was rising
    bool input_falling=false;//Indicates, if the input was falling
    bool output_rising=false;//Indicates, if the output was rising
    bool output_falling=false;//Indicates, if the output was falling
    unsigned long et=0;//Elapsed Time of the timer
    volatile unsigned long start_time=0;//Sorage, if the timer block starts running
    volatile unsigned long actual_time=0;//Storage of the actual time for delta calculation
    bool in_last=0;//Last input state
    bool output_last=0;//Last output state
    bool tof_timer=false;//If set to false, the timer will be a TON timer. Otherwise it will be a TOF timer
    bool timer_in_micros=false;//By default the timer is calculated in milliseconds. But if set to true, it is calculated in microseconds

  public://Public Part of the object with public Access

    Timer(bool tof_timer_init,bool last_state_init,bool timer_in_micros_init) //Constructor of the object including variable initialization (Needs at least minimum 1 argument)
    {
      tof_timer=tof_timer_init;
      timer_in_micros=timer_in_micros_init;
      //Initiate the last condition of the block

      in_last=last_state_init;
      output=last_state_init;
      output_last=last_state_init;

      if(tof_timer)//If tof timer is used, invert the states for the timer to be correct
      {
        in_last=!in_last;
        output=!output;
        output_last=!output_last;
      }
    }

    bool calc_timer(bool in, unsigned long pt) //This function needs to be called cyclic to calculate the time difference between actual and last call
    {
      input=in;
      if(tof_timer) //If a TOF timer is set, the input will be inverted to be used a sa TOF timer
      {in=!in;}
      else
      {in=in;}

      //Get Rising and falling edges for the input signal
      input_rising=in_last==false && in==true;
      input_falling=in_last==true && in==false;

      if(timer_in_micros)//By default calculate the time in milliseconds. But otherwise calculate in microseconds, if parametrized in init
      {actual_time=micros();}
      else
      {actual_time=millis();}

      if(input_rising)//If there is a rising edge on the input, start the timer
      {
        start_time=actual_time;//Store the actual time as start time
        running=true;//Set running to true
      }


      if(pt>0 && (actual_time-start_time)<pt && running==true && in==true) //Check, if the timer is running and if input is still true
      {
        et=actual_time-start_time;//Calc the elapsed time. Due to the delta calculation an overflow of the millis timer doesent matter
        output=false;
      }
      else if(in==true)//Last cycle of the timer deactivate the running (if timer was reached)
      {
        output=true;
      }
      else if (in==false)//If input is false, set all variables to init
      {
        et=0;
        running=false;
        output=false;
      }

      if(output==true)//Set the conditions, if the timer has finished
      {
          running=false;//Deactivate the running information
          et=pt;//Set the timer output to the max value
      }

      //Get Rising and falling edges for the output0 signal
      output_rising=output_last==false && output==true;
      output_falling=output_last==true && output==false;

      in_last=in;//Store the last unput condition
      output_last=output;//Store the last output condition


      if(tof_timer) //If a TOF timer is set, the input will be inverted to be used a sa TOF timer
      {return !output;}//Retuzrn the inverted output
      else
      {return output;}//Return the normal output value

    }

    bool get_input()
    {
      {return input;}//Return the normal input value
    }

    bool get_output()
    {
      if(tof_timer) //If a TOF timer is set, the input will be inverted to be used a sa TOF timer
      {return !output;}//Retuzrn the inverted output
      else
      {return output;}//Return the normal output value
    }

    bool get_running()
    {return running;}

    long get_et()//Return elapsed time
    {return et;}

    bool get_input_rising()
    {
      if(tof_timer) //Check which timer was used
      {return input_falling;}//Return the output for TOF timer
      else
      {return input_rising;}//Return the normal output for TON Timer value
    }

    bool get_input_falling()
    {
      if(tof_timer) //Check which timer was used
      {return input_rising;}//Return the output for TOF timer
      else
      {return input_rising;}//Return the normal output for TON Timer value
    }

    bool get_output_rising()
    {
      if(tof_timer) //Check which timer was used
      {return output_falling;}//Return the output for TOF timer
      else
      {return output_rising;}//Return the normal output for TON Timer value
    }

    bool get_output_falling()
    {
      if(tof_timer) //Check which timer was used
      {return output_rising;}//Return the output for TOF timer
      else
      {return output_falling;}//Return the normal output for TON Timer value
    }
    void set_new_timer_mode(bool set_tof_timer)//Overwrite the timer behaviour, if it is an t-on or t-off timer
    {
      tof_timer=set_tof_timer;
    }

}; //End of class definition allways with a semikolon






//This Class provides a general purpose approach for creating a modulated blink timer
//The outputs of the functions are boolean values, showing falling, rising, any or no edges
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class BlinkTimer //Class for detecting rising and/or falling edge of an input signal
{
  private://Private Object part with private only access
    Timer blink_timer;
    bool led_blink_raw=false;
    bool blink_interrupt=false;
    int blink_interrupt_counter=1;

  public://Public Part of the object with public Access


    BlinkTimer(bool dummy) //Constructor of the object including variable initialization
    :blink_timer(false,false,false)
    {
    }

    void calc_blink_timer(long half_cycle_blink_time, int blink_cycles_on, int blink_cycles_off,bool reset_pattern) //This function needs to be called cyclic to observe an input signal to get rising or falling edges
    {
      //half_cycle_blink_time: is the shortest time of one blink impulse to be generated
      //blink_cycles_on: For generating a blink pattern, here you can a number of blinkcycles, where the blink is on
      //blink_cycles_on: After the blink on pattern here you can specify a number of non blink pattern. If you want to blink contnously, you can set this to 0
      //reset_pattern as long as this is true, the blink output will be reset and starting again, as soon, as it becomes true again

      //Calculate a blink timer, which switches the state
      blink_timer.calc_timer(!blink_timer.get_output() && !reset_pattern, half_cycle_blink_time);
      if(led_blink_raw==false && blink_timer.get_output_rising())
      {led_blink_raw=true;}
      else if(led_blink_raw==true && blink_timer.get_output_rising())
      {led_blink_raw=false;}

      if(reset_pattern)
      {blink_interrupt_counter=1;led_blink_raw=true;blink_interrupt=false;}

      blink_cycles_off=2*blink_cycles_off;
      blink_cycles_on=2*blink_cycles_on;
      if(blink_timer.get_output_rising())
      {
        blink_interrupt_counter=blink_interrupt_counter+1;
        if(blink_interrupt_counter>(blink_cycles_on+blink_cycles_off))
        {blink_interrupt_counter=1;}

        if(blink_interrupt_counter<=(blink_cycles_on))
        {blink_interrupt=false;}
        else if(blink_interrupt_counter<=(blink_cycles_on+blink_cycles_off))
        {blink_interrupt=true;}
      }
    }


    bool get_blink_raw()
    {return led_blink_raw;}

    bool get_blink_interrupt()
    {return blink_interrupt;}

    bool get_blink_modulated()
    {return led_blink_raw && !blink_interrupt;}

    bool get_blink_modulated_inverted()
    {return !get_blink_modulated();}
}; //End of class definition allways with a semikolon





//This Class provides a general purpose approach for detecting rising and falling edges
//The input is expected as a long value.
//The outputs of the functions are boolean values, showing falling, rising, any or no edges
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class EdgeDetection //Class for detecting rising and/or falling edge of an input signal
{
  private://Private Object part with private only access
    long last_state = 0;

  public://Public Part of the object with public Access
    bool detect_rising=false;
    bool detect_falling=false;
    bool detect_any=false;

    EdgeDetection(long init_state) //Constructor of the object including variable initialization
    {
      last_state=init_state;
    }

    void calc_edge(long in) //This function needs to be called cyclic to observe an input signal to get rising or falling edges
    {
      if(in!=last_state)
      {
        detect_any=true;//Any edge detected
        if(in>last_state)
        {
          //Rising Edge Detected
          detect_rising=true;
          detect_falling=false;
        }
        else
        {
          //Falling Edge Detected
          detect_rising=false;
          detect_falling=true;
        }
      }
      else
      {
        //No Edge Detected
        detect_rising=false;
        detect_falling=false;
        detect_any=false;
      }

      last_state=in;//Store input value to last value
    }

    bool get_detect_rising()
    {return detect_rising;}

    bool get_detect_falling()
    {return detect_falling;}

    bool get_detect_any()
    {return detect_any;}

    bool get_no_edge()
    {return !detect_any;}

}; //End of class definition allways with a semikolon





//This Class provides purpose for storing a long value inside the ESP32 using the #include <Preferences.h> libary
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class ESP32StoreLong //Class for detecting rising and/or falling edge of an input signal
{
  private://Private Object part with private only access

    Preferences store; //Create object store from class Prefferences (Is a class for the ESP32 to store data permanently)

    bool read_already_performed=false;
    bool enable_esp32_storage=false;
    long output_read=0;
    char s_storage='s';
    char s_key='t';

  public://Public Part of the object with public Access

    ESP32StoreLong(bool set_enable_esp32_storage, char set_s_storage, char set_s_key) //Constructor of the object including variable initialization
    {
      //init_value=set_init_value;
      enable_esp32_storage=set_enable_esp32_storage;
      s_storage=set_s_storage;
      s_key=set_s_key;
    }

    //This function includes a complete esp 32 store process for a long value
    long esp32_store_process_long(int write_case,long write_value,long default_value)
    {
      //write_case: 0=read stored value, but only in the first cycle ; 1=write new value ; 2=reset value to default and read data again
      delete_esp32_storage(write_case==2);//Delete the storage, if the channel master is also doing so
      read_esp32_long(write_case==2,default_value);//Read storage value and force to reread it the channel master is also doing so
      write_esp32_long(write_case==1,write_value);//Write the storage, if the channel master is also doing so

      return get_output_read();
    }

  //This function is designed to write the calibration value of this object and store it permanently into a ESP32. Therefore the libary #include <Preferences.h> needs to be included
    long read_esp32_long(bool force_read,long default_value)
    {
      if(enable_esp32_storage)
      {
        if(!read_already_performed || force_read)
        {
          if(store.isKey(String(s_key).c_str()))//CHeck if all keys exist. In this case just open the storage for reading
          {store.begin(String(s_storage).c_str(), true);}//Open a storage for reading with the number of the channel as a string for example "1", "2", ...
          else//If not all keys exist, open the storage for writing, to allow to create the keys
          {store.begin(String(s_storage).c_str(), false);}//Open a storage for writing with the number of the channel as a string for example "1", "2", ...

          //Here are the actions for reading from the permanent storage and write to this object. If the storage does not exist, the default value will be loaded
          output_read=store.getLong(String(s_key).c_str(), default_value);
          store.end();//Close the storage container again
          read_already_performed=true;

          Serial.print("OPEN STORAGE ");
          Serial.print(String(s_storage).c_str());
          Serial.print(":");
          Serial.print(String(s_key).c_str());
          Serial.print(":");
          Serial.print(output_read);
          Serial.println(" Successful");
        }
      }
      else
      {output_read=default_value;}//Else , if storage is notr used, always use the init value

      return output_read;
    }

    //This function is designed to write a value of this object and store it permanently into a ESP32. Therefore the libary #include <Preferences.h> needs to be included
    long write_esp32_long(bool enable, long StorageValue)
    {
      if(enable_esp32_storage && enable)
      {
        store.begin(String(s_storage).c_str(), false);//Open a storage for writing with the number of the channel as a string for example "1", "2", ...

        //Here are the actions for writing to the permanent storage the actual values of this object
        store.putLong(String(s_key).c_str(), StorageValue);
        store.end();//Close the storage container again
        output_read=StorageValue;

        Serial.print("SAVE STORAGE ");
        Serial.print(String(s_storage).c_str());
        Serial.print(":");
        Serial.print(String(s_key).c_str());
        Serial.print(":");
        Serial.print(StorageValue);
        Serial.println(" Successful ");
      }
      return output_read;
    }

    //This function is designed to delete the content of a namespace of the a ESP32 (The namespace itself will remain). Therefore the libary #include <Preferences.h> needs to be included
    void delete_esp32_storage(bool enable)
    {
      if(enable_esp32_storage && enable)
      {
        store.begin(String(s_storage).c_str(), false);//Open a storage for writing with the number of the channel as a string for example "1", "2", ...

        //Here are all keys from the preference namespace will be cleared. THe namespace itself will not be cleard
        store.clear();
        store.end();//Close the storage container again

        Serial.print("RESET STORAGE ");
        Serial.print(String(s_storage).c_str());
        Serial.println(" Successful");
      }
    }

    long get_output_read()
    {return output_read;}

}; //End of class definition allways with a semikolon







//This Class provides a general purpose approach for using a button or pushbutton as a toogler button with additional external release condition
//It needs to be defined, if the button is a pushbutton or not.
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class ButtonAutoRelease //Class for detecting rising and/or falling edge of an input signal
{
  private://Private Object part with private only access
    bool last_in;//Marker for the last input state
    bool output_state;//Output state to be returned after each cycle
    bool first_cycle=true;//On initialization the fist cycle is true
    bool auto_release_pre_condition_fulfilled=false;//Only if the precondition was fulfilled once, the auto reset will be performed. If you want to disable the pre reset check, set auto_release_pre_condition to true constantly
    bool internal_reset_last;
    long interrupt_counter=0;
    bool interrupt_active=false;

  public://Public Part of the object with public Access

    ButtonAutoRelease(bool dummy) //Constructor of the object including variable initialization
    {

    }

    void calc_auto_release_state(bool in,bool auto_release_pre_condition,bool auto_release_condition,bool bypass_enable, bool button_is_pushbutton, bool internal_reset_edge, bool interrupt_condition, long interrupt_cycles) //This function calculates a toogled output detected by rising or falling edges of an input button. If the auto_release_condition is true, the output will also be reset and is not able to be set
    {
        if(first_cycle)
        {
          last_in=in;//Set last state to the actual state, to not detect any kind of edges at the beginning
          //if(in=true)
          //{
          //  output_state=true;//Set also output to true, if in is true at the first cycle
          //}
        }
        interrupt_active=false;

        if(bypass_enable==false)//If bypass is not enabled, go for the calculation
        {
          if(output_state==false)//Reset the auto release pre condition, if input is false
          {auto_release_pre_condition_fulfilled=false;}
          else if(auto_release_pre_condition)//Set the auto releas epre condition to true
          {auto_release_pre_condition_fulfilled=true;}

          bool edge_detected=(last_in==false && in==true) || (button_is_pushbutton==false && in!=last_in);//Check for an Edge. If a normal button is used, also detect faslling edges
          bool reset_condition=(output_state && edge_detected) || (auto_release_condition && auto_release_pre_condition_fulfilled); //Check the reset condition
          bool set_condition=(!output_state && edge_detected);//Check the set condition

          if(reset_condition || (internal_reset_last==false && internal_reset_edge==true))//At first check the reset condition with higher priority
          {output_state=false;}//Set output to false
          else if(set_condition)//Then check the Set condition
          {output_state=true;}//Set output to high

          //Check if to set a temporary interrupt
          if(!output_state)//Of no output, set interrupt condition to false
          {interrupt_counter=0;}
          else if(interrupt_counter==0 && interrupt_condition)//If output is set, initiate the interrupt counter
          {interrupt_counter=1;}
          else if(interrupt_counter>=1 & interrupt_counter<=interrupt_cycles) //Otherwise count a counter, but limit the counter to not overshoot
          {interrupt_counter=interrupt_counter+1;}

          if(interrupt_counter>=1 && interrupt_counter<=interrupt_cycles)
          {interrupt_active=true;}
          else
          {interrupt_active=false;}

          last_in=in;//Store the last input state
        }
        else
        {output_state=in;}//If the object is not enabled, just the input condition will be bypassed to the oputput

        internal_reset_last=internal_reset_edge;//Store last condition of internal reset
        first_cycle=false;//First cycle was finished in any case
    }

    bool get_output_state_raw()
    {return output_state;}

    bool get_output_state()
    {return (output_state && !interrupt_active);}

    bool get_interrupt_active()
    {return interrupt_active;}

}; //End of class definition allways with a semikolon





//This Class provides a general purpose approach detecting input combination.
//It combines a activation, pre_check, combo(Depending on an input signal, two trigger levels and a combo counter within a specified time) and pre_reset and reset condition for the combo output.
//It works with all input signals provided as long
//The output is a boolean value, which can be used to detect, if the combo was sucsessfully finished.
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class ComboCalc //Class for detecting multiple signals within a time span
{
  private://Private Object part with private only access
    Timer count_tof_timer;//Create an instance of the Timer class used as an off timer
    EdgeDetection hyst_edge;
    long combo_counter=0;
    bool combo_running=false;
    bool output=false;
    bool output_last=false;
    bool output_rising=false;
    bool output_falling=false;
    bool reset_pre_condition_fulfilled=false;
    bool combo_finished=false;
    bool combo_finished_rising=false;
    bool pre_check_finished=false;
    int condition=0;

  public://Public Part of the object with public Access

    ComboCalc(bool dummy_var) //Constructor of the object including variable initialization
    :count_tof_timer(true,false,false),hyst_edge(0)//Add further object initializations to the class constructer. Further objects can be added by seperating with ","
    {
      dummy_var=dummy_var;
    }

    bool combo(bool activate_condition, bool pre_check, long signal_in, long trigger_min, long trigger_max, int start_mode , long max_time_between_pulses, long finish_pulses,bool reset_pre_condition,bool reset_condition,bool toogle_output) //Executes the cyclic combo
    {
      /*
      activate_condition: if set to false, the combo will not be enabled. Can be used as additional condition for the combo. Set this condition to false weill not reset the output condition, if already true!
      pre_check: This Preckeck needs to be fulfilled once, before the combo can start. But to fulfill the prequeck, also the activation condition must be set. If you don't want to use the preckeck, just set it to true
      signal_in: this is the signal used as input for the combo
      trigger_min: this is the min trigger to be used as lower value for counting/detecting the combo
      trigger_max: this is the max trigger to be used as lower value for counting/detecting the combo
      start_mode: 0=Starting the combo on rising or falling edge. 1=starting the combo on rising edge 2 start thje combo on falling edge
      max_time_between_pulses:Max Time between pulses, before the combo will be interrupted and not finished
      finish_pulses: Number of finish pulses to be count before  the combo is finished
      reset_pre_condition: The reset over the reset_condition will only be executed, if the reset pre condition was set to true at leas once after the combo was finished if you dont want to use the precondition, always set it to true
      reset_condition: If the reset condition is set, the combo wil be reset. If always set to true, the combo will be reset directly, after finished
      toogle_output: if set to false, the output will remain true until the reset condition. If set to true, the out output will be true until the reset condition, or will toogle if the combo is detected again
      */

      if(activate_condition && pre_check)//Check if the precheck was fulfilled. But only, if the system was also activated
      {pre_check_finished=true;}

      //Check a hysteresis condition
      long tmp_trigger=trigger_min;
      if(trigger_min>trigger_max)
      {tmp_trigger=trigger_min;trigger_min=trigger_max;trigger_max=tmp_trigger;}


      //int condition=0;
      if(signal_in>=trigger_max)
      {condition=+1;}
      else if(signal_in<=trigger_min)
      {condition=-1;}
      else if(!count_tof_timer.get_running())
      {condition=0;}

      hyst_edge.calc_edge(condition);//Calc Edge on Hysteresis signal

      //Checke Edge condition on the hysteresis value to start or trigger the timer
      bool new_trigger_detected=false;//In general, no new trigger is expected If this signal becomes true, the timer will start running in the NEXT cycle, as it is a Tof Timer
      if(activate_condition && pre_check_finished && condition!=0 && (combo_finished==false || toogle_output))//Without precheck and without condition, don't sart the combo trigger at all
      {
        if(!count_tof_timer.get_running() && hyst_edge.get_detect_rising() && start_mode==1)//Check for starting on rising or any edge mode
        {new_trigger_detected=true;}
        else if(!count_tof_timer.get_running() && hyst_edge.get_detect_falling() && start_mode==2)//Check for starting on falling or any edge mode
        {new_trigger_detected=true;}
        else if(!count_tof_timer.get_running() && hyst_edge.get_detect_any() && start_mode==0)//Check for starting on falling or any edge mode
        {new_trigger_detected=true;}
        else if(count_tof_timer.get_running() && hyst_edge.get_detect_any())//Check counting on any edge, if running
        {new_trigger_detected=true;}
      }


      //Calculate the timer for the combo. As long as the output is high, the combo is active.
      count_tof_timer.calc_timer(new_trigger_detected,max_time_between_pulses);//(edge_detected,max_time_between_pulses)


      if(new_trigger_detected)//If a new trigger was detected, count the combo counter
      {combo_counter=combo_counter+1;combo_running=true;}
      else if(!count_tof_timer.get_running())// Else if combo timer is not running anymore, also reset the counter (Counter will start running one cycle after the trigger was detected)
      {combo_counter=0;combo_running=false;}


      combo_finished_rising=false;
      if(combo_counter>=finish_pulses)
      {
        combo_finished_rising=true;
        combo_finished=true;//Actual combo has finished
        combo_running=false;
        combo_counter=0;//Set the combo counter to 0 again
        if(toogle_output)//If toogle is enabled, toogle the output
        {output=!output;}
        else//If toogle is not enabled, set the output to true
        {output=true;}
      }

      //Check for rising and falling edges of the output
      output_rising=!output_last && output;
      output_falling=output_last && !output;

      output_last=output;//Store the last output


      //Check Reset Pre condition for allowing Rest

      if(reset_pre_condition==true && (combo_finished || toogle_output))
      {reset_pre_condition_fulfilled=true;}
      else if(combo_running)//At combo start or stop, reset the indicator for fulfilled reset pre condition to false
      {reset_pre_condition_fulfilled=false;}//set the request pre condition to false


      //Check Reset Condition:
      if(combo_finished_rising || activate_condition==false || (reset_condition && reset_pre_condition_fulfilled))////If a reset was requestet, and the precondition was fulfilled, allow the reset
      {
        combo_counter=0;// Reset the counter
        combo_running=false;

        //Additional Timer Reset, if it is still running
        if(count_tof_timer.get_running())//If timer is still running, reset the timer, if there was a request on that
        {count_tof_timer.calc_timer(0,0);}// Reset the timer

        if(reset_condition && reset_pre_condition_fulfilled)//If external reset condition is given, reset the output, if necesarry
        {
          combo_finished=false;
          pre_check_finished=false;
          //if(!toogle_output)
          //{output=false;}
          output=false;
        }
      }

      //Can be used for debugging:
      //Serial.println(condition*100000000+hyst_edge.get_detect_rising()*10000000+hyst_edge.get_detect_falling()*1000000+hyst_edge.get_detect_any()*100000+count_tof_timer.get_running()*10000+new_trigger_detected*1000+combo_counter*100+combo_running*10+output);

      return output_last;//Return the output (Will be stored here in the output_last)
    }

    bool get_reset_pre_condition_fulfilled()//Gets information, if reset pre condition was finished
    {return reset_pre_condition_fulfilled;}

    bool get_output()//Gets the combo output condition
    {return output;}

    bool get_combo_finished()//Gets the combo finished condition. Will be true for one cycle
    {return combo_finished;}

    bool get_pre_check_finished()//Gets if the precheck was finshed
    {return pre_check_finished;}

    bool get_combo_running()//Gets if the combo is running
    {return combo_running;}

    bool get_timer_running()
    {return count_tof_timer.get_running();}

    bool get_output_rising()
    {return output_rising;}

    bool get_output_falling()
    {return output_falling;}

    long get_combo_counter()//Gets the combo counter. If the combo counter reaches its maximum, it will already be rerset to 0!
    {return combo_counter;}

    long get_timer_time()//Gets the combo output condition
    {return count_tof_timer.get_et();}

}; //End of class definition allways with a semikolon





//This Class provides a general purpose approach for handling RC receivers. Each Object of this Class can handle one channel
//Each channel can be an analog or discrete channel. The class provides automatic calibration steps to find the total min/max and deadzone min/max values for analog channels and the number of discrete steps of discrete channels
//The Class was written and tested for an ESP32 development board. It uses the #include <Preferences.h> to store calibration data on the ESP32 permanently.
//To be able to us ethe class on other boards, the read_esp32_pref, write_esp32_pref & delete_esp32_pref needs to be replaced. If the "channel_number" is set to negative values, these methods are also not used internally to prevent using permanent storing
//Author: jogger86 for contact go to community.sturmkind.com and contact this user
//Licene: This software is provided as it is. The author don't take anny kind if warrenty. Fell free to use and optimize it for your needs.
class RcReceiverReader //Class for detecting and processing PWM signals from RC receivers using external interrupt routines
{
  private://Private Object part with private only access

    Preferences store; //Create object store from class Prefferences (Is a class for the ESP32 to store data permanently)

    int channel_number=-1;//Number Of the channel to be an identifyer, when printing debug infos. If channel number is negative, the saving of the calibration data on the ESP is deactivated
    volatile int pin_nummer=0; //Arduino Pin Nummer to be checked in the interrupt routine

    //Declare all variables used in the interrupt routine as volatile, to avoid trouble
    volatile unsigned long min_delta_time;//Minimum valid delta time
    volatile unsigned long max_delta_time;//Maximum valid delta time.
    volatile unsigned long valid_delta_time;//Actual valid delta time which was processed

    volatile unsigned long starting_time=0;//Actual measured Time
    volatile unsigned long delta_time=0;//Raw calculated delta time
    volatile bool new_value_cycle=false;//If this flag is true, a new value was comeing this cycle

    unsigned long cal_delta_min_time=0;//Calibration value of the min delta time in use for the mapping
    unsigned long cal_delta_min_time_init=0;//Calibration value of the min delta time in use for the mapping INITIAL VALUE
    unsigned long cal_delta_max_time=0;//Calibration value for the max delta time in use for the mapping
    unsigned long cal_delta_max_time_init=0;//Calibration value for the max delta time in use for the mapping INITIAL VALUE

    unsigned long cal_neutral_min_time=0;//Calibration value for the neutral min time of the PWM signal
    unsigned long cal_neutral_min_time_init=0;//Calibration value for the neutral min time of the PWM signal INITIAL VALUE
    unsigned long cal_neutral_max_time=0;//Calibration value for the neutral max time of the PWM signal
    unsigned long cal_neutral_max_time_init=0;//Calibration value for the neutral max time of the PWM signal INITIAL VALUE

    long endstop_deadzone=0;//Deadzone in us at each side of the end stops (Should normally only be small values, because are added to the calibration as safety margin)
    long endstop_deadzone_init=0;//Deadzone in us at each side of the end stops (Should normally only be small values, because are added to the calibration as safety margin)
    long neutral_deadzone=0;//Deadzone in us at each side of the neutral zone (Should normally only be small values, because are added to the calibration as safety margin)
    long neutral_deadzone_init=0;//Deadzone in us at each side of the neutral zone (Should normally only be small values, because are added to the calibration as safety margin)

    bool channel_inversion=false;//This bool flag invers analogh channel, if set to true. -> Prescaled value and Output value will be inverted
    long maximum_output_value=100;//Value in percent to limit/downscale the maximum output value for analog channels
    long minimum_output_value=0;//Value in percent to limit/downscale the minimum output value for analog channels

    bool discrete_button_is_toogle_button=false;//This value will be set during the calibration only for discrete buttons. If in the second calibration step the corresponding channel button is pressed at least 4 times, the button will afterwards only react on rising edges and outputs a boolean toogle value
    int last_step_cannel_condition=0;//This will be set at the end of the calibration routine. For analog channels it will be set to -2,-1, 0 ,+1, +2 depending if last position is close to minimum, maximum or neutral. For discrete channels, the discrete output will be used
    int use_combos=2;//Normally it is set to 2 (Can be chaned by the calibration routine by pressing the boot button at lest 10 will set it to 1, if pressing at least 15 times, it will set it to 0) (But in any case combos are not part of this object itselfe)

    int additional_channel_option=0;//THis option will be set for analog channels in the calibration step ov the inversion, if the trigger is hold to the in the positive direction before pressing the trigger, it will be set to +1, if it will be hold to the negative direction, it will be set to -1 (slighly is enough-> Can be less then the max input before) otherwithe in neutral it will be set to 0

    long min_output_scale=-32767;//minimum output will be scaled to this value to fit the controller interface if minimum and maximum scalings are set to 0, the output will not be scalled
    long max_output_scale=32767;//maximum output will be scaled to this value to fit the controller interface if minimum and maximum scalings are set to 0, the output will not be scalled
    long output_discretize_steps=0;//If set unequal to 0, the output will be dicretized in equal distant steps (For switches) If you have a 2 poston switch, set to 1. If you have a 3 position switch to 2 and so on.
    long output_discretize_steps_init=0;//If set unequal to 0, the output will be dicretized in equal distant steps (For switches) If you have a 2 poston switch, set to 1. If you have a 3 position switch to 2 and so on. INIT VALUE

    long output_discretize_steps_max_auto=15;//Max number of discretize steps which will be active for the auto matic step number detection during calibration
    long prescaled_max_value=1000;//Max prescale value is set to 1000 (1 per mil)

    long channel_exp_factor=0;//Here we can set a channel exp factor, which is default 0 and so not active. -1000 = very aggressive, 0=linear, +1000= more agressive

    long tmp_storage=0;//Temporary storage to be used during the deadzone calibration
    long tmp_storage_neg=0;//Temporary storage to be used during the deadzone calibration
    long tmp_storage_pos=0;//Temporary storage to be used during the deadzone calibration

    long prescaled_value=0;//Processed prescaled value to be used for sending as a gamepad command
    long prescaled_value_last=0;//Processed LAST prescaled value to be used for sending as a gamepad command
    long prescaled_value_delta=0;//Processed Delta value to the last value. Caqn be used for edge detection or gradients
    int16_t output_value=0;//Processed prescaled value to be used for sending as a gamepad command
    int output_condition=0;//Gives an indication in which range the output is (0=Neutral Zone, 1=Middle Zone, 2=Max Limit)
    bool led_condition=0;//Gives an possible indication for setting the LED for diagnostic purpose
    Timer timer_led;//Create an instance of the Timer class used for the calibration routine

    Timer timer_calibration;//Create an instance of the Timer class used for the calibration routine
    bool calibration_button_state=false;//State of the calibration button to be transmitted to the object
    bool calibration_button_state_last=false;//State of the calibration button to be transmitted to the object
    int cal_step=0;//Actual calibration step
    int cal_step_external=0;//Actual calibration step understandable for external
    bool within_last_test_step=false;//Indicates if we are in the last calibration test step
    int calibration_write_case=0;//0=not in any write cycle, 1=Is into a write cycle, 2=Is into an erase and rewrite cycle
    long timer_longpress_time=5000;//Time in ms to perform a longpress for starting calibration
    long timer_shortpress_time=1;//Time in ms to perform a longpress for starting calibration

    bool activate_debug_mode=false;//Wil be bypassed into this object. If true, some debug information will be displayed in some steps
    unsigned long internal_cycle_task_counter=0;//Internal counter, which counts all cycles and will be reset after a max number
    unsigned long internal_cycle_task_counter_max=2000;//max number for the internal cycle counter (For low priority task like when printing debug infos)
    bool internal_task_cycle_active=false;//If the counter is reaching the maximum, this value will be true for one cycel
    bool debug_print_this_cycle_used=false;//if true, in this cycle a debug info was printed if falso not

    volatile unsigned long last_valid_ms=0;//Display edition: time of the last valid pulse (set in the interrupt routine)
    unsigned long valid_delta_time_last=0;//Last valid delta time which was processed
    unsigned long valid_delta_time_max_delta_abs=0;//Maximum delta between two valid time deltas. Will be used in calibration for discrete channels to automatically set the number of steps

    int valid_delta_time_filter_elements_analog=7;//7 Filtering elements for analog channels (1= no filtering)
    int valid_delta_time_filter_elements_digital=4;//4 Filtering elements for digital channels (1= no filtering)
    unsigned long valid_delta_time_filter;//Filtered value of the time signal
    unsigned long filter_step_deactivation_delta=200;//200 If this time delta is overwound, the filter is overwound in this cycle

    bool enable_esp32_storage=true;//If this is set to true, the calibration values will be automatically stored inside the esp32 (This bool variable will automaticallly be set with the channel_number. If channel number is negative, the ESP saving is deactivated)
    int erase_esp32_counter=0;//This counter will be used at the end of the calibration routine, to check, if the esp32 should be erased instead of storing the values. If 10 shot press were pewrformed, the esp will be erased
    int erase_esp32_counter_last=0;//This counter will be used at the end of the calibration routine, to check, if the esp32 should be erased instead of storing the values. If 10 shot press were pewrformed, the esp will be erased
    bool cycle_led_interrupt=false;//If this is set to true, it will only be true for one cycle. It will be used to show a short interrupt of the LED
    int discrete_button_type_counter=0;//This counter will be increased, by pressing the discrete channel putton in the second calibration step. If the counter reaches 2 (4 button presses needed)
    bool button_toogle_state=false;//Internal storage of the button toogle state
    bool read_already_performed=false;//This flag will be set to true after the first read, to avoid continous read on all cycles

    //This function is designed to write the calibration value of this object and store it permanently into a ESP32. Therefore the libary #include <Preferences.h> needs to be included
    void read_esp32_pref(bool force_read)
    {
      if(enable_esp32_storage)
      {
        if(!read_already_performed || force_read)
        {
          if(store.isKey("1") && store.isKey("2") && store.isKey("3") && store.isKey("4") && store.isKey("5") && store.isKey("6") && store.isKey("7"))//CHeck if all keys exist. In this case just open the storage for reading
          {store.begin(String(channel_number).c_str(), true);}//Open a storage for reading with the number of the channel as a string for example "1", "2", ...
          else//If not all keys exist, open the storage for writing, to allow to create the keys
          {store.begin(String(channel_number).c_str(), false);}//Open a storage for writing with the number of the channel as a string for example "1", "2", ...

          //Here are the actions for reading from the permanent storage and write to this object. If the storage does not exist, the default value will be loaded
          set_cal_delta_min_time(store.getLong("1", cal_delta_min_time_init));
          set_cal_delta_max_time(store.getLong("2", cal_delta_max_time_init));
          set_cal_neutral_min_time(store.getLong("3", cal_neutral_min_time_init));
          set_cal_neutral_max_time(store.getLong("4", cal_neutral_max_time_init));
          set_endstop_deadzone(store.getLong("5", endstop_deadzone_init));
          set_neutral_deadzone(store.getLong("6", neutral_deadzone_init));
          set_output_discretize_steps(store.getLong("7", output_discretize_steps_init));
          set_discrete_button_is_toogle_button(store.getBool("8", false));
          set_last_step_cannel_condition(store.getInt("9", 0));
          set_use_combos(store.getInt("10", 2));
          set_channel_inversion(store.getBool("11", false));
          set_maximum_output_value(store.getLong("12", 100));
          set_additional_channel_option(store.getInt("13", 0));
          set_minimum_output_value(store.getLong("14", 0));
          set_channel_exp_factor(store.getLong("15", 0));

          store.end();//Close the storage container again
          read_already_performed=true;

          Serial.print("OPEN STORAGE ");
          Serial.print(channel_number);
          Serial.println(" Successful");
        }
      }
    }

    //This function is designed to write the calibration value of this object and store it permanently into a ESP32. Therefore the libary #include <Preferences.h> needs to be included
    void write_esp32_pref()
    {
      if(enable_esp32_storage)
      {
        store.begin(String(channel_number).c_str(), false);//Open a storage for writing with the number of the channel as a string for example "1", "2", ...

        //Here are the actions for writing to the permanent storage the actual values of this object
        store.putLong("1", get_cal_delta_min_time());
        store.putLong("2", get_cal_delta_max_time());
        store.putLong("3", get_cal_neutral_min_time());
        store.putLong("4", get_cal_neutral_max_time());
        store.putLong("5", get_endstop_deadzone());
        store.putLong("6", get_neutral_deadzone());
        store.putLong("7", get_output_discretize_steps());
        store.putBool("8", get_discrete_button_is_toogle_button());
        store.putInt("9", get_last_step_cannel_condition());
        store.putInt("10", get_use_combos());
        store.putBool("11", get_channel_inversion());
        store.putLong("12", get_maximum_output_value());
        store.putInt("13", get_additional_channel_option());
        store.putLong("14", get_minimum_output_value());
        store.putLong("15", get_channel_exp_factor());

        store.end();//Close the storage container again

        Serial.print("SAVE STORAGE ");
        Serial.print(channel_number);
        Serial.println(" Successful ");
      }
    }

    //This function is designed to delete the content of a namespace of the a ESP32 (The namespace itself will remain). Therefore the libary #include <Preferences.h> needs to be included
    void delete_esp32_pref()
    {
      if(enable_esp32_storage)
      {
        store.begin(String(channel_number).c_str(), false);//Open a storage for writing with the number of the channel as a string for example "1", "2", ...

        //Here are all keys from the preference namespace will be cleared. THe namespace itself will not be cleard
        store.clear();

        store.end();//Close the storage container again

        Serial.print("RESET STORAGE ");
        Serial.print(channel_number);
        Serial.println(" Successful");
      }
    }

    bool toggle_button()//This function uses the prescaled value to toggel this value on rising edges, if a pushbutton is used
    {
      if(button_toogle_state && prescaled_value_delta>0)//At first check the reset condition with higher priority
      {button_toogle_state=false;}//Set output to false
      else if(!button_toogle_state && prescaled_value_delta>0)//Then check the Set condition
      {button_toogle_state=true;}//Set output to high

      return button_toogle_state;
    }

    unsigned long unsigned_long_abs_delta(unsigned long a, unsigned long b)//Calculates a delta of 2 unsigned long variables
    {
      if(a>=b)
        {return (a-b);}
      else
        {return (b-a);}
    }

    unsigned long filter_valid_delta_time(int filter_elements,unsigned long filter_deactivation_delta)//Calculates an mooving average filter for the time delta value
    {
        if(new_value_cycle)
        {
          if(filter_elements<=1 || (cal_step>0 && within_last_test_step==false))//Don't use the filter
          {
            valid_delta_time_filter=valid_delta_time;
          }
          else
          {
            if((filter_deactivation_delta>0 && unsigned_long_abs_delta(valid_delta_time_filter,valid_delta_time)>filter_deactivation_delta) && (cal_step<=0 || within_last_test_step==true))
            {valid_delta_time_filter=valid_delta_time;}//Bypass the filter, if filter deactivation delta is overwound (Don't bypass the filter in the standard calibration steps)
            else
            {valid_delta_time_filter=(valid_delta_time_filter*(filter_elements-1)+valid_delta_time)/(filter_elements);}//Calculate the filter values
          }
          return valid_delta_time_filter;
        }
    }

    long discretize(long input, long min, long max, long steps) // This function discretizes an input value to a specified range regarding the set steps
    {
      if(steps==0)
      {
        return input;
      }
      else
      {
        long tmp_stepsize=(max-min)/steps;//Calculate the delta between max and min
          if(tmp_stepsize==0)
          {
            return 0;
          }
          else
          {
            return (input-min+tmp_stepsize/2)/tmp_stepsize;//Return discretized value
          }
      }
    }

    void calculate_new_discretize_steps()//If this function can be called after the calibrate_min_max has finished, to calculate the new number of steps (output_discretize_steps) will only be performed, if discretization was enabled
    {
      if(output_discretize_steps>0 && output_discretize_steps<=output_discretize_steps_max_auto)//Calibrate/adopt the discretized output steps, if the number of steps is within this specified range
      {
        if(valid_delta_time_max_delta_abs>0)
        {
          //long tmp_output_discretize_steps=(cal_delta_max_time-cal_delta_min_time)/valid_delta_time_max_delta_abs;//Calculate the number of steps. (Old calculation without rounding up consideration -> obsolete)

          //Calculate the number of steps. If it is ion between, it will us ethe modulo operation to chekc, if it is necesarry to round one step up!
          long tmp_output_discretize_steps_delta=(cal_delta_max_time-cal_delta_min_time);
          long tmp_output_discretize_steps_rest=tmp_output_discretize_steps_delta%valid_delta_time_max_delta_abs;
          long tmp_output_discretize_steps=tmp_output_discretize_steps_delta/valid_delta_time_max_delta_abs;
          if(tmp_output_discretize_steps_rest>(valid_delta_time_max_delta_abs/2))
          {tmp_output_discretize_steps=tmp_output_discretize_steps+1;}

          if(tmp_output_discretize_steps>0 and tmp_output_discretize_steps<=output_discretize_steps_max_auto) //Check, if the calibration value is within the allowed range
          {
            output_discretize_steps=tmp_output_discretize_steps;//If ok, store the new number of discretized steps (In any case only if discretized output was enabled)
          }
        }
      }
    }


    void calculate_last_step_cannel_condition()//THis can be called in the calibration step routrine, to rememer the last condition of the cannels (prescaled values) Analog channels will only decide between -2,-1, 0, +1, +2
    {
        if(output_discretize_steps>0)
        {//In discretized condition just get the last prescaled value from the button
          last_step_cannel_condition=get_prescaled_value();
        }
        else
        {//In analog condition convert the signal to -1 (if prescaled value <85%), +1 (if prescaled value >85%), else, in between
          if(get_prescaled_value()>880)
          {last_step_cannel_condition=2;}
          else if(get_prescaled_value()>300)
          {last_step_cannel_condition=1;}
          else if(get_prescaled_value()<-300)
          {last_step_cannel_condition=-1;}
          else if(get_prescaled_value()<-880)
          {last_step_cannel_condition=-2;}
          else
          {last_step_cannel_condition=0;}
        }
    }

    void calculate_additional_channel_option()//THis can be called in the calibration step routrine, after the inversion check, to get and remember an additional option (-1,0,+1), depending on the last position holing before the button press
    {
        if(output_discretize_steps>0)
        {//In discretized condition just get the last prescaled value from the button
          additional_channel_option=get_prescaled_value();
        }
        else
        {//In analog condition convert the signal to -1 to +1
          if(get_prescaled_value()<10)
          {additional_channel_option=0;}
          else if(get_prescaled_value()<=((maximum_output_value*10)/2))
          {additional_channel_option=-1;}
          else
          {additional_channel_option=+1;}
        }
    }

    void deactivate_neutral_zone_completely(bool condition)//This function deactivates the neutral zone completely and can be called at the end of the calibration routine
    {
      if(output_discretize_steps==0)
      {
        if(condition)
        {
          unsigned long middle_setting=cal_neutral_min_time+(cal_neutral_max_time-cal_neutral_min_time)/2;
          cal_neutral_min_time=middle_setting;
          cal_neutral_max_time=middle_setting;
          endstop_deadzone=0;
          neutral_deadzone=0;
        }
      }

    }

    void calibrate_min_max()//If this function is called cyclic inside this object, the calibration for the min and max pwm time signal value is active and adopted cyclic.
    {
        if(valid_delta_time_filter<cal_delta_min_time || cal_delta_min_time==0)//Check if there is a new min calibration value and store it // Now filtered value is used
        {
          cal_delta_min_time=valid_delta_time_filter;// Now filtered value is used
        }

        if(valid_delta_time_filter>cal_delta_max_time || cal_delta_max_time==0)//Check if there is a new min calibration value and store it // Now filtered value is used
        {
              cal_delta_max_time=valid_delta_time_filter;// Now filtered value is used
        }

      //Calibrate/adopt the discretized output steps (Not for analog channels used), if the number of steps is within this specified range
      if(output_discretize_steps>0 && output_discretize_steps<=output_discretize_steps_max_auto)
      {
        long tmp_min_discretize_step_delta=(cal_delta_max_time_init-cal_delta_min_time_init)/output_discretize_steps_max_auto;//Minimum time delta to be accepted for the calibration of the discretized output
        long tmp_valid_delta_time_difference=0;

        //Calculate the difference between the absolute actual and and last time measurement
        tmp_valid_delta_time_difference=valid_delta_time-valid_delta_time_last;
        tmp_valid_delta_time_difference=abs(tmp_valid_delta_time_difference);

        if((tmp_valid_delta_time_difference>valid_delta_time_max_delta_abs || valid_delta_time_max_delta_abs==0) && tmp_valid_delta_time_difference>=tmp_min_discretize_step_delta)//Check if there is a new max abs delta between this step and the last steps after starting the calibration
        {
          valid_delta_time_max_delta_abs=tmp_valid_delta_time_difference;
        }
      }
    }

    void reset_min_max_calibration()//This function resets the min max calibration values
    {
      maximum_output_value=100;
      minimum_output_value=0;

      cal_delta_min_time=0;
      cal_delta_max_time=0;
      valid_delta_time_max_delta_abs=0;
    }


    void calibrate_neutral()//If this function is called cyclic inside this object, the calibration for the neutal min and max pwm time signal value is active and adopted cyclic.
    {
        if(valid_delta_time_filter<cal_neutral_min_time || cal_neutral_min_time==0)//Check if there is a new min calibration value and store it // Now filtered value is used
        {
          cal_neutral_min_time=valid_delta_time_filter;// Now filtered value is used
        }

        if(valid_delta_time_filter>cal_neutral_max_time || cal_neutral_max_time==0)//Check if there is a new min calibration value and store it // Now filtered value is used
        {
              cal_neutral_max_time=valid_delta_time_filter;// Now filtered value is used
        }

    }

    void calibrate_readopt_min_max()//This functtion can be called ONCE after the min max and neutral calibration, to correct the maximum endstopsa in case the value is jittering a lot
    {
      long tmp_neutral_diff;
      if(cal_neutral_max_time>=cal_neutral_min_time)
        {tmp_neutral_diff=((cal_neutral_max_time-cal_neutral_min_time)*10)/15;}
      else
        {tmp_neutral_diff=((cal_neutral_min_time-cal_neutral_max_time)*10)/15;}

      if (tmp_neutral_diff<0 )
        {tmp_neutral_diff=0;}
      else if(tmp_neutral_diff>10)
        {tmp_neutral_diff=10;}

      cal_delta_min_time=cal_delta_min_time+tmp_neutral_diff;
      cal_delta_max_time=cal_delta_max_time-tmp_neutral_diff;

      if (cal_delta_min_time > cal_neutral_min_time)
        {cal_delta_min_time = cal_neutral_min_time;}

      if (cal_delta_max_time < cal_neutral_max_time)
        {cal_delta_max_time = cal_neutral_max_time;}
    }

    void reset_neutral_calibration()//This function resets the neutral calibration values
    {
      cal_neutral_min_time=0;
      cal_neutral_max_time=0;
    }

    void calibrate_deadzone(int step, int cal_type)//This function calibrates the additional deadzones (Will be set equal for negative and positive side both sites)
    //step: 1=reset temporary value, 2=Get new calibration value, 3=save the temporary value
    //cal_type: 1=calibration for the Endstop deadzone , 2=calibration for the neutral deadzone
    {
      unsigned long general_deadzone_buffer=4;
      if(step==1)
      {
        tmp_storage=0;
        tmp_storage_neg=0;
        tmp_storage_pos=0;
        if(cal_type==1)
        {endstop_deadzone=0;}
        else if(cal_type==2)
        {neutral_deadzone=0;}
      }
      else if(step==2)
      {// Now filtered value is used in this whole case step
        if(valid_delta_time_filter>(cal_delta_min_time+endstop_deadzone_init/2) && valid_delta_time_filter<(cal_neutral_min_time-neutral_deadzone_init/2))//It was a deadzone in the negative area
        {
          if(cal_type==1 && tmp_storage_neg<(cal_neutral_min_time-valid_delta_time_filter))
          {//1=calibration for the Endstop deadzone
            tmp_storage_neg=cal_neutral_min_time-valid_delta_time_filter;//Store the new calibration value temporary
            tmp_storage=max(tmp_storage_pos,tmp_storage_neg);
          }
          else if(cal_type==2 && tmp_storage_neg<(cal_neutral_min_time-valid_delta_time_filter))
          {//2=calibration for the neutral deadzone
            tmp_storage_neg=cal_neutral_min_time-valid_delta_time_filter;//Store the new calibration value temporary
            tmp_storage=max(tmp_storage_pos,tmp_storage_neg);
          }
        }
        else if(valid_delta_time_filter<(cal_delta_max_time-endstop_deadzone_init/2) && valid_delta_time_filter>(cal_neutral_max_time+neutral_deadzone_init/2))//It was a deadzone in the positive area
        {
          if(cal_type==1 && tmp_storage_pos<(valid_delta_time_filter-cal_neutral_max_time))
          {//1=calibration for the Endstop deadzone
            tmp_storage_pos=valid_delta_time_filter-cal_neutral_max_time;//Store the new calibration value temporary
            tmp_storage=max(tmp_storage_pos,tmp_storage_neg);
          }
          else if(cal_type==2 && tmp_storage_pos<(valid_delta_time_filter-cal_neutral_max_time))
          {//2=calibration for the neutral deadzone
            tmp_storage_pos=valid_delta_time_filter-cal_neutral_max_time;//Store the new calibration value temporary
            tmp_storage=max(tmp_storage_pos,tmp_storage_neg);
          }
        }
      }
      else if(step==3)
      {
        if(tmp_storage<=0)
        {
          //Otherwise restore the init value
          if(cal_type==1)
          {endstop_deadzone=endstop_deadzone_init;}
          else if(cal_type==2)
          {neutral_deadzone=neutral_deadzone_init;}
        }
        else if(cal_type==1)
        {
          //1=calibration for the Endstop deadzone
          endstop_deadzone=tmp_storage;
        }
        else if(cal_type==2)
        {
          //2=calibration for the neutral deadzone
          neutral_deadzone=tmp_storage;
        }
      }
    }


    void calibrate_inversion_and_max_output(int step)//This function calibrates if analog channels needs to be inverted
    //step: 1=reset temporary value, 2=Get new calibration value, 3=save the temporary value
    {
      if(step==1)//Reset storage values and channel inversion
      {
        tmp_storage=0;
        tmp_storage_neg=0;
        tmp_storage_pos=0;
        channel_inversion=false;
        maximum_output_value=100;
        minimum_output_value=0;
      }
      else if(step==2 && get_output_discretize_steps()==0)
      {
        //Get the positive and negative maximum input. The direction where the maximum abs value is detected from both will be used as direction for positive output values (throttle, or right steering)

        if(abs(get_prescaled_value())>=80 || (abs(get_prescaled_value())>=20 && (abs(tmp_storage_pos)>0 || abs(tmp_storage_neg)>0)))//Only start the detection, if the prescaled value is larger than 50 (5%) and analog channels are used
        {
          if(get_prescaled_value()>0 && get_prescaled_value()>tmp_storage_pos)//CHeck to tmp store new negative value
          {tmp_storage_pos=get_prescaled_value();}
          else if(get_prescaled_value()<0 && get_prescaled_value()<tmp_storage_neg)//Check to tmp store new positive value
          {tmp_storage_neg=get_prescaled_value();}

          tmp_storage=max(abs(tmp_storage_pos),abs(tmp_storage_neg));
        }
      }
      else if(step==2 && get_output_discretize_steps()>0)
      {
        //Get the positive minimum and maximum values for a digital channel, to see, if there was a input made, to be used to activate inversion
        if(tmp_storage==0)
        {
          tmp_storage=1;
          tmp_storage_pos=get_prescaled_value();
          tmp_storage_neg=tmp_storage_pos;
        }
        if(get_prescaled_value()>tmp_storage_pos)//CHeck to tmp store new min value
        {tmp_storage_pos=get_prescaled_value();}
        else if(get_prescaled_value()<tmp_storage_neg)//Check to tmp store new max value
        {tmp_storage_neg=get_prescaled_value();}
      }
      else if(step==3 && get_output_discretize_steps()==0)//Analog Channels
      {
        if(tmp_storage_neg!=0 || tmp_storage_neg!=0)//If any kind of input was given store new values
        {
          if(abs(tmp_storage_neg)>abs(tmp_storage_pos))//Invert the channel, if the detected negative values are larger than the detected positive values
          {
            channel_inversion=true;//Set channel inversion to true, if negative values are dominating
            if(abs(tmp_storage_pos)>20)//In this case use the positive values, if bigger than an offset, as an minimum output value
            {minimum_output_value=abs(tmp_storage_pos)/10;}
            else
            {minimum_output_value=0;}
          }
          else
          {
            channel_inversion=false;//Set channel inversion to true, if positive values are dominating
            if(abs(tmp_storage_neg)>15)//In this case use the negative values, if bigger than an offset, as an minimum output value
            {minimum_output_value=abs(tmp_storage_neg)/10;}
            else
            {minimum_output_value=0;}
          }
        }

        if(tmp_storage>=80 && tmp_storage<=920)// If the  value is larger 10% and smaller 90%, use the absolute value as output limitation
        {maximum_output_value=tmp_storage/10;}
        else
        {maximum_output_value=100;}//Else seth the output limitation to 10%
      }
      else if(step==3 && get_output_discretize_steps()>0)//Digital channels inversion check
      {
        if(tmp_storage_pos!=tmp_storage_neg)//If the digital channel was touched in the inversion step, invert the digital channel
        {channel_inversion=true;}
        else
        {channel_inversion=false;}
      }
    }


    //This function is called inside a calibration step to be able to specify, if a button should only react on rising edges instead of the state
    void check_button_type_counter(int check_presses)
    {
        if(output_discretize_steps>0 && prescaled_value_delta==1)//Only if there is a discrete channel and if there is a rising edge on this channel, count the counter
        {
          discrete_button_type_counter=discrete_button_type_counter+1;
          if(discrete_button_type_counter>=check_presses)
          {
            discrete_button_is_toogle_button=true;
          }
        }
    }


    int calibration_step_routine()//Routine for performing a calibration step by step
    {
      long timer_used_time=timer_shortpress_time;//Local variable containing the actual used time for the timer in generel expect a short press time. Only in some cases expect a longpress time
      if(cal_step==0)//Initial state. No calibration is active
      {
        timer_used_time=timer_longpress_time;//In general use the longpress timer
        //Wait for the button to start calibration
      }
      else if(cal_step==1) //Print actual configuration
      {
        debug_infos_marker(true);//Force to print the debug infos in thi step
        if(get_debug_print_this_cycle_used())
        {Serial.println("1) CALIBRATION OF ENDSTOPS OF ALL CHANNELS STARTING:");}  // erzeugt einen Tab-Stop
        cal_step_external=cal_step_external+1;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==2)//In this state the calibration of the endstops will be prepared
      {
        channel_exp_factor=0;//Set exp factor to 0 again
        channel_inversion=false;//Also reset channel inversion initially
        reset_min_max_calibration();//Reset the calibration value sto 0
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==3)//In this state a calibration step will be performed
      {
        calibrate_min_max();//Cyclic calibrate the min and max positions, until going to the next step
        //Wait for the button to go to the next step
      }
      else if(cal_step==4)
      {
        calculate_new_discretize_steps();//Calculate and set new number of discretize steps. Will only be performed for discretized channels
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==5) //Print debug after min max calibration
      {
        debug_infos_marker(true);//Force to print the debug infos in this step
        if(get_debug_print_this_cycle_used())
        {Serial.println("2) CALIBRATION OF NEUTRAL ZONE STARTING:");}  // erzeugt einen Tab-Stop
        cal_step_external=cal_step_external+1;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==6)//In this state the neutral calibration of the endstops will be prepared
      {
        reset_neutral_calibration();//Reset the neutral calibration value sto 0
        discrete_button_type_counter=0;
        discrete_button_is_toogle_button=false;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==7)//In this state a calibration step will be performed
      {
        check_button_type_counter(2);//check the button type counter for discrete channels. If these buttons are prerssed at least 4 times at the second calibration step, this channel will react only toogle on rising edges
        calibrate_neutral();//Cyclic calibrate the neutral min and max positions, until going to the next step
        //Wait for the button to go to the next step
      }
      else if(cal_step==8) //Print debug after neutral calibration
      {
        calibrate_readopt_min_max();//In case the value has still some jittering, the maximum value endstops will be corrected here (Only called ONCE)

        debug_infos_marker(true);//Force to print the debug infos in thi step
        if(get_debug_print_this_cycle_used())
        {Serial.println("3) [optional] CALIBRATION OF ANALOG MAXIMUM DEADZONE STARTING:");}  // erzeugt einen Tab-Stop
        cal_step_external=cal_step_external+1;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==9)
      {
        calibrate_deadzone(1,1);//Initiate the deadzone calibration for the endstops
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==10)
      {
        calibrate_deadzone(2,1);//Perform the deadzone calibration for the endstops
        //Wait for the button to go to the next step
      }
      else if(cal_step==11)
      {
        calibrate_deadzone(3,1);//Store the deadzone calibration for the endstop
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==12) //Print debug after calibrating the additional max deadzone
      {
        debug_infos_marker(true);//Force to print the debug infos in thi step
        if(get_debug_print_this_cycle_used())
        {Serial.println("4) [optional] CALIBRATION OF ANALOG NEUTRAL DEADZONE STARTING:");}  // erzeugt einen Tab-Stop
        cal_step_external=cal_step_external+1;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==13)
      {
        calibrate_deadzone(1,2);//Initiate the deadzone calibration for the neutral zone
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==14)
      {
        calibrate_deadzone(2,2);//Perform the deadzone calibration for the neutral zone
        //Wait for the button to go to the next step
      }
      else if(cal_step==15)
      {
        calibrate_deadzone(3,2);//Store the deadzone calibration for the neutral zone
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==16) //Print debug after calibrating the additional neutral deadzone
      {
        debug_infos_marker(true);//Force to print the debug infos in thi step
        if(get_debug_print_this_cycle_used())
        {Serial.println("5) [optional] CALIBRATION OF ANALOG CHANNEL INVERSION STARTING (positive direction expected):");}  // erzeugt einen Tab-Stop
        cal_step_external=cal_step_external+1;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==17)
      {
        //Check if channels need to be inverted
        calibrate_inversion_and_max_output(1);//Reset the output inversion to default
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==18)
      {
        //Check if channels need to be inverted
        calibrate_inversion_and_max_output(2);//Cyclic get the new values, until the button is pressed
        //Wait for the button to go to the next step
      }
      else if(cal_step==19)
      {
        //Take the calibration values for the channel inversion
        calibrate_inversion_and_max_output(3);//Store the new values inside the object
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==20)
      {
         //Take at the end an additional channel option, by pushing analog triggers slightly to + or - direction (Important to calculate after storing the new inversion)
        calculate_additional_channel_option();
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==21) //Print debug after calibrating the additional neutral deadzone
      {
        debug_infos_marker(true);//Force to print the debug infos in thi step
        if(get_debug_print_this_cycle_used())
        {Serial.println("6) TESTING OF THE NEW CALIBRATION AND [optional] SETTINGS AT THE END");}  // erzeugt einen Tab-Stop
        erase_esp32_counter=0;//Reset the erase_esp32_counter to 0 again
        erase_esp32_counter_last=0;
        cal_step_external=cal_step_external+1;
        cal_step=cal_step+1;//Automatically go to the next step without button press
      }
      else if(cal_step==22)
      {
        debug_infos_marker(false);//Print cyclic debug infos, but only in cycles, where this task is active
        timer_used_time=timer_longpress_time/2;//Use the longpress timer to wait a longpress, before storing the data

        //Wait for the long press button to go to the next step, or for 10 short press
        erase_esp32_counter_last=erase_esp32_counter;
        erase_esp32_counter=erase_esp32_counter+timer_calibration.get_input_rising();

        if(output_discretize_steps==0 && within_last_test_step==true && calibration_button_state_last==true && calibration_button_state==false && timer_calibration.get_et()<timer_used_time/2 && timer_calibration.get_output()==false && timer_calibration.get_output_falling()==false)//In case of a press and falling edge in the calibration step, each  && calibration_button_state==false
        {
          long tmp_exp_value_to_write=-get_prescaled_value()*1000/prescaled_max_value;//Use the actual value of the channel as exp factor
          if(channel_exp_factor==0 || tmp_exp_value_to_write!=0)//Only write values, if original value is 0, or new value is not 0
          {channel_exp_factor=tmp_exp_value_to_write;}//Use the actual value of the channel as exp factor
          else if(tmp_exp_value_to_write!=0 && abs(tmp_exp_value_to_write!=0)<50)//At very small values arround 0, but unequal to 0, set value to 0 again
          {channel_exp_factor=0;}//Set exp factor to 0 again
        }

        if(erase_esp32_counter>=15)//If 15 short presses were performed, deactivate the use of combos (Will also be stored permanently)
        {
          set_use_combos(0);//Dont use combos in this case
          if(erase_esp32_counter_last!=erase_esp32_counter && erase_esp32_counter==15)//In this step interrupt the LED for a short moment
          {cycle_led_interrupt=true;}
        }
        else if(erase_esp32_counter>=10)//If 10 short presses were performed, deactivate the use of combos in parts (Will also be stored permanently)
        {
          set_use_combos(1);//Only use a part of the combos in this case
          if(erase_esp32_counter_last!=erase_esp32_counter && erase_esp32_counter==10)//In this step interrupt the LED for a short moment
          {cycle_led_interrupt=true;}
        }
        else if(erase_esp32_counter>=5)//If 5 short presses were performed, deactivate the use of combos in parts (Will also be stored permanently)
        {
          set_use_combos(-1);//Only use a part of the combos in this case
          if(erase_esp32_counter_last!=erase_esp32_counter && erase_esp32_counter==5)//In this step interrupt the LED for a short moment
          {cycle_led_interrupt=true;}
        }
        else
        {
          set_use_combos(2);//Use all kind of combos as default
        }
        //Wait until a long butto npress is performed again

        // OR:
        if(erase_esp32_counter>=21)//If 20 short presses were performed in the last step, erase the stored calibration data on the ESP directly and afterwards go to the write step, to write the init values again to the storage
        {
          last_step_cannel_condition=0;
          delete_esp32_pref();//Delete/Erase ESP32 preferences, if activated
          read_esp32_pref(true);//Force to read the values from the ESP again, to get the default values
          calibration_write_case=2;
          erase_esp32_counter=0;//Reset the erase_esp32_counter to 0 again
          erase_esp32_counter_last=0;
          cal_step=cal_step+1;
        }

        if(calibration_button_state==false && timer_calibration.get_output()==false)
        {within_last_test_step=true;}//Indicate to be in the last test step, after button was released
      }
      else if(cal_step==23)
      {
          calibration_write_case=0;
          calculate_last_step_cannel_condition();//Remember condition of the channels (To be used externally of this object to apply additional serttings after leaving the calibration routine)
          deactivate_neutral_zone_completely(abs(get_last_step_cannel_condition())==1);//In case deactivate the neutral position at the end completely
          cal_step=cal_step+1;
      }

      else if(cal_step==24)
      {
        //If a long press was performed in the step before,
        write_esp32_pref();//Write ESP32 preferences, if activated
        calibration_write_case=1;
        cal_step=cal_step+1;
      }
      else
      {
        calibration_write_case=0;
        cal_step=0;//Reset calibration step to 0
        cal_step_external=0;
        timer_used_time=timer_longpress_time;
        within_last_test_step=false;
      }

      //Use the timer function, to check, if to go to the new step, if the output of the timer is rising
      timer_calibration.calc_timer(calibration_button_state,timer_used_time);
      cal_step=cal_step+timer_calibration.get_output_rising();//Go to the next step, if the output is rising

      return cal_step;
    }


    void debug_infos_marker(bool force_debug_print)//This function can be used, to print cyclic debug infos, only if activated
    {
      debug_print_this_cycle_used=false;
      if(activate_debug_mode && (internal_task_cycle_active || force_debug_print))
      {debug_print_this_cycle_used=true;}
    }


    void calculate_task_cycle()//THis function needs to be called cyclic, to evaluate if we have a task cycle, to perform low priority things as debug print
    {
      //Here a task counter is generated, which activates a task cycle
      internal_task_cycle_active=false;
      internal_cycle_task_counter=internal_cycle_task_counter+1;//Debug cycle counter
      if(internal_cycle_task_counter_max>0 and  internal_cycle_task_counter>=internal_cycle_task_counter_max)//Check, if this cy<cle becomes a debug cycle
      {
        internal_task_cycle_active=true;//This cycle is a debug cycle
        internal_cycle_task_counter=0;//Reset Debug cycle counter
      }
    }


    long exp_factor_curve(long in, long exp_factor,long in_out_min_max)//This function adds an exp value to the prescaled linear signal
    {
    //in is the prescaled input value
    //exp_factor is the exponential factornential value expects exp_factor values from -1000 - +1000 (1000 =100%) -->  -1000 = more agressive, 0=linear, +1000=less agressive
    //in_out_min_max is the minimum and maximum value of the input and output value (for example 500 = -500 .. +500)

      long out;
      if (exp_factor < 0)
      {
        if (in >= 0)
      {out = in_out_min_max - ((abs(exp_factor / 1000.) / pow(in_out_min_max, 2)) * pow(in_out_min_max - abs(in), 3) + (1 - abs(exp_factor / 1000.)) * (in_out_min_max - abs(in)));}
        else
      {out = (abs(exp_factor / 1000.) / pow(in_out_min_max, 2)) * pow(in_out_min_max - abs(in), 3) + (1 - abs(exp_factor / 1000.)) * (in_out_min_max - abs(in)) - in_out_min_max;}
      }
      else
      {
        out = (exp_factor / 1000. / pow(in_out_min_max, 2)) * pow(in, 3) + (1 - exp_factor / 1000.) * in;
      }
      return out;
    }



  public://Public Part of the object with public Access

    //Constructor of the object including variable initialization (Needs at least minimum 1 argument)
    RcReceiverReader(int set_channel_number,byte set_pin_nummer,long set_min_delta_time, long set_max_delta_time,long set_cal_delta_min_time,long set_cal_delta_max_time,long set_cal_neutral_min_time,long set_cal_neutral_max_time,long set_endstop_deadzone,long set_neutral_deadzone, long set_min_output_scale,long set_max_output_scale, long set_output_discretize_steps)
    :timer_calibration(false,false,false),timer_led(true,false,false) //Add further object initializations to the class constructer. Further objects can be added by seperating with ","
    {
      //Do the initialization of the object variables
      channel_number=abs(set_channel_number);
      pin_nummer=abs(set_pin_nummer);
      pinMode(pin_nummer, INPUT_PULLUP);//Set the pin mode, for reading out this pin

      if(set_channel_number<0)//If channel number was set negative, esp32 permanent calibration data saving is deactivated
      {enable_esp32_storage=false;}
      else//If channel number was set positive, esp32 permanent calibration data saving is activated
      {enable_esp32_storage=true;}//true

      min_delta_time=set_min_delta_time;
      max_delta_time=set_max_delta_time;
      cal_delta_min_time=set_cal_delta_min_time;
        cal_delta_min_time_init=set_cal_delta_min_time;
      cal_delta_max_time=set_cal_delta_max_time;
        cal_delta_max_time_init=set_cal_delta_max_time;
      cal_neutral_min_time=set_cal_neutral_min_time;
        cal_neutral_min_time_init=set_cal_neutral_min_time;
      cal_neutral_max_time=set_cal_neutral_max_time;
        cal_neutral_max_time_init=set_cal_neutral_max_time;
      endstop_deadzone=set_endstop_deadzone;
        endstop_deadzone_init=set_endstop_deadzone;
      neutral_deadzone=set_neutral_deadzone;
        neutral_deadzone_init=set_neutral_deadzone;
      min_output_scale=set_min_output_scale;
      max_output_scale=set_max_output_scale;
      output_discretize_steps=set_output_discretize_steps;
        output_discretize_steps_init=set_output_discretize_steps;
    }

    void interrupt_calc() //This function needs to be called inside the interrupt routine to calculate the time difference between actual and last call
    {
      volatile int act_state=digitalRead(pin_nummer);//Read out the pin state directly, to decide later, if it is a rising or falling edge

      if(act_state==1)//It will be a rising edge, as the actual state is high
      {starting_time=micros();}//Start the measurement, when trigger is rising
      else if(act_state==0)//It will be a falling edge, as the actual state is low
      {delta_time=micros()-starting_time;}//End the measurement, when trigger is falling

      if(delta_time>min_delta_time && delta_time<max_delta_time)//Check if the delta time is within the maximum valid range, if so do all calculatios for a new valid value
      {
        //IT IS IMPORTANT TO DO THIS CHECK HERE INSIDE THE INTERRUPT ROUTINE
        valid_delta_time=delta_time;//Store new valid delta time
        last_valid_ms=millis();//Display edition: time of the last valid pulse
        new_value_cycle=true;//Store that a new value is in this cycle
      }
    }


    //Object interfaces
    bool perform_cyclic_calculation(bool led_status_passthrough, bool calibration_button_state_in,bool activate_debug_mode_in)//This function performs the cyclic calculation for the time (led_status_passthrough can be a variable to passthrough, if multible instances are used from this object to get one general LED status)
    {
      cycle_led_interrupt=false;
      calibration_button_state_last=calibration_button_state;
      calibration_button_state=calibration_button_state_in;//Store the button state inside the object
      debug_print_this_cycle_used=false;
      calculate_task_cycle();
      activate_debug_mode=activate_debug_mode_in;

      read_esp32_pref(false);//Read ESP32 preferences, if activated, don't force the read, to only read the ESP data the first cycle

      prescaled_value_last=prescaled_value;//Store the last prescaled value, to be able to perform an edge detection

      if(output_discretize_steps==0)
      {
        //Dont discretize the output -> For analog triggers etc.

        output_condition=0;
        filter_valid_delta_time(valid_delta_time_filter_elements_analog,filter_step_deactivation_delta);
        prescaled_value=valid_delta_time_filter;
        //Check the output condition and calculate the prescaled value for this condition
        if (prescaled_value<(cal_delta_min_time+endstop_deadzone))//Here we are in the negative minimum deadzone
        {
          output_condition=2;
          prescaled_value=-prescaled_max_value;
        }
        else if(prescaled_value>(cal_delta_max_time-endstop_deadzone))//Here we are in the positive maximum deadzone
        {
            output_condition=2;
            prescaled_value=prescaled_max_value;
        }
        else if(prescaled_value<(cal_neutral_min_time-neutral_deadzone))//Here we are in the normal "negative" area
        {
            output_condition=1;
            prescaled_value=map(prescaled_value, (cal_delta_min_time+endstop_deadzone), (cal_neutral_min_time-neutral_deadzone), -prescaled_max_value, 0);//Interpolate the value in  a linear function (map) on the time range
        }
        else if(prescaled_value>(cal_neutral_max_time+neutral_deadzone))//Here we are in the normal "positive" area
        {
            output_condition=1;
            prescaled_value=map(prescaled_value, (cal_neutral_max_time+neutral_deadzone), (cal_delta_max_time-endstop_deadzone), 0, prescaled_max_value);//Interpolate the value in  a linear function (map) on the time range
        }
        else//Here we are in the neutral zone --> Value is alwys 0
        {
          output_condition=0;
          led_condition=0;
          prescaled_value=0;
        }

        prescaled_value = constrain(prescaled_value,-prescaled_max_value,prescaled_max_value);//Limit the boundaries, to not exceed the values due to the interpolation (map) function (Just for safety)
        prescaled_value_delta=prescaled_value-prescaled_value_last;//Calc the delta value from the old value to the newvalue which can be used for edge detection

        output_value=prescaled_value;//At first assume output value is the prescaled value
        if (min_output_scale!=0 || max_output_scale!=0)//Only Scale the output value, if the scalings are set unequal to zero. Otherwise just use the prescaled value
        {
          long min_output_tmp=min_output_scale;
          long max_output_tmp=max_output_scale;
          if(maximum_output_value<100)//Calculate new effective limited output values (Only for analog channels used)
          {
            min_output_tmp=(min_output_tmp*maximum_output_value)/100;
            max_output_tmp=(max_output_tmp*maximum_output_value)/100;
          }

          long min_offset_output_tmp=0;
          long max_offset_output_tmp=0;
          if(minimum_output_value>0)//Calculate new effective limited output values (Only for analog channels used)
          {
            min_offset_output_tmp=(min_output_scale*minimum_output_value)/100;
            max_offset_output_tmp=(max_output_scale*minimum_output_value)/100;
          }


          //Here with the tmp_prescaled_for_exp an exp function can be added, which at the end will only apply on the output value and not on the prescaled value itself
           long tmp_prescaled_for_exp;
           if(channel_exp_factor==0)//If exp factor is not set, also don't apply it, as it consumes a lot of calculation power
           {tmp_prescaled_for_exp=prescaled_value;}
           else
           {tmp_prescaled_for_exp=exp_factor_curve(prescaled_value,channel_exp_factor,prescaled_max_value);}//Calculate the exp curve

          if(prescaled_value==0)
          {output_value=0;}
          else if(prescaled_value>0)
          {output_value=map(tmp_prescaled_for_exp, 0, prescaled_max_value, max_offset_output_tmp, max_output_tmp);}//Interpolate the value in  a linear function (map),
          else
          {output_value=map(tmp_prescaled_for_exp, -prescaled_max_value, 0, min_output_tmp, min_offset_output_tmp);}//Interpolate the value in  a linear function (map),

          output_value = constrain(output_value,min_output_tmp,max_output_tmp);//Limit the output boundaries, to not exceed the values due to the interpolation (map) function
        }
      }
      else
      {
        //Discretize the output (Signal will be devided in fix steps (1 step are 2 states, 2 steps are 3 states...))

        filter_valid_delta_time(valid_delta_time_filter_elements_digital,filter_step_deactivation_delta);
        prescaled_value=discretize(valid_delta_time_filter,cal_delta_min_time,cal_delta_max_time,output_discretize_steps);//Discretize the output -> prescaled shows normally 0,1,2,.. etc
        prescaled_value_delta=prescaled_value-prescaled_value_last;//Calc the delta value from the old value to the newvalue which can be used for edge detection
        toggle_button();//Use an internal state to calculate a toogle state of the pushbutton

        if(discrete_button_is_toogle_button)
        {output_value=button_toogle_state;}//If the button is set as a pushbuttpn use the toogle state instead of the normal state for output (Output will only switch between low and high on rising edges)
        else
        {output_value=prescaled_value;}//Otherwise At first assume output value is the prescaled value}

        if (min_output_scale!=0 || max_output_scale!=0)//Only Scale the output value, if the scalings are set unequal to zero. Otherwise just use the prescaled value
        {
          output_value=map(prescaled_value, 0, output_discretize_steps, min_output_scale, max_output_scale);//Interpolate the value in  a linear function (map), but only at the discretized steps
          output_value = constrain(output_value,min_output_scale,max_output_scale);//Limit the output boundaries, to not exceed the values due to the interpolation (map) function
        }

        output_condition=(prescaled_value_delta!=0);//If there is a rising or falling edge, set the output condition
      }

      calibration_step_routine();//In case if the calibration is activated with the button, the calibration routine will perferm the calibration step by step
      valid_delta_time_last=valid_delta_time;//Store the last valid time delta, which doesen't contains any kind of othe rcalculations


      if (cal_step==0)//Calculate the LED state for the normal operation
      {led_condition=timer_led.calc_timer((prescaled_value_delta!=0 || led_status_passthrough),15);}
      else//Calculate the LED in case of calibration operation
      {led_condition=!timer_led.calc_timer(timer_calibration.get_output_rising() || cycle_led_interrupt,1000);}

      new_value_cycle=false;//Reset to false that no new value is expected at first for the next cycle

      return led_condition;
    }

    void print_debug_infos()//This function can be used, to print debug infos for one channel
    {
      Serial.print("\t|Nr");  // erzeugt einen Tab-Stop
      Serial.print(get_channel_number());  // Ausgabe Sensorwert
      Serial.print("\t");  // erzeugt einen Tab-Stop
      Serial.print(get_delta_time());  // Ausgabe Sensorwert
      Serial.print("\t");  // erzeugt einen Tab-Stop
      Serial.print(get_cal_delta_min_time());  // Ausgabe Sensorwert
      Serial.print("\t");  // erzeugt einen Tab-Stop
      Serial.print(get_cal_delta_max_time());  // Ausgabe Sensorwert
      if(output_discretize_steps==0)
      {//Output for analog channels
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_cal_neutral_min_time());  // Ausgabe Sensorwert
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_cal_neutral_max_time());  // Ausgabe Sensorwert
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_neutral_deadzone());  // Ausgabe Sensorwert
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_endstop_deadzone());  // Ausgabe Sensorwert
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_prescaled_value());  // Ausgabe Sensorwert
      }
      else
      {//Output for discretized channels
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_output_discretize_steps());  // Ausgabe Sensorwert
        Serial.print("\t");  // erzeugt einen Tab-Stop
        Serial.print(get_output_value());  // Ausgabe Sensorwert
        //Serial.print("\t");  // erzeugt einen Tab-Stop
        //Serial.print(channel_inversion);  // Ausgabe Sensorwert
      }
    }

    void print_initial_general_debug_infos()//Print additional debug infos to the console explaining the output of the "normal debug infos"
    {
      Serial.println("General infos for the CH Control Box in Debug Mode (Is active, when in calibration mode)");
      Serial.println("Abbreviations in debug mode (Will not equal to your channel numbers):");
      Serial.println("(Nr1)Steering [Analog], (Nr2)Throttle/Brake [Analog], (Nr3)Turbo boost [Digital] & (Nr4)Reverse [Digital]");
      Serial.println("");
      Serial.println("Column content for [Analog] channels:");
      Serial.println("1: Name/Nr.");
      Serial.println("2: Actual measured PWM value (microseconds)");
      Serial.println("3: Actual calibration setting for the minimum endstop (microseconds)");
      Serial.println("4: Actual calibration setting for the maximum endstop (microseconds)");
      Serial.println("5: Actual calibration setting for the minimum neutal position (microseconds)");
      Serial.println("6: Actual calibration setting for the maximum neutal position (microseconds)");
      Serial.println("7: Actual calibration setting for the additional symmetric min/max deadzone (microseconds)");
      Serial.println("8: Actual calibration setting for the additional symmetric neutral deadzone (microseconds)");
      Serial.println("9: Actual calculated output signal (-1000 to +1000)");
      Serial.println("");
      Serial.println("Column content for [Digital] channels (Buttons/Switches):");
      Serial.println("1: Name/Nr.");
      Serial.println("2: Actual measured PWM value (microseconds)");
      Serial.println("3: Actual calibration setting for the minimum button/switch signal (microseconds)");
      Serial.println("4: Actual calibration setting for the maximum button/switch signal (microseconds)");
      Serial.println("5: Actual calibrationdiscrete channel number of steps (1 Step=2Positions...)");
      Serial.println("6: Actual calculated discrete channel output");
      Serial.println("");
      Serial.println("If you want to go through the calibration process, push the asigned boot button at the end of each step.");
    }

    bool get_signal_ok()//Display edition: true, if valid pulses arrived within the last 300 ms
    {return valid_delta_time>0 && (millis()-last_valid_ms)<300;}

    int get_cal_short_presses()//Display edition: number of short CAL presses in the last calibration step
    {return erase_esp32_counter;}

    void save_settings()//Display edition: store the actual settings of this channel permanently (same as at the end of the calibration)
    {write_esp32_pref();}

    bool get_channel_connected_once()//Get the information, if the channel is connected and received a valid value
    {return valid_delta_time>0;}

    int16_t get_output_value()//Returns the output value to be used for sending as a gamepad command
    {
      if(channel_inversion)
      {
        if(output_discretize_steps>0 && min_output_scale==0 && max_output_scale==0)
        {return output_discretize_steps-output_value;}//For digital channels, if also no scaling on the digital channel was used
        else
        {return -output_value;}//For analog channels
      }
      else
      {return output_value;}
    }

    int16_t get_output_value_processed(int16_t neutral_permille_tol, int16_t max_permille_tol)//Returns the output processed and safe Cut by a max and min permille
    {
      int16_t tmp_out;
      if(output_value>=0)
      {
        if(neutral_permille_tol>0 && output_value<(max_output_scale/1000)*neutral_permille_tol)
        {tmp_out=0;}
        else if(max_permille_tol<1000 && output_value>(max_output_scale-(max_output_scale/1000)*max_permille_tol))
        {tmp_out=max_output_scale;}
        else
        {tmp_out=output_value;}
      }
      else
      {
        if(neutral_permille_tol>0 && output_value>-(max_output_scale/1000)*neutral_permille_tol)
        {tmp_out=0;}
        else if(max_permille_tol<1000 && output_value<-(max_output_scale-(max_output_scale/1000)*max_permille_tol))
        {tmp_out=min_output_scale;}
        else
        {tmp_out=output_value;}
      }

      if(channel_inversion)
      {return -tmp_out;}
      else
      {return tmp_out;}
    }

    long get_prescaled_value()//Returns the prescaled output value to be used for sending as a gamepad command
    {
      if(channel_inversion)
      {
        if(output_discretize_steps>0)
        {return output_discretize_steps-prescaled_value;}//For digital channels
        else
        {return -prescaled_value;}//For analog channels
      }
      else
      {return prescaled_value;}//If not inverted
    }

    long get_prescaled_value_delta()//Returns the prescaled delta value to be used for sending as a gamepad command (For digital channels this is already after discretization)
    {
      if(channel_inversion)
      {return -prescaled_value_delta;}
      else
      {return prescaled_value_delta;}
    }

    bool get_channel_is_active()//Check, if the channel is active/used -> Is depending on the calibration values
    {
      if(cal_delta_min_time<=min_delta_time/2 && cal_delta_max_time<=min_delta_time/2)//if the calibration values are are much smaller, than the expected minimum, this channel is expected to be not active
      {return false;}
      else
      {return true;}
    }

    bool get_channel_inversion()//Returns if the channel needs to be inverted
    {return channel_inversion;}

    long get_maximum_output_value()//Returns if the maximum output value in percent
    {return maximum_output_value;}

    long get_minimum_output_value()//Returns if the minimum output value in percent
    {return minimum_output_value;}

    long get_delta_time()//This function gets the processed deltatime
    {return valid_delta_time;}

    long get_delta_time_raw()//This function gets the deltatime, without limitation
    {return delta_time;}

    bool get_led_condition()//This function returns the LED condition for this object.
    {return led_condition;}

    int get_cal_step()//This function returns the actual calibration routine step. 0 means calibration routine is not active
    {return cal_step;}

    int get_cal_step_external()//This function returns the actual calibration routine step in a same way as the end user would expect it
    {return cal_step_external;}

    int get_calibration_write_case()//This function returns the actual write case 0=not in any write cycle, 1=Is into a write cycle, 2=Is into an erase and rewrite cycle
    {return calibration_write_case;}

    int get_channel_number()//This function returns the actual channel/interruptz number
    {return channel_number;}

    long get_cal_delta_min_time()//This function returns a calibration value
    {return cal_delta_min_time;}

    long get_cal_delta_max_time()//This function returns a calibration value
    {return cal_delta_max_time;}

    long get_cal_neutral_min_time()//This function returns a calibration value
    {return cal_neutral_min_time;}

    long get_cal_neutral_max_time()//This function returns a calibration value
    {return cal_neutral_max_time;}

    long get_endstop_deadzone()//This function returns a calibration value
    {return endstop_deadzone;}

    long get_neutral_deadzone()//This function returns a calibration value
    {return neutral_deadzone;}

     long get_output_discretize_steps()//This function gets the actual number of set discretize steps
    {return output_discretize_steps;}

    bool get_debug_print_this_cycle_used()//This function returns, if this cycle a debug print was used
    {return debug_print_this_cycle_used;}

    bool get_internal_task_cycle_active()//Get if this cycle was a task cycle
    {return internal_task_cycle_active;}

    long get_min_output_scale()//Get min output scale
    {return min_output_scale;}

    long get_max_output_scale()//Get max output scale
    {return max_output_scale;}

    int get_last_step_cannel_condition()//Get last Step channel condition
    {return last_step_cannel_condition;}

    int get_additional_channel_option()//Get additional channel option
    {return additional_channel_option;}

    bool get_discrete_button_is_toogle_button()//Get last Step channel condition
    {return discrete_button_is_toogle_button;}

    int get_use_combos()//Get if combos should be used
    {return use_combos;}

    bool get_button_toogle_state()//Get pushbutton toogle state
    {return button_toogle_state;}

    long get_channel_exp_factor()//This function returns the exp factor
    {return channel_exp_factor;}

    void set_cal_delta_min_time(long new_cal_value)//This function sets a calibration value
    {cal_delta_min_time=new_cal_value;}

    void set_cal_delta_max_time(long new_cal_value)//This function sets a calibration value
    {cal_delta_max_time=new_cal_value;}

    void set_cal_neutral_min_time(long new_cal_value)//This function sets a calibration value
    {cal_neutral_min_time=new_cal_value;}

    void set_cal_neutral_max_time(long new_cal_value)//This function sets a calibration value
    {cal_neutral_max_time=new_cal_value;}

    void set_endstop_deadzone(long new_cal_value)//This function sets a calibration value
    {endstop_deadzone=new_cal_value;}

    void set_neutral_deadzone(long new_cal_value)//This function sets a calibration value
    {neutral_deadzone=new_cal_value;}

    void set_output_discretize_steps(long new_cal_value)//This function sets a calibration value
    {output_discretize_steps=new_cal_value;}

    void set_last_step_cannel_condition(int new_value)//Set last Step channel condition
    {last_step_cannel_condition=new_value;}

    void set_additional_channel_option(int new_value)//Set new additional channel option
    {additional_channel_option=new_value;}

    void set_discrete_button_is_toogle_button(bool new_value)
    {discrete_button_is_toogle_button=new_value;}

    void set_use_combos(int new_value)
    {use_combos=new_value;}

    void set_channel_inversion(bool new_value)
    {channel_inversion=new_value;}

    void set_maximum_output_value(long new_value)
    {maximum_output_value=new_value;}

    void set_minimum_output_value(long new_value)
    {minimum_output_value=new_value;}

    void set_channel_exp_factor(long new_value)
    {channel_exp_factor=new_value;}

}; //End of class definition allways with a semikolon







//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------ Define, Create and initiate necesarry objects ------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//Startup for BT Librarie
#define bt_device_creator "mameise and jogger86"//Creators and designers of the adapter software
XboxGamepadDevice *gamepad;
BleCompositeHID compositeHID(bt_device_name, bt_device_creator, 100);

//Startup for USB Librarie New
#if use_usb_controler_support>0
Joystick_ Joystick(JOYSTICK_DEFAULT_REPORT_ID,
    JOYSTICK_TYPE_GAMEPAD, 15, 2,
    true, false, false, false, false, false,
    false, false, true, true, false);
#endif


//Create the objects for the time calculation for each channel
//In the folowing code the interrupt routines are attached to te channels as following: (ir1)Steering, (ir2)Throttle/Brake, (ir3)Turbo boost & (ir4)Reverse (This is only for interest for Developers)
RcReceiverReader ir1(1,steering_hw_pin,pwm_min_time,pwm_max_time,pwm_min_init_cal,pwm_max_init_cal,pwm_neutral_min_init_cal,pwm_neutral_max_init_cal,pwm_minmax_deadzone,pwm_neutral_deadzone,-steering_output_max,steering_output_max,0);//Channel object and interrupt handler for -Steering channel-
RcReceiverReader ir2(2,throttle_brake_hw_pin,pwm_min_time,pwm_max_time,pwm_min_init_cal,pwm_max_init_cal,pwm_neutral_min_init_cal,pwm_neutral_max_init_cal,pwm_minmax_deadzone,pwm_neutral_deadzone,-throttlebrake_output_max,throttlebrake_output_max,0);//Channel object and interrupt handler for -Throttle/Brake channel-
RcReceiverReader ir3(3,turbo_hw_pin,pwm_min_time,pwm_max_time,pwm_min_init_cal,pwm_max_init_cal,pwm_neutral_min_init_cal,pwm_neutral_max_init_cal,pwm_minmax_deadzone,pwm_neutral_deadzone,0,0,discrete_initial_button_steps);//Channel object and interrupt handler for -Turbo channel-
RcReceiverReader ir4(4,reverse_hw_pin,pwm_min_time,pwm_max_time,pwm_min_init_cal,pwm_max_init_cal,pwm_neutral_min_init_cal,pwm_neutral_max_init_cal,pwm_minmax_deadzone,pwm_neutral_deadzone,0,0,discrete_initial_button_steps);//Channel object and interrupt handler for -Reverse channel-


//Create objects for Combos and other postprocessing purpose
ComboCalc combo_turbo(0);
ComboCalc combo_launch_control(0);
ComboCalc combo_reverse(0);
ComboCalc combo_light(0);
ComboCalc combo_motorstart(0);
ComboCalc combo_menue(0);
ButtonAutoRelease turbo_button_auto_release(0);
BlinkTimer led_blink_timer(0);
Timer sleep_timer(false,false,false);
Timer launch_control_interrupt_timer(false,false,false);//Create a timer in case of launch control interrupt
Timer bt_not_connected_timer(false,false,false);//Create a timer in case of BT is not connected
Timer reverse_press_timer(true,false,false);

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------ Define interrupt routines ------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//--> These routines are attached to the interrupts for each chanel and executing the objects for the time calculation
void interrupt_ir1()
{ir1.interrupt_calc();}

void interrupt_ir2()
{ir2.interrupt_calc();}

void interrupt_ir3()
{ir3.interrupt_calc();}

void interrupt_ir4()
{ir4.interrupt_calc();}


//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------ Setup part of the software, which will be called once after startup ------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
void setup()
{
  Serial.begin(9600);//Hardware Initialization

  //Setup additional Hardware In-& Outputs
  pinMode(abs(status_led_hw_pin), OUTPUT);
  pinMode(internal_boot_button_hw_pin,INPUT);//Initialize the internal Boot Button as a normal button (Can be used in Software, after board is booted up)

  //Attach the interrupts for the PWM Inputs for getting the values from the RC receiver
  attachInterrupt(digitalPinToInterrupt(steering_hw_pin), interrupt_ir1, CHANGE);
  attachInterrupt(digitalPinToInterrupt(throttle_brake_hw_pin), interrupt_ir2, CHANGE);
  attachInterrupt(digitalPinToInterrupt(turbo_hw_pin), interrupt_ir3, CHANGE);
  attachInterrupt(digitalPinToInterrupt(reverse_hw_pin), interrupt_ir4, CHANGE);

//Bluetooth and XBOX Gamepad initialization (Use pre compiler else & if, to exclude not used option from source code. Otherwise it will not work correctly)
  #if used_xbox_controler_type==1
  XboxOneSControllerDeviceConfiguration* config = new XboxOneSControllerDeviceConfiguration();
  #else
  XboxSeriesXControllerDeviceConfiguration* config = new XboxSeriesXControllerDeviceConfiguration();
  #endif

  //XboxSeriesXControllerDeviceConfiguration* config = new XboxSeriesXControllerDeviceConfiguration();
  //XboxOneSControllerDeviceConfiguration* config = new XboxOneSControllerDeviceConfiguration();
  BLEHostConfiguration hostConfig = config->getIdealHostConfiguration();

  gamepad = new XboxGamepadDevice(config);

  //Calculate an individual device name and overwrite the setting
  uint32_t low     = ESP.getEfuseMac() & 0xFFFFFFFF; //Get low part of the mac adress (Vendor specific part, equal at identical chips -> will not be used in this code)
  uint32_t high    = ( ESP.getEfuseMac() >> 32 ) % 0xFFFFFFFF;//Unique id for one vendor. Normally enough to avoid a conflict -> Will be used here as unique ID
  std::string str_prefix = bt_device_name;
  std::string str_spacer = " ";
  if(bt_include_unique_id)
  {compositeHID.deviceName=str_prefix+str_spacer+String(high).c_str();}//Change the name of the BT device and include the unique ID

  #if use_usb_controler_support<2
  compositeHID.addDevice(gamepad);
  compositeHID.begin(hostConfig);
     //Work arround to avoid problems with the Bluetooth class for setting this stick to invalid initial values for analog sticks
    gamepad->setLeftThumb(1,1);//Set Left thumb stick to a value unequal to 0
    gamepad->setLeftThumb(0, 0);//Set Left thumb stick to a value to 0
    gamepad->setRightThumb(1,1);//Set Right thumb stick to a value unequal to 0
    gamepad->setRightThumb(0,0);//Set Right thumb stick to a value to 0
    gamepad->sendGamepadReport();
  #endif

  #if use_usb_controler_support>0
  //Setup for USB joystik New
  USB.PID(0x8211);
  USB.VID(0x303b);
  USB.productName(usb_device_name);
  USB.manufacturerName(bt_device_creator);
  USB.begin();
  Joystick.setXAxisRange(-steering_output_max, steering_output_max);
  Joystick.setAcceleratorRange(0, throttlebrake_output_max);
  Joystick.setBrakeRange(0, throttlebrake_output_max);
  Joystick.begin(true);
  #endif

  //setCpuFrequencyMhz(240); Change CPU Frequency 240, 160, 80 <<< For all types of XTAL crystal available on ESP32 -> Frequency in Mhz (240Mhz is also default)
  esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);//Disable all wakeup sources

  #if lcd_display_enabled
  if(ext_cal_button_hw_pin>=0) {pinMode(ext_cal_button_hw_pin,INPUT_PULLUP);}//Optional external CAL button
  if(rx_power_hw_pin>=0) {gpio_hold_dis((gpio_num_t)rx_power_hw_pin);pinMode(rx_power_hw_pin,OUTPUT);digitalWrite(rx_power_hw_pin,HIGH);}//Optional: switch on the 5V module of the receiver
  {
    const int lcd_pins[4]={steering_hw_pin,throttle_brake_hw_pin,turbo_hw_pin,reverse_hw_pin};
    lcd_begin(compositeHID.deviceName.c_str(),"v1-6-0 " LCD_UI_VERSION,lcd_pins,btn_next_hw_pin,btn_ok_hw_pin);
  }
  #else
  pinMode(20,OUTPUT);digitalWrite(20,LOW);//Waveshare ESP32-S3-LCD-1.3: keep the display backlight off, if the display is not used
  #endif
}



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------ Main Software, which will be called cyclic -> Defines Software behaviour and uses all above objects and routines ------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
bool was_connected_last=false;
bool first_loop_active=true;
bool invert_pcb_boot_button=true;//Wil be automatically be set in the ffirst cycle
bool PCB_button_state_last=false;
long PCB_button_counter=0;
bool PCB_button_state_last_debug=false;
int stored_last_combo_key=0;
int stored_last_combo_key_usb=0;
bool reverse_condition_last=false;
unsigned long launch_control_interrupt=0;
long calculation_cycle=0;

bool use_combined_turbo_reverse_channel;
bool combined_reverse_active;
bool combined_turbo_active;
bool old_physical_reverse_condition;
bool reverse_condition;
bool turbo_condition;

bool LED_status;

void loop()
{
  //Get the PCB boot button state and check in the first cycle, if it needs to be inverted
  if(first_loop_active && digitalRead(internal_boot_button_hw_pin))//If bot button is High in the first step, invert the signal always for the future
  {invert_pcb_boot_button=true;}
  bool PCB_button_state=digitalRead(internal_boot_button_hw_pin);//Get actual button state and store it in a local variable
  if(invert_pcb_boot_button)//In case invert the button state, if necesarry
  {PCB_button_state=!PCB_button_state;}
  #if bt_advertising_fix
  bt_advertising_fix_check();//Bluetooth name in the advertising and advertising after a disconnect
  #endif
  #if lcd_display_enabled
  if(ext_cal_button_hw_pin>=0 && digitalRead(ext_cal_button_hw_pin)==LOW)//Optional external CAL button (to GND) works like the BOOT button
  {PCB_button_state=true;}
  #endif

  //Calculate all processed channels individually.
  bool channel_led_status;
  channel_led_status=ir1.perform_cyclic_calculation(channel_led_status,PCB_button_state,debug_active_mode);//Calculate the processed information (Always use the first object instance as debug trigger)
  channel_led_status=ir2.perform_cyclic_calculation(channel_led_status,PCB_button_state,false);//Calculate the processed information
  channel_led_status=ir3.perform_cyclic_calculation(channel_led_status,PCB_button_state,false);//Calculate the processed information
  channel_led_status=ir4.perform_cyclic_calculation(channel_led_status,PCB_button_state,false);//Calculate the processed information

  //Receiver was connected once.
  bool receiver_was_never_connected=!ir1.get_channel_connected_once() && !ir2.get_channel_connected_once() && !ir3.get_channel_connected_once() && !ir4.get_channel_connected_once();


  //Calculate if to show debug infos in the Arduino Console
  if(PCB_button_state==true && PCB_button_state_last==false  && ir1.get_cal_step()==0)//Count short button presses (Rising edges), before the calibration starts. If 10 is reached and the calibration is started afterwards, extended debug information are shown
  {PCB_button_counter=PCB_button_counter+1;}
  //In case when debug informations should be displayed during the calibration process
  if (debug_active_mode && ir1.get_cal_step()!=0 && ir1.get_internal_task_cycle_active() && (!PCB_button_state || (PCB_button_state!=PCB_button_state_last_debug)))//Use channel 1 as trigger for checking, if debug infos needs to be displayed
  {
    if(PCB_button_counter>10)//Output additional debug infos in the first step only
    {
      Serial.println("");
      ir1.print_initial_general_debug_infos();
      Serial.println("");
    }
    PCB_button_counter=0;//Otherwise or in any case reset the counter to 0

    //Output the normal debug infos:
    ir1.print_debug_infos();//Print infos for interrupt 1
    ir2.print_debug_infos();//Print infos for interrupt 1
    ir3.print_debug_infos();//Print infos for interrupt 1
    ir4.print_debug_infos();//Print infos for interrupt 1
    Serial.print("\tCAL_BUTTON=");Serial.print(PCB_button_state);//Print the physical button state

    if(ir2.get_additional_channel_option()<0)//Show time for slow Mode
    {Serial.print("\tSLOW COMBO");}
    else if(ir2.get_additional_channel_option()>0)//Show time for fast Mode
    {Serial.print("\tFAST COMBO");}
    else //Show time for normal Mode
    {Serial.print("\tMEDIUM COMBO");}

    Serial.println("");// Print a new line, after the debug output of the object (only if debug was active)

    PCB_button_state_last_debug=PCB_button_state;//Remember the last button state when showing debug infos
  }



  //Combo Calculations (Not each cycle)
  unsigned int calc_combo_interrupt_cycles=5;//If set to 5, only each 5th cycle a new combo value is calculated (Except there is a change on channel 3 or 4 detected)
  if(calculation_cycle%calc_combo_interrupt_cycles==0 || ir3.get_prescaled_value_delta()!=0 || ir4.get_prescaled_value_delta()!=0)//Calculate only each Nth cycle a new combo value is calculated (Except there is a change on channel 3 or 4 detected)
  {
    //Calculate the times used for the Combos at the end
    long set_combo_turbo_time=combo_turbo_time;
    long set_combo_launch_control_time=combo_launch_control_time;
    long set_combo_reverse_time=combo_reverse_time;
    if(ir2.get_additional_channel_option()<0)//Use additional channel option from throttle channel (-1, 0, +1) to decide, if to increase or decrease the necesarry time for combos -> Time is increased by 20% -> Slow mode
    {
      //Increase Combo time at negative values
      set_combo_turbo_time=(set_combo_turbo_time*100)/80;
      set_combo_launch_control_time=(set_combo_launch_control_time*100)/80;
      set_combo_reverse_time=(set_combo_reverse_time*100)/80;
    }
    else if(ir2.get_additional_channel_option()>0)//Use additional channel option from throttle channel (-1, 0, +1) to decide, if to increase or decrease the necesarry time for combos -> Time is reduced by 20% -> Fast mode
    {
      //Reduce Combo time at positive values
      set_combo_turbo_time=(set_combo_turbo_time*80)/100;
      set_combo_launch_control_time=(set_combo_launch_control_time*80)/100;
      set_combo_reverse_time=(set_combo_reverse_time*80)/100;
    }

    //Calculate the Combos for Launch Control, Turbo & Reverse
    combo_turbo.combo(ir1.get_use_combos()>0 && ir1.get_cal_step()==0 && ir2.get_prescaled_value()>100,ir2.get_prescaled_value()>950,ir2.get_prescaled_value(),900,950,2,set_combo_turbo_time,4,(combo_turbo.get_output() && ir2.get_prescaled_value()>950) || ir3.get_prescaled_value_delta()!=0,(ir2.get_prescaled_value()<870 && combo_turbo.get_output()) || ir3.get_prescaled_value_delta()!=0,false);
    combo_launch_control.combo((ir1.get_use_combos()>0 || ir1.get_use_combos()<0) && combo_light.get_output()==false && combo_menue.get_output()==false && ir1.get_cal_step()==0 && ir2.get_prescaled_value()<-900,true,ir1.get_prescaled_value(),-850,850,0,set_combo_launch_control_time,4,ir2.get_prescaled_value()>700 || ir3.get_prescaled_value_delta()!=0,ir2.get_prescaled_value()<300 || ir3.get_prescaled_value_delta()!=0,false);
    combo_reverse.combo((ir1.get_use_combos()>1 || ir1.get_use_combos()<0) && ir1.get_cal_step()==0 && ir2.get_prescaled_value()<150 && ir1.get_prescaled_value()>=-400 && ir1.get_prescaled_value()<=400,true,ir2.get_prescaled_value(),-900,-300,2,set_combo_reverse_time,5,combo_launch_control.get_output() || combo_turbo.get_output() || ir2.get_prescaled_value()>-500,combo_launch_control.get_output() || combo_turbo.get_output() || ir2.get_prescaled_value()>-500,false);
    //LIGHT: Full Brake Trigger and 3 Times full Right (Light Combo is always active)
    combo_light.combo(ir1.get_cal_step()==0 && ir2.get_prescaled_value()<-900 && ir1.get_prescaled_value()>-200,true,ir1.get_prescaled_value(),+300,+900,1,(set_combo_reverse_time*90)/100,5,true,(combo_light.get_output()==true && (ir1.get_prescaled_value()<100 || ir2.get_prescaled_value()>-700)),false);
    //MOTOR START:Full Brake Trigger and 3 Times full Right and after that full left (Will start/Stop the motor)
    long combo_motor_start_input_value=-10000;
    if(combo_motorstart.get_pre_check_finished())
    {combo_motor_start_input_value=ir1.get_prescaled_value();}
    combo_motorstart.combo(ir1.get_cal_step()==0 && ir2.get_prescaled_value()<-900,combo_light.get_output()==true,combo_motor_start_input_value,-900,+900,1,(set_combo_reverse_time*170)/100,2,true,(combo_motorstart.get_output()==true && (ir1.get_prescaled_value()>-100 || ir2.get_prescaled_value()>-700)),false);
    //MENUE: Full Brake Trigger and 3 Times full Left (Only Carrera Hybrid)
    combo_menue.combo((ir1.get_use_combos()>1 || ir1.get_use_combos()<0) && ir1.get_cal_step()==0 && ir2.get_prescaled_value()<-900 && ir1.get_prescaled_value()<+200,true,ir1.get_prescaled_value(),-900,-300,2,(set_combo_reverse_time*90)/100,5,true,(combo_menue.get_output()==true && (ir1.get_prescaled_value()>-100 || ir2.get_prescaled_value()>-700)),false);

    //Calculate potential combined reverse and turbo states
    use_combined_turbo_reverse_channel=ir3.get_channel_is_active() && (ir4.get_channel_is_active()==false || ir4.get_output_discretize_steps()<1) && ir3.get_output_discretize_steps()>=2;//Condition to check, if combined reverse/Turbo is Used
    combined_reverse_active=(use_combined_turbo_reverse_channel && ir3.get_prescaled_value_delta()<0 && ir3.get_prescaled_value()<1);
    combined_turbo_active=(use_combined_turbo_reverse_channel && ir3.get_prescaled_value()>1);

    //Calculate condition if reverse should be set
    old_physical_reverse_condition=ir4.get_prescaled_value()>=1 && ir4.get_discrete_button_is_toogle_button()==true;
    reverse_condition=((ir4.get_prescaled_value_delta()!=0 || combined_reverse_active) && ir4.get_discrete_button_is_toogle_button()==false) || (combo_reverse.get_output_rising());//Reverse condition for combo
      //bool reverse_condition=old_physical_reverse_condition || combo_reverse.get_output();//Reverse condition for combo
    reverse_press_timer.calc_timer(reverse_condition!=reverse_condition_last && first_loop_active==false,250);
    reverse_condition_last=reverse_condition;


    //Calculate the resulting turbo state, depending on the turbo button behaviour. If it is enabled, it will act like an auto release of the turbo (Always set button to be not a pushbutton, as in the calibration a pushbotton can be converted to a normal button)
    //turbo_button_auto_release.calc_auto_release_state(ir3.get_output_value()>=1,ir2.get_prescaled_value()>950 , ir2.get_prescaled_value()<870,use_combined_turbo_reverse_channel==true || ir2.get_last_step_cannel_condition()<=0 || ir1.get_cal_step()!=0 ,false,combo_turbo.get_output_falling() || combo_launch_control.get_output_falling(),(ir1.get_prescaled_value()>200 || ir1.get_prescaled_value()<-200),500);
    turbo_button_auto_release.calc_auto_release_state((ir3.get_output_value()>=1 && use_combined_turbo_reverse_channel==false) || combined_turbo_active,ir2.get_prescaled_value()>950 , ir2.get_prescaled_value()<870, ir2.get_last_step_cannel_condition()<=0 || ir1.get_cal_step()!=0,false,combo_turbo.get_output_falling() || combo_launch_control.get_output_falling(),(ir1.get_prescaled_value()>200 || ir1.get_prescaled_value()<-200),500);

    //Check if to interrupt launch control by shortly tunring the steerring wheel druing launch control
    if(!combo_launch_control.get_output())
    {launch_control_interrupt=0;}
    else if(launch_control_interrupt==0 && combo_launch_control.get_output() && combo_launch_control.get_reset_pre_condition_fulfilled() && (ir1.get_prescaled_value()>200 || ir1.get_prescaled_value()<-200))
    {launch_control_interrupt=1;}
    else if(launch_control_interrupt_timer.get_output())
    {launch_control_interrupt=2;}
    launch_control_interrupt_timer.calc_timer(launch_control_interrupt==1,150);

    turbo_condition=turbo_button_auto_release.get_output_state() || combo_turbo.get_output() || (combo_launch_control.get_output() && (launch_control_interrupt!=1||ir2.get_prescaled_value()<100));
  }




  //LED Calculations (Not each cycle)
  unsigned int calc_led_interrupt_cycles=10;//If set to 5, only each 5th cycle a new combo value is calculated (Except there is a change on channel 3 or 4 detected)
  unsigned int calc_led_interrupt_offsets=calc_combo_interrupt_cycles/2;
  if((calculation_cycle-calc_led_interrupt_offsets)%calc_led_interrupt_cycles==0 || ir3.get_prescaled_value_delta()!=0 || ir4.get_prescaled_value_delta()!=0)//Calculate only each Nth cycle a new combo value is calculated (Except there is a change on channel 3 or 4 detected)
  {
    LED_status=channel_led_status;
    //Overwrite the LED in cases where the LED should start blinking
    long blink_period_on_time=150;
    int blink_on_periods=5;
    int blink_off_periods=5;
    bool blink_reset_pattern=true;

    bt_not_connected_timer.calc_timer(!compositeHID.isConnected() && !receiver_was_never_connected,10000);
    if(receiver_was_never_connected)//If the receiver was never connected, leave the LED off
    {
      LED_status=false;
    }
    else if(ir1.get_cal_step_external()!=0)//In general by default i nthe calibration routine, the LED will be always on and only be short off in the steps between. Here a blink indication for each step will be over modulated with an invertet blink pattern
    {
      blink_period_on_time=180;blink_on_periods=ir1.get_cal_step_external();blink_off_periods=10-ir1.get_cal_step_external();blink_reset_pattern=!LED_status;
      LED_status=LED_status && !led_blink_timer.get_blink_modulated();
    }
    else if((!compositeHID.isConnected() && use_usb_controler_support==0) || (bt_not_connected_timer.get_running() && use_usb_controler_support>0))//If Bluetooth is not connectet, flash the LED 4 times in between
    {
      blink_period_on_time=100;blink_on_periods=6;blink_off_periods=25;blink_reset_pattern=false;
      if(!led_blink_timer.get_blink_interrupt())
      {LED_status=led_blink_timer.get_blink_modulated();}
    }
    else if(combo_turbo.get_output() || combo_launch_control.get_output() || combo_reverse.get_output())//If combos are active, activate a 3 times inverted
    {
      blink_period_on_time=100;blink_on_periods=3;blink_off_periods=3;blink_reset_pattern=false;
      //LED_status=(LED_status && (led_blink_timer.get_blink_modulated() || led_blink_timer.get_blink_interrupt())) || led_blink_timer.get_blink_modulated();
      if(!led_blink_timer.get_blink_interrupt())
      {LED_status=led_blink_timer.get_blink_modulated();}

    }
    else if(old_physical_reverse_condition || turbo_condition)//If reverse or turbo button are active, the led is on, but not in a transition and also perform a short blink over time
    {
      blink_period_on_time=100;blink_on_periods=1;blink_off_periods=5;blink_reset_pattern=(ir3.get_prescaled_value_delta()!=0 || ir4.get_prescaled_value_delta()!=0);
      //LED_status=(LED_status && (led_blink_timer.get_blink_modulated() || led_blink_timer.get_blink_interrupt())) || led_blink_timer.get_blink_modulated();
      if(!led_blink_timer.get_blink_interrupt())
      {LED_status=led_blink_timer.get_blink_modulated();}
    }

    led_blink_timer.calc_blink_timer(blink_period_on_time, blink_on_periods, blink_off_periods,blink_reset_pattern);//Calculate the blink timer (One cycle behind)
  }



  //Calculate processed steering and throttle values to avoid that in android or iOS small to 0% or small to 100% will remain
  int16_t processed_steering_value=ir1.get_output_value_processed(8,8);
  int16_t processed_throttlebrake_value=ir2.get_output_value_processed(8,8);

  //Calculate what to send as an emulated bluetooth gamepad for Carrera Hybrid
  #if use_usb_controler_support<2
  if(compositeHID.isConnected())//Only process the output information, if bluetooth is connected
  {
      //Interpret the result of all channels to send an output to the bluetooth gamecontroller class

      //Set Steering Stick Command which is on interrupt channel 1 (positive output values are right, negative are left)
      gamepad->setLeftThumb(processed_steering_value, 0);//Set left Thumbstick X, Y for steering

      //Set trottle trigger which is on interrupt channel 2 (positive output values are throttle, negative are brake)
      if(processed_throttlebrake_value > 0)//Throttle condition
      {gamepad->setRightTrigger(abs(processed_throttlebrake_value));}
      else//No condition
      {gamepad->setRightTrigger(0);}

      //Set brake trigger & and also set brake trigger, if throttle is set, but interrupt4 Button channel was set (reverse), or the combo is active
      if(processed_throttlebrake_value < 0 )//Brake condition
      {gamepad->setLeftTrigger(abs(processed_throttlebrake_value));}
      else if(old_physical_reverse_condition)//OLD Reverse condition, with Brake and Throttle at the same time (Only available in Carrera Hybrid) -> ONLY use this condition, if the reverse button is used as toggle button
      {gamepad->setLeftTrigger(abs(ir2.get_min_output_scale()));}
      else//No Condition
      {gamepad->setLeftTrigger(0);}

      //Interpret Turbo Button (interrupt channel 3), or the combo is active
      if(turbo_condition)
      {gamepad->press(XBOX_BUTTON_LB);}//Is gamepad Tester Button 7 and LB on original CH Controller ; WAS XBOX_BUTTON_X in old Versions
      else
      {gamepad->release(XBOX_BUTTON_LB);}//Is gamepad Tester Button 7 and LB on original CH Controller ; WAS XBOX_BUTTON_X in old Versions

      //New Reverse Condition over Button
      if(reverse_press_timer.get_output())
      {gamepad->press(XBOX_BUTTON_RB);}//RB is now for reverse toggle
      else
      {gamepad->release(XBOX_BUTTON_RB);}//RB is now for reverse toggle

      //Interpret Light Combo, to simulate button press (Full Brake Trigger and 3 Times full Right)
      if(combo_light.get_output())
      {gamepad->press(XBOX_BUTTON_B);gamepad->press(XBOX_BUTTON_Y);stored_last_combo_key=XBOX_BUTTON_Y;}//Xbox B Is gamepad Tester Button 2 (Used for Dr!ft) and A on original CH Controller | Xbox Y Is gamepad Tester Button 5 (Used for Carrera Hybrid) and X on original CH Controller
      else
      {gamepad->release(XBOX_BUTTON_B);gamepad->release(XBOX_BUTTON_Y);}//Xbox B Is gamepad Tester Button 2 (Used for Dr!ft) and A on original CH Controller | Xbox Y Is gamepad Tester Button 5 (Used for Carrera Hybrid) and X on original CH Controller

      //Interpret Motor Start Combo, to simulate button press  (5 Times Full brake trigger)
      if(combo_motorstart.get_output())
      {gamepad->press(XBOX_BUTTON_START);stored_last_combo_key=XBOX_BUTTON_START;}//Is gamepad Tester Button 13 and + on original CH Controller
      else
      {gamepad->release(XBOX_BUTTON_START);}//Is gamepad Tester Button 13 and + on original CH Controller

      //Interpret Menue Combo, to simulate button press (Full Brake Trigger and 3 Times full Left) -> Used librarie seems to not pass the select button over bluetooth, so it is useless right now!!! So as an altenative, also the Right Stick is pressed. To map it, at first trigger the compo and then press the mapping buton in CH
      if(combo_menue.get_output())
      {gamepad->press(XBOX_BUTTON_SELECT);gamepad->press(XBOX_BUTTON_RS);stored_last_combo_key=XBOX_BUTTON_RS;}//Is gamepad Tester Button 14 and - on original CH Controller
      else
      {gamepad->release(XBOX_BUTTON_SELECT);gamepad->release(XBOX_BUTTON_RS);}//Is gamepad Tester Button 14 and - on original CH Controller

      //Marker for Special Keys, to be able to do remapping of these keys, by activating the combo first and afterwards perform a short press on the cal/boot button
      if(stored_last_combo_key!=0 && PCB_button_state==true && ir1.get_cal_step()==0)
      {gamepad->press(stored_last_combo_key);}
      else if(ir1.get_cal_step()!=0 || (stored_last_combo_key!=0 && PCB_button_state_last==true && PCB_button_state==false && ir1.get_cal_step()==0))
      {gamepad->release(stored_last_combo_key);stored_last_combo_key=0;}
      else if(stored_last_combo_key!=0 && (ir3.get_prescaled_value_delta()!=0 or ir4.get_prescaled_value_delta()!=0))
      {stored_last_combo_key=0;}

      gamepad->sendGamepadReport();
  }
  //else
  //{
    //if(was_connected_last==true || (PCB_button_state_last==true && PCB_button_state==false && ir1.get_cal_step()==0)) //ELSE Backup Check, if the ESP board looses the connection and send one advertising message again, but also if not connected and boot Butto is pressed, if it is not connected
    //{
        //compositeHID.end();    // stop Bluetooth connection first
        //delay(150);            // wait a small time [ms], to ensure, that it is disconnected/shutdown
        //compositeHID.begin();  // Send one advertising message again, to try to reconnect again
    //}
  //}
  //was_connected_last=compositeHID.isConnected();//Store the actual connection state as a marker for the last connection state for the next cycle
#endif


#if use_usb_controler_support>0
//Calculate what to send as an emulated USB gamepad for Carrera Hybrid
  if(!compositeHID.isConnected())//Only process the output information, if bluetooth is connected
  {
      //Interpret the result of all channels to send an output to the bluetooth gamecontroller class
      //Button Key Code Mapping: 0=A, 1=B, 2=C, 3=X, 4=Y, 5=Z, 6=L1, 7=R1, 8=L2, 9=R2, 10=SELECT, 11=START, 12=MODE, 13=L3, 14=R3
      //Set Steering Stick Command which is on interrupt channel 1 (positive output values are right, negative are left)
      Joystick.setXAxis(processed_steering_value);//Set left Thumbstick X, for steering

      //Set trottle trigger which is on interrupt channel 2 (positive output values are throttle, negative are brake)
      if(processed_throttlebrake_value > 0)//Throttle condition
      {Joystick.setAccelerator(abs(processed_throttlebrake_value));}
      else//No condition
      {Joystick.setAccelerator(0);}

      //Set brake trigger & and also set brake trigger, if throttle is set, but interrupt4 Button channel was set (reverse), or the combo is active
      if(processed_throttlebrake_value < 0 )//Brake condition
      {Joystick.setBrake(abs(processed_throttlebrake_value));}
      else if(old_physical_reverse_condition)//OLD Reverse condition, with Brake and Throttle at the same time (Only available in Carrera Hybrid) -> ONLY use this condition, if the reverse button is used as toggle button
      {Joystick.setBrake(abs(ir2.get_min_output_scale()));}
      else//No Condition
      {Joystick.setBrake(0);}

      //Interpret Turbo Button (interrupt channel 3), or the combo is active
      if(turbo_condition)
      {Joystick.setButton(usb_turbo_key, true);}
      else
      {Joystick.setButton(usb_turbo_key, false);}

      //New Reverse Condition over Button
      if(reverse_press_timer.get_output())
      {Joystick.setButton(usb_reverse_key, true);}//RB is now for reverse toggle
      else
      {Joystick.setButton(usb_reverse_key, false);}//RB is now for reverse toggle

      //Interpret Light Combo, to simulate button press (Full Brake Trigger and 3 Times full Right)
      if(combo_light.get_output())
      {Joystick.setButton(1, true);Joystick.setButton(4, true);stored_last_combo_key_usb=5;}//Xbox B Is gamepad Tester Button 2 (Used for Dr!ft) and A on original CH Controller | Xbox Y Is gamepad Tester Button 5 (Used for Carrera Hybrid) and X on original CH Controller
      else
      {Joystick.setButton(1, false);Joystick.setButton(4, false);}//Xbox B Is gamepad Tester Button 2 (Used for Dr!ft) and A on original CH Controller | Xbox Y Is gamepad Tester Button 5 (Used for Carrera Hybrid) and X on original CH Controller

      //Interpret Motor Start Combo, to simulate button press  (5 Times Full brake trigger)
      if(combo_motorstart.get_output())
      {Joystick.setButton(11, true);stored_last_combo_key_usb=11;}//Is gamepad Tester Button 13 and + on original CH Controller
      else
      {Joystick.setButton(11, false);}//Is gamepad Tester Button 13 and + on original CH Controller

      //Interpret Menue Combo, to simulate button press (Full Brake Trigger and 3 Times full Left) -> Used librarie seems to not pass the select button over bluetooth, so it is useless right now!!! So as an altenative, also the Right Stick is pressed. To map it, at first trigger the compo and then press the mapping buton in CH
      if(combo_menue.get_output())
      {Joystick.setButton(10, true);Joystick.setButton(14, true);stored_last_combo_key_usb=14;}//Is gamepad Tester Button 14 and - on original CH Controller
      else
      {Joystick.setButton(10, false);Joystick.setButton(14, false);}//Is gamepad Tester Button 14 and - on original CH Controller

      //Marker for Special Keys, to be able to do remapping of these keys, by activating the combo first and afterwards perform a short press on the cal/boot button
      if(stored_last_combo_key_usb!=0 && PCB_button_state==true && ir1.get_cal_step()==0)
      {Joystick.setButton(stored_last_combo_key_usb, true);}
      else if(ir1.get_cal_step()!=0 || (stored_last_combo_key_usb!=0 && PCB_button_state_last==true && PCB_button_state==false && ir1.get_cal_step()==0))
      {Joystick.setButton(stored_last_combo_key_usb, false);stored_last_combo_key_usb=0;}
      else if(stored_last_combo_key_usb!=0 && (ir3.get_prescaled_value_delta()!=0 or ir4.get_prescaled_value_delta()!=0))
      {stored_last_combo_key_usb=0;}
  /*
  //Just to be used for debug, if rest of USB output is uncommented
  if(ir3.get_prescaled_value_delta()!=0)
  {stored_last_combo_key_usb=stored_last_combo_key_usb+1;} // Turbo counts to next button
  if(abs(ir1.get_prescaled_value())>500 || abs(ir2.get_prescaled_value())>500)//Throttle or brake will reset the button counter
  {stored_last_combo_key_usb=0;}
  if(ir4.get_prescaled_value()>0)//toggles the button
  {Joystick.setButton(stored_last_combo_key_usb, true);}
  else
  {Joystick.setButton(stored_last_combo_key_usb, false);}
*/
      //Mappings for new release which will matche BT layout
      //(Second Value to be tested for USB)
      //Turbo 4 --> 7
      //Reverse 7 --> 9
      //Motor Start 10 --> 13
      //Light 14 --> 5 AND 2 --> 2
      //Menue 9 --> 12 AND 12 -->15
  }
#endif


  if(status_led_hw_pin<0)//If selected, invert the LED status
  {LED_status=!LED_status;}

  //Write the LED status to the correct LED
  if(internal_led_is_rgb_led!=1)
  {digitalWrite(abs(status_led_hw_pin),LED_status);}//Write the status information to the LED (Normal LED on the Board)
  else
  {rgbLedWrite(abs(status_led_hw_pin), 0, 0, 64*LED_status);}//Write the status information to the LED (RGB LED on the Board (64 is max value))


  //Code for checking if setting board to deep sleep mode
  bool sleep_timer_condition_short=ir1.get_prescaled_value()==0 && ir2.get_prescaled_value()==0 && ir3.get_prescaled_value_delta()==0 && ir4.get_prescaled_value_delta()==0;//Condition is, that Analog channels are in neutral position and digital channels are not moved
  bool sleep_timer_condition_long=ir1.get_prescaled_value_delta()==0 && ir2.get_prescaled_value_delta()==0 && ir3.get_prescaled_value_delta()==0 && ir4.get_prescaled_value_delta()==0;//Condition is, that all channels are in a not moved position
  bool sleep_timer_condition_use;
  unsigned long time_until_sleep;
  if(receiver_was_never_connected && time_to_deep_sleep_mode_initial>0)//If Receiver was never connectet, use the short time to detect depp sleep mode
  {time_until_sleep=(time_to_deep_sleep_mode_initial*60000);sleep_timer_condition_use=sleep_timer_condition_short;}
  else if(sleep_timer_condition_short && time_to_deep_sleep_mode>0)//If the more strict short condition is fulfilled, use the normal longer time
  {time_until_sleep=time_to_deep_sleep_mode*60000;sleep_timer_condition_use=sleep_timer_condition_short;}
  else if(time_to_deep_sleep_mode>0)//If only the easyer condition is fulfilled, use the normal longer time +15 minutes until detect depp sleep mode
  {time_until_sleep=(time_to_deep_sleep_mode+15)*60000;sleep_timer_condition_use=sleep_timer_condition_long;}
  else//Otherwise deep sleep mode is completely deactivated
  {time_until_sleep=0;sleep_timer_condition_use=false;}
  //Calculate the timer for detecting depp sleep mode
  sleep_timer.calc_timer(sleep_timer_condition_use,time_until_sleep);
  #if lcd_display_enabled
  lcd_loop_update(PCB_button_state,old_physical_reverse_condition,turbo_condition,use_combined_turbo_reverse_channel,receiver_was_never_connected,time_until_sleep);
  if(sleep_timer.get_output() || lcd_battery_empty())//Display edition: show the sleep screen and switch off display, LED and receiver power before the deep sleep
  {
    lcd_enter_sleep(lcd_battery_empty());
    if(internal_led_is_rgb_led==1) {rgbLedWrite(abs(status_led_hw_pin),0,0,0);} else {digitalWrite(abs(status_led_hw_pin),status_led_hw_pin<0);}
    pinMode(LCD_PIN_BL,OUTPUT);digitalWrite(LCD_PIN_BL,LOW);gpio_hold_en((gpio_num_t)LCD_PIN_BL);
    if(rx_power_hw_pin>=0) {digitalWrite(rx_power_hw_pin,LOW);gpio_hold_en((gpio_num_t)rx_power_hw_pin);}
    gpio_deep_sleep_hold_en();
    esp_deep_sleep_start();
  }
  #endif
  if(sleep_timer.get_output())//Going to deepsleep mode after a long time without input (Wakup will be performed by pressing EN Button again, or repower on the ESP Board)
  {esp_deep_sleep_start();}


  //Misc last states
  PCB_button_state_last=PCB_button_state;//Save last button state
  first_loop_active=false;//Indicate that the first cycle was finished.

  if(calculation_cycle>=999999999)
  {calculation_cycle=0;}
  else
  {calculation_cycle=calculation_cycle+1;}
}
//-------------------------------------------------------------------



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------ Display edition: collect the data for the display and apply settings from the display menu ------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#if bt_advertising_fix
#include <NimBLEDevice.h>
//The Bluetooth server is started by the library in its own task. As soon as it runs, add the name and enable advertising after a disconnect
void bt_advertising_fix_check()
{
  static bool server_done=false;
  static bool name_done=false;
  if(server_done && name_done) {return;}
  if(!NimBLEDevice::isInitialized()) {return;}
  NimBLEServer* server=NimBLEDevice::getServer();
  if(server==nullptr) {return;}
  if(!server_done) {server->advertiseOnDisconnect(true);server_done=true;}
  NimBLEAdvertising* adv=NimBLEDevice::getAdvertising();
  if(adv==nullptr) {return;}
  if(adv->isAdvertising())//Library has started the advertising: restart it with the name in the scan response
  {
    adv->stop();
    adv->enableScanResponse(true);
    adv->setName(compositeHID.deviceName);
    adv->start();
    name_done=true;
  }
  else if(compositeHID.isConnected())//Already connected: only prepare the name for the next advertising
  {
    adv->enableScanResponse(true);
    adv->setName(compositeHID.deviceName);
    name_done=true;
  }
}
#endif

#if lcd_display_enabled
void lcd_fill_channel(LcdChannel& c, RcReceiverReader& ir)
{
  c.active=ir.get_channel_is_active();
  c.signal=ir.get_signal_ok();
  c.raw=ir.get_delta_time();
  c.pre=ir.get_prescaled_value();
  c.steps=ir.get_output_discretize_steps();
  c.cal_min=ir.get_cal_delta_min_time();
  c.cal_max=ir.get_cal_delta_max_time();
  c.neu_min=ir.get_cal_neutral_min_time();
  c.neu_max=ir.get_cal_neutral_max_time();
  c.toggle_btn=ir.get_discrete_button_is_toogle_button();
  c.expo=ir.get_channel_exp_factor();
}

void lcd_loop_update(bool cal_button, bool reverse_hold, bool turbo, bool combined_tr, bool receiver_never_connected, unsigned long time_until_sleep)
{
  static LcdTele tele;
  static unsigned long cal_press_start=0;
  static bool cal_button_last=false;
  static bool bt_last=false;
  static unsigned long last_publish=0;
  unsigned long now=millis();

  //Remember the last activity (wakes up the display)
  bool bt=compositeHID.isConnected();
  if(ir1.get_prescaled_value_delta()!=0 || ir2.get_prescaled_value_delta()!=0 || ir3.get_prescaled_value_delta()!=0 || ir4.get_prescaled_value_delta()!=0 || cal_button!=cal_button_last || bt!=bt_last)
  {tele.activity_ms=now;}
  if(cal_button && !cal_button_last) {cal_press_start=now;}
  cal_button_last=cal_button;
  bt_last=bt;

  //Apply settings changed in the display menu (never during the calibration)
  int sid; long sval;
  if(lcd_take_setting(sid,sval) && ir1.get_cal_step()==0)
  {
    if(sid==LCD_SET_COMBOS) {ir1.set_use_combos(sval);ir1.save_settings();}
    else if(sid==LCD_SET_SPEED) {ir2.set_additional_channel_option(sval);ir2.save_settings();}
    else if(sid==LCD_SET_EXPO_STEER) {ir1.set_channel_exp_factor(sval);ir1.save_settings();}
    else if(sid==LCD_SET_EXPO_THROTTLE) {ir2.set_channel_exp_factor(sval);ir2.save_settings();}
  }

  //Publish not more often than every 15 ms, except for short reverse pulses
  if(now-last_publish<15 && !reverse_press_timer.get_output()) {return;}
  last_publish=now;

  tele.ms=now;
  tele.bt_connected=bt;
  tele.rx_seen=!receiver_never_connected;
  lcd_fill_channel(tele.ch[0],ir1);
  lcd_fill_channel(tele.ch[1],ir2);
  lcd_fill_channel(tele.ch[2],ir3);
  lcd_fill_channel(tele.ch[3],ir4);
  tele.cal_step_ext=ir1.get_cal_step_external();
  tele.cal_presses=ir1.get_cal_short_presses();
  tele.cal_btn=cal_button;
  tele.cal_hold_ms=cal_button ? (now-cal_press_start) : 0;
  tele.turbo=turbo;
  tele.reverse_pulse=reverse_press_timer.get_output();
  tele.reverse_hold=reverse_hold;
  tele.c_launch=combo_launch_control.get_output();
  tele.c_light=combo_light.get_output();
  tele.c_motor=combo_motorstart.get_output();
  tele.c_menu=combo_menue.get_output();
  tele.c_turbo=combo_turbo.get_output();
  tele.c_reverse=combo_reverse.get_output();
  tele.use_combos=ir1.get_use_combos();
  tele.combo_speed=ir2.get_additional_channel_option();
  tele.combined_tr=combined_tr;
  if(time_until_sleep>0 && sleep_timer.get_running())
  {tele.sleep_left_ms=(time_until_sleep>(unsigned long)sleep_timer.get_et()) ? (time_until_sleep-sleep_timer.get_et()) : 0;}
  else
  {tele.sleep_left_ms=0;}
  lcd_publish(tele);
}
#endif
//-------------------------------------------------------------------

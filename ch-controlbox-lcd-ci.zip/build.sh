#!/bin/bash
# Baut beide Firmware-Varianten und die Flash-Seite.
# Voraussetzung: arduino-cli mit esp32 Core 3.0.7 und den Bibliotheken (siehe Workflow).
set -euo pipefail
cd "$(dirname "$0")"
VER=$(tr -d '[:space:]' < VERSION)
DATE=$(date +%d.%m.%Y)
FQBN="${FQBN:-esp32:esp32:esp32s3:FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB}"
CLI="${ARDUINO_CLI:-arduino-cli}"
EXTRA=${ARDUINO_EXTRA:-}
rm -rf dist && mkdir -p dist/build dist/site/firmware dist/firmware dist/sketch_classic

echo "== Mit Display =="
$CLI compile --fqbn "$FQBN" $EXTRA --output-dir dist/build/lcd firmware/CH_ControlBox_LCD

echo "== Ohne Display =="
cp -r firmware/CH_ControlBox_LCD dist/sketch_classic/
sed -i 's/^#define lcd_display_enabled 1/#define lcd_display_enabled 0/' dist/sketch_classic/CH_ControlBox_LCD/CH_ControlBox_LCD.ino
grep -q '^#define lcd_display_enabled 0' dist/sketch_classic/CH_ControlBox_LCD/CH_ControlBox_LCD.ino
$CLI compile --fqbn "$FQBN" $EXTRA --output-dir dist/build/classic dist/sketch_classic/CH_ControlBox_LCD

# Einzelteile fuer den Web-Flasher: so bleiben Kalibrierung und Einstellungen (NVS bei 0x9000) beim Update erhalten
for v in lcd classic; do
  mkdir -p "dist/site/firmware/$v"
  cp "dist/build/$v/CH_ControlBox_LCD.ino.bootloader.bin" "dist/site/firmware/$v/bootloader.bin"
  cp "dist/build/$v/CH_ControlBox_LCD.ino.partitions.bin" "dist/site/firmware/$v/partitions.bin"
  cp tools/boot_app0.bin "dist/site/firmware/$v/boot_app0.bin"
  cp "dist/build/$v/CH_ControlBox_LCD.ino.bin" "dist/site/firmware/$v/firmware.bin"
done
# Gesamtdatei (16 MB, ab Adresse 0x0) fuer andere Flash-Tools. Achtung: loescht dabei auch die Kalibrierung
cp dist/build/lcd/CH_ControlBox_LCD.ino.merged.bin "dist/firmware/ch_controlbox_lcd_v${VER}_komplett_0x0.bin"
cp dist/build/classic/CH_ControlBox_LCD.ino.merged.bin "dist/firmware/ch_controlbox_lcd_v${VER}_ohne_display_komplett_0x0.bin"
cp dist/build/lcd/CH_ControlBox_LCD.ino.bin "dist/firmware/ch_controlbox_lcd_v${VER}_app_0x10000.bin"
cp dist/build/classic/CH_ControlBox_LCD.ino.bin "dist/firmware/ch_controlbox_lcd_v${VER}_ohne_display_app_0x10000.bin"

cp -r site/* dist/site/
sed -i "s/{{VERSION}}/${VER}/g; s/{{DATE}}/${DATE}/g" dist/site/index.html
for v in lcd classic; do
  if [ "$v" = lcd ]; then N="CH Control Box LCD"; else N="CH Control Box LCD (ohne Display)"; fi
  cat > "dist/site/manifest_${v}.json" <<JSON
{
  "name": "$N",
  "version": "$VER",
  "new_install_prompt_erase": true,
  "builds": [
    {
      "chipFamily": "ESP32-S3",
      "parts": [
        { "path": "firmware/$v/bootloader.bin", "offset": 0 },
        { "path": "firmware/$v/partitions.bin", "offset": 32768 },
        { "path": "firmware/$v/boot_app0.bin", "offset": 57344 },
        { "path": "firmware/$v/firmware.bin", "offset": 65536 }
      ]
    }
  ]
}
JSON
done
touch dist/site/.nojekyll
ls -laR dist/site/firmware dist/firmware

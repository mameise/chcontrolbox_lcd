# CH Control Box LCD

Firmware für das **Waveshare ESP32-S3-LCD-1.3** mit eingebautem 1,3" Display.
Basis ist die CH Control Box v1-6-0 von jogger86 & mameise. Die Steuerlogik (Kanäle, Kombos, Kalibrierung, Bluetooth) ist unverändert, dazu kommen Display, Menü und optionale Tasten.

Version: **1.1.0** (Anzeige auf dem Gerät: `v1-6-0 LCD 1.1.0`)

## Anschlüsse

Linke Stiftleiste von oben nach unten: `5V, GND, 3V3, IO1, IO2, IO3, IO4, IO5`
Rechte Stiftleiste von oben nach unten: `IO14 … IO8, IO7`

| Board | Wohin |
|---|---|
| 5V | Plus am Empfänger (nur bei Betrieb über USB, mit Akku siehe unten) |
| GND | Minus am Empfänger |
| IO4 | Signal Lenkung |
| IO3 | Signal Gas / Bremse |
| IO1 | Signal Turbo (oder 3-Stufen-Schalter für Turbo und Rückwärts) |
| IO2 | Signal Rückwärts |
| IO5 | optional Taste **CAL** nach GND (gleich wie BOOT) |
| IO7 | optional Taste **Weiter** nach GND |
| IO8 | optional Taste **OK** nach GND |

Die Pins sind gleich wie bei der Waveshare ESP32-S3 Mini Version (1 Turbo, 2 Rückwärts, 3 Gas, 4 Lenkung).
Der 5V Pin ist direkt mit USB verbunden (Schaltplan geprüft). Er hat nur Strom, wenn ein USB Kabel steckt.
Die Tasten brauchen keinen Widerstand (interner Pull-up). Beide Tasten an den gleichen GND Pin.

## Betrieb mit Akku

```
LiPo 1S + ── Schalter ──┬── Akkustecker Board (+)
                        └── 5V Modul IN+ ── 5V OUT ── Empfänger +
LiPo 1S − ──────────────┬── Akkustecker Board (−)
                        └── 5V Modul IN− ── GND OUT ── Empfänger −
Signale IO1 bis IO4 wie oben
```

- Das Board hat **keinen Ein/Aus Schalter**. Es schaltet nur automatisch zwischen USB und Akku um. Darum kommt ein Schalter in die Plus-Leitung direkt nach dem Akku.
- Den 5V Pin des Boards **frei lassen**. Sonst lädt das Board den Akku über sein eigenes 5V Modul, und mit eingestecktem USB Kabel arbeiten zwei 5V Quellen gegeneinander.
- Laden über USB-C am Board. Der Schalter muss dabei an sein, die Box läuft beim Laden mit.
- Polarität am Akkustecker (MX1.25) prüfen, bei fertigen Akkus ist sie oft vertauscht.
- Akkuanzeige: Symbol mit Prozent oben rechts, Prozent und Spannung auf der Info Seite. Bei 10% kommt eine Warnung. Ist der Akku 1 Minute lang unter 3.3 V, geht die Box in den Tiefschlaf. Ohne Akku (nur USB) wird kein Symbol angezeigt.
- Tiefschlaf schaltet nur den ESP32 ab. 5V Modul und Empfänger brauchen weiter Strom, wenn der Schalter an bleibt. Hat das 5V Modul einen EN Pin, kann man ihn an einen freien GPIO hängen und `rx_power_hw_pin` setzen (z.B. 9). Dann wird auch der Empfänger im Tiefschlaf abgeschaltet.

Schalter im Sketch: `lcd_battery_display` (Akkusymbol), `battery_low_sleep` (Tiefschlaf bei leerem Akku), `rx_power_hw_pin` (EN des 5V Moduls, -1 = aus).

## Bedienung

| Taste | Kurz | Lang |
|---|---|---|
| BOOT / CAL | Weiter in der Kalibrierung | 5 s Kalibrierung starten, 3 s im Schritt 6 speichern |
| Weiter (IO7) | Nächste Seite, im Menü nächster Punkt | Display aus, im Menü einen Punkt zurück |
| OK (IO8) | Menü öffnen, Wert ändern | Menü schliessen |

Seiten: **Fahren** (Lenkrad, Gas/Bremse, Turbo, Rückwärts, Licht, Motor, Launch, Menü), **Kanäle** (µs Werte, Kalibrierbereich, Signal), **Info**.
Menü: Helligkeit, Display aus nach, Drehen, Spiegeln (für das Prisma Gehäuse), Sprache, Kombos, Kombo-Tempo, Expo Lenkung, Expo Gas.
Kombos, Kombo-Tempo und Expo werden gleich gespeichert wie bei der Kalibrierung. Die bisherigen Wege über die CAL Klicks im Schritt 6 funktionieren weiterhin.

## Schalter

Im Sketch unter "Display edition": `#define lcd_display_enabled 1`.
Mit `0` entsteht genau das Originalverhalten mit den gleichen Pins (Display bleibt dunkel). Diese Variante wird immer mitgebaut und ist auf der Flash-Seite als "Ohne Display" wählbar.

## GitHub

Repo Aufbau:
```
.github/workflows/build.yml
ch-controlbox-lcd-ci.zip      (dieses Paket, gezippt hochladen, nicht entpacken)
```
Einmalig: Settings → Pages → Source: **GitHub Actions**. Danach baut jeder Push die Firmware und stellt die Flash-Seite unter `https://<name>.github.io/<repo>/` bereit.
Die Firmware Dateien und die Flash-Seite gibt es zusätzlich als Download unter Actions → letzter Lauf → Artifacts. Die Flash-Seite kann man auch so wie sie ist in Netlify ziehen.

## Änderungen

- **1.1.0** Akkuanzeige mit Prozent, Warnung bei 10%, Tiefschlaf bei leerem Akku, optionaler EN Ausgang für das 5V Modul. Korrektur: Spannungsteiler auf dem Board ist 100K/100K (Faktor 2.0, vorher falsch 3.0).
- **1.0.0** Erste Version mit Display.

## Inhalt

- `firmware/CH_ControlBox_LCD/` Sketch (`.ino`), Display Modul `lcd_ui.h`, Schriften `lcd_fonts.h` (Inter, SIL Open Font License)
- `site/` Flash-Seite (ESP Web Tools)
- `build.sh` baut beide Varianten und die Flash-Seite
- `tools/patch_sketch.py` erzeugt den Sketch nachvollziehbar aus dem Original v1-6-0 (`tools/CH_ControlBox_v1-6-0_original.ino`)
- `tools/mkvlw.py` erzeugt die Schriften
- `tools/preview/` rendert die Display Seiten am PC als Bilder

## Bauen von Hand (Arduino IDE)

Board "ESP32S3 Dev Module", Flash Size 16MB, PSRAM "OPI PSRAM", Partition "16M Flash (3MB APP/9.9MB FATFS)", esp32 Core 3.0.7.
Bibliotheken: NimBLE-Arduino 2.1.0, ESP32-BLE-CompositeHID 0.3.1, Callback 1.1, LovyanGFX 1.1.16.

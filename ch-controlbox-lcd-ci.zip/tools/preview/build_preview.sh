#!/bin/bash
# Rendert die Display-Seiten auf dem PC als PNG (ohne Hardware). Braucht g++ und LovyanGFX 1.1.16.
set -e
cd "$(dirname "$0")"
L="${LGFX:-$HOME/Arduino/libraries/LovyanGFX/src}"
mkdir -p cobj out
for f in "$L"/lgfx/utility/*.c; do gcc -O1 -w -c "$f" -o "cobj/$(basename "$f").o" -I "$L"; done
SRCS=$(ls "$L"/lgfx/v1/*.cpp "$L"/lgfx/v1/misc/*.cpp "$L"/lgfx/v1/panel/*.cpp "$L"/lgfx/v1/platforms/framebuffer/*.cpp)
# Japanische/chinesische Schriften der Bibliothek werden nicht gebraucht: Platzhalter
g++ -std=gnu++17 -O1 -w -DLGFX_LINUX_FB -I shim -I "$L" main.cpp $SRCS cobj/*.o -o preview -lpthread 2>&1 | grep -oE "undefined reference to \`[a-z_0-9]*" | sed 's/.*`//' | sort -u > stubs.txt || true
(echo '#include <cstdint>'; while read n; do echo "extern \"C\" { extern const uint8_t $n[]; const uint8_t $n[1]={0}; }"; done < stubs.txt) > stub.cpp
g++ -std=gnu++17 -O1 -w -DLGFX_LINUX_FB -I shim -I "$L" main.cpp stub.cpp $SRCS cobj/*.o -o preview -lpthread
rm -f out/*; ./preview; python3 topng.py

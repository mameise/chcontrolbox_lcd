#include "shim/Arduino.h"
uint32_t host_ms=100000;
#define LCDUI_HOST
#include <LovyanGFX.hpp>
#include "../../firmware/CH_ControlBox_LCD/lcd_ui.h"
using namespace lcdui;

static void frame()
{
  spr.fillScreen(C_BG);
  if(t.cal_step_ext!=0) draw_calibration();
  else { status_bar(); if(menu_open) draw_menu(); else if(page==0) page_drive(); else if(page==1) page_channels(); else page_info(); }
  overlays();
}
static void dump(const char* name)
{
  frame();
  char fn[128]; snprintf(fn,sizeof(fn),"out/%s.raw",name);
  FILE* f=fopen(fn,"wb");
  for(int y=0;y<240;y++) for(int x=0;x<240;x++){ uint32_t c=spr.readPixel(x,y); uint8_t rgb[3]={(uint8_t)(c>>11<<3),(uint8_t)((c>>5&63)<<2),(uint8_t)((c&31)<<3)}; fwrite(rgb,1,3,f);} 
  fclose(f);
}
static void base()
{
  t=LcdTele(); t.ms=100000; t.bt_connected=true; t.rx_seen=true;
  long raw[4]={1500,1500,1000,1000};
  for(int i=0;i<4;i++){ auto&c=t.ch[i]; c.active=true; c.signal=true; c.raw=raw[i]; c.cal_min=1000; c.cal_max=2000; c.neu_min=1488; c.neu_max=1512; c.steps=(i>=2)?1:0; }
  t.ch[3].steps=2; t.ch[3].toggle_btn=true; t.use_combos=2; menu_open=false; page=0; set_lang=0; toast_until=0; reverse_flash_until=0; blocked_until=0;
  snprintf(bt_name,sizeof(bt_name),"CH Control Box 4038021"); snprintf(fw_name,sizeof(fw_name),"v1-6-0 LCD 1.1.0");
  pins[0]=4;pins[1]=3;pins[2]=1;pins[3]=2; pin_ok=8; battery_mv=3950; battery_pct=-1; sleep_empty=false;
}
int main()
{
  wrapS.set(FONT_S); fontS.loadFont(&wrapS); wrapM.set(FONT_M); fontM.loadFont(&wrapM);
  wrapL.set(FONT_L); fontL.loadFont(&wrapL); wrapXL.set(FONT_XL); fontXL.loadFont(&wrapXL);
  spr.setColorDepth(16); spr.createSprite(240,240);
  base(); t.ch[0].pre=450; t.ch[0].raw=1735; t.ch[1].pre=700; t.ch[1].raw=1850; t.turbo=true; t.c_light=true; dump("01_fahren");
  base(); t.bt_connected=false; for(auto&c:t.ch){c.signal=false;c.raw=0;} t.rx_seen=false; dump("02_kein_empfaenger");
  base(); t.ch[0].pre=-800; t.ch[1].pre=-600; reverse_flash_until=t.ms+500; t.c_launch=true; dump("03_bremsen_rueckwaerts");
  base(); page=1; t.ch[0].raw=1620; t.ch[1].raw=1430; t.ch[2].raw=2000; t.ch[2].pre=1; t.ch[3].pre=1; t.ch[3].raw=1500; t.ch[3].signal=false; dump("04_kanaele");
  base(); page=2; t.ch[0].expo=500; t.combo_speed=1; dump("05_info");
  base(); menu_open=true; menu_item=5; dump("06_menue");
  base(); menu_open=true; menu_item=8; t.ch[1].expo=-250; dump("07_menue_scroll");
  base(); t.cal_step_ext=1; t.ch[0].cal_min=1100; t.ch[0].cal_max=1800; t.ch[0].raw=1700; t.ch[1].cal_min=1300; t.ch[1].cal_max=1900; dump("08_kal_schritt1");
  base(); t.cal_step_ext=2; t.ch[2].toggle_btn=true; dump("09_kal_schritt2");
  base(); t.cal_step_ext=5; t.ch[1].raw=1950; dump("10_kal_schritt5");
  base(); t.cal_step_ext=6; t.cal_presses=7; dump("11_kal_schritt6");
  base(); t.cal_step_ext=6; t.cal_presses=3; t.cal_btn=true; t.cal_hold_ms=1600; dump("12_kal_speichern");
  base(); t.cal_btn=true; t.cal_hold_ms=3100; dump("13_cal_halten");
  base(); t.sleep_left_ms=42000; t.ch[0].pre=0; dump("14_schlaf_countdown");
  base(); toast_txt=T_SAVED; toast_until=t.ms+1000; dump("15_gespeichert");
  base(); set_lang=1; t.ch[0].pre=-300; t.ch[1].pre=350; t.c_motor=true; dump("16_english");
  base(); battery_mv=3920; battery_pct=78; t.ch[0].pre=200; t.ch[1].pre=400; dump("17_akku_78");
  base(); battery_mv=3700; battery_pct=28; page=1; dump("18_akku_28_kanaele");
  base(); battery_mv=3600; battery_pct=9; t.ms=100250; toast_txt=T_BAT_LOW; toast_until=t.ms+1000; dump("19_akku_fast_leer");
  base(); battery_mv=4180; battery_pct=100; page=2; dump("20_akku_info");
  base(); t.bt_connected=false; battery_mv=3800; battery_pct=50; dump("21_akku_suche");
  base(); sleep_empty=true; spr.fillScreen(C_BG); { draw_sleep_screen(); FILE* f=fopen("out/22_akku_leer.raw","wb"); for(int y=0;y<240;y++) for(int x=0;x<240;x++){ uint32_t c=spr.readPixel(x,y); uint8_t rgb[3]={(uint8_t)(c>>11<<3),(uint8_t)((c>>5&63)<<2),(uint8_t)((c&31)<<3)}; fwrite(rgb,1,3,f);} fclose(f);} 
  // Logik Test battery_feed
  auto reset=[](){ battery_mv=0; battery_pct=-1; bat_win_min=100000; bat_win_max=0; bat_win_start=0; bat_unstable=true; bat_seen_ok=false; bat_low_warned=false; bat_empty_since=0; battery_empty=false; };
  uint32_t ms;
  reset(); ms=1000; for(int i=0;i<200;i++){ battery_feed(3900+(i%3)*10,ms); ms+=250; } printf("stabil 3.9V: pct=%d mv=%d empty=%d\n",battery_pct,battery_mv,(int)battery_empty);
  reset(); ms=1000; for(int i=0;i<200;i++){ battery_feed((i%4<2)?4200:3400,ms); ms+=250; } printf("springend (kein Akku): pct=%d empty=%d\n",battery_pct,(int)battery_empty);
  reset(); ms=1000; for(int i=0;i<200;i++){ battery_feed(150,ms); ms+=250; } printf("0V (kein Akku): pct=%d\n",battery_pct);
  reset(); ms=1000; for(int i=0;i<2000;i++){ battery_feed(3000,ms); ms+=250; } printf("stabil 3.0V seit Start: pct=%d empty=%d\n",battery_pct,(int)battery_empty);
  reset(); ms=1000; int mv=3700; int warned_at=-1; uint32_t empty_at=0; for(int i=0;i<4000 && !battery_empty;i++){ if(i%20==0 && mv>3200) mv-=5; battery_feed(mv,ms); if(bat_low_warned && warned_at<0) warned_at=mv; ms+=250; if(battery_empty) empty_at=ms; } printf("entladen: warnung bei %d mV, leer=%d bei %u ms, mv=%d\n",warned_at,(int)battery_empty,empty_at,battery_mv);
  printf("pct: 4200=%d 4000=%d 3800=%d 3700=%d 3600=%d 3400=%d\n",battery_percent(4200),battery_percent(4000),battery_percent(3800),battery_percent(3700),battery_percent(3600),battery_percent(3400));
  printf("done\n");
}

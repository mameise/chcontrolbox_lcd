from PIL import Image
import glob,os
files=sorted(glob.glob('out/*.raw')); ims=[]
for f in files:
    im=Image.frombytes('RGB',(240,240),open(f,'rb').read()); im.save(f.replace('.raw','.png')); ims.append(im)
cols=4; rows=(len(ims)+cols-1)//cols; S=2
sheet=Image.new('RGB',(cols*(240*S+20)+20,rows*(240*S+20)+20),(60,60,60))
for i,im in enumerate(ims):
    sheet.paste(im.resize((240*S,240*S),Image.NEAREST),(20+(i%cols)*(240*S+20),20+(i//cols)*(240*S+20)))
sheet.save('sheet.png'); h=sheet.size[1]//2
sheet.crop((0,0,sheet.size[0],h)).save('sheet_a.png'); sheet.crop((0,h,sheet.size[0],sheet.size[1])).save('sheet_b.png')

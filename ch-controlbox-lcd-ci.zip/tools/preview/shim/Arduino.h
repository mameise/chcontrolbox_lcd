// Minimaler Arduino Ersatz fuer die Vorschau auf dem PC
#pragma once
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
using std::min; using std::max;
#define PROGMEM
#define PI 3.14159265358979f
#define LOW 0
#define HIGH 1
#define INPUT_PULLUP 2
#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
extern uint32_t host_ms;
inline uint32_t millis_host(){ return host_ms; }
inline int digitalRead(int){ return HIGH; }
inline void pinMode(int,int){}
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(x) (void)(x)
#define portEXIT_CRITICAL(x) (void)(x)
struct Preferences { bool begin(const char*,bool){return true;} void end(){} int getInt(const char*,int d){return d;} void putInt(const char*,int){} };

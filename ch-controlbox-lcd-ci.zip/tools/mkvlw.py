#!/usr/bin/env python3
"""Erzeugt VLW Smooth Fonts (TFT_eSPI/LovyanGFX Format) als C-Header aus einer TTF/OTF Datei."""
import sys, struct
from PIL import Image, ImageDraw, ImageFont

def make(ttf, size, name, chars):
    font = ImageFont.truetype(ttf, size)
    ascent, descent = font.getmetrics()
    glyphs = []
    for ch in chars:
        cp = ord(ch)
        bbox = font.getbbox(ch, anchor="ls")  # relative zur Grundlinie
        adv = int(round(font.getlength(ch)))
        if bbox[2] <= bbox[0] or bbox[3] <= bbox[1]:
            glyphs.append((cp, 0, 0, adv, 0, 0, b""))
            continue
        w = bbox[2] - bbox[0]; h = bbox[3] - bbox[1]
        img = Image.new("L", (w, h), 0)
        ImageDraw.Draw(img).text((-bbox[0], -bbox[1]), ch, font=font, fill=255, anchor="ls")
        glyphs.append((cp, h, w, adv, -bbox[1], bbox[0], img.tobytes()))
    out = bytearray()
    out += struct.pack(">iiiiii", len(glyphs), 11, size, 0, ascent, descent)
    for cp, h, w, adv, top, left, _ in glyphs:
        out += struct.pack(">iiiiiii", cp, h, w, adv, top, left, 0)
    for g in glyphs:
        out += g[6]
    lines = [f"// Generiert aus {ttf.split('/')[-1]} ({size}px), SIL Open Font License", f"static const uint8_t {name}[] PROGMEM = {{"]
    for i in range(0, len(out), 24):
        lines.append("  " + ",".join(f"0x{b:02x}" for b in out[i:i+24]) + ",")
    lines.append("};")
    return "\n".join(lines) + "\n", len(out)

if __name__ == "__main__":
    base = "".join(chr(c) for c in range(0x20, 0x7f))
    latin = "".join(chr(c) for c in range(0xa0, 0x100))
    digits = "0123456789+-%.:/ "
    specs = [
        ("/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", 13, "FONT_S", base + latin),
        ("/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", 16, "FONT_M", base + latin),
        ("/usr/share/fonts/opentype/inter/Inter-Bold.otf", 22, "FONT_L", base + latin),
        ("/usr/share/fonts/opentype/inter/Inter-Bold.otf", 44, "FONT_XL", digits),
    ]
    hdr = ["// Schriften fuer die CH Control Box LCD. Inter (c) The Inter Project Authors, SIL Open Font License 1.1", "#pragma once", "#include <Arduino.h>", ""]
    total = 0
    for ttf, size, name, chars in specs:
        txt, n = make(ttf, size, name, chars); total += n
        hdr.append(txt)
    open(sys.argv[1], "w").write("\n".join(hdr))
    print("bytes", total)

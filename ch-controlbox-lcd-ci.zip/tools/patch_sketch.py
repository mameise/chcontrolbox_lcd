#!/usr/bin/env python3
"""Erzeugt CH_ControlBox_LCD.ino aus dem Original v1-6-0 Sketch.
Alle Aenderungen sind hier nachvollziehbar und laufen ueber den Schalter lcd_display_enabled."""
import sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding="utf-8", newline="").read().replace("\r\n", "\n")
s = "\n".join(l.rstrip() for l in s.split("\n"))  # Leerzeichen am Zeilenende entfernen

def rep(old, new, count=1):
    global s
    old = "\n".join(l.rstrip() for l in old.split("\n"))
    n = s.count(old)
    if n != count:
        raise SystemExit(f"Anker {n}x statt {count}x gefunden: {old[:80]!r}")
    s = s.replace(old, new)

# 1) Kopf: Version und Changelog
rep("""
CH_ControlBox_v1-6-0

Software Changelog:
""", """
CH_ControlBox_v1-6-0_LCD-1-1-2 (Waveshare ESP32-S3-LCD-1.3)

Software Changelog:
CH_ControlBox_v1-6-0_LCD-1-1-2: Button fix (09.10.2026, mameise)
1) Bugfix:      External CAL button that is closed at start (normally closed button or wrong wiring) is inverted, like the BOOT button.
                Before, the calibration started by itself and stayed in step 1 (switch: ext_cal_button_autodetect)
2) Feature:     Live state of all buttons on the info page and the calibration header turns green while CAL is pressed

CH_ControlBox_v1-6-0_LCD-1-1-1: Bluetooth fix (09.10.2026, mameise)
1) Bugfix:      With NimBLE-Arduino 2.x the box did not send its name while advertising. Phones did not list it.
                The name is now sent in the scan response (switch: bt_advertising_fix)
2) Bugfix:      After a disconnect the box advertises again, so the phone can reconnect without reset (switch: bt_advertising_fix)

CH_ControlBox_v1-6-0_LCD-1-1-0: Battery operation (09.10.2026, mameise)
1) Feature:     Battery symbol with charge in percent in the status bar, percent and voltage on the info page (switch: lcd_battery_display)
2) Feature:     Warning when the battery is low (10%), deep sleep when the battery is empty for one minute (switch: battery_low_sleep)
3) Feature:     Optional output rx_power_hw_pin for the EN pin of a 5V module: switches the receiver power off in deep sleep
4) Bugfix:      Battery voltage divider of the board is 100K/100K, factor 2.0 (was 3.0, voltage was shown too high)

CH_ControlBox_v1-6-0_LCD-1-0-0: Display edition for the Waveshare ESP32-S3-LCD-1.3 (08.10.2026, mameise)
1) Feature:     Support for the onboard 1.3" display (ST7789 240x240). See chapter 12 for all details.
                Drive view (steering wheel, throttle/brake, turbo, reverse, light, motor, launch control, menu),
                channel view (raw PWM values, calibration ranges, signal state) and info view
2) Feature:     Guided calibration on the display (step, short instruction, live values of all channels, save progress)
3) Feature:     Optional buttons: external CAL button (parallel to BOOT), NEXT button, OK button
4) Feature:     Settings menu on the display: brightness, screen off time, rotation, mirroring (prism case), language DE/EN,
                combos, combo speed, expo steering, expo throttle (combo/expo settings are stored like a calibration)
5) Feature:     Countdown on the display before deep sleep mode, sleep screen when entering deep sleep
6) Switch:      lcd_display_enabled 0 builds exactly the original behavior (same pins), see "ESP32 Pin Assignment"
7) Info:        The control logic (channels, combos, calibration, Bluetooth) is unchanged. The display runs in its own task on core 0.
8) Info:        USB controller mode is not possible on this board (USB is connected over a CH343 USB to UART chip)

""")

# 1b) Handbuch Kapitel 12
rep("""Have fun and good race.""", """12) Display edition (Waveshare ESP32-S3-LCD-1.3)
This edition uses the onboard 1.3" display. The control logic is the same as described in chapters 1 to 8.

12.1) Wiring (left pin header from top: 5V, GND, 3V3, IO1, IO2, IO3, IO4, IO5 | right pin header from top: IO14 ... IO8, IO7)
5V  -> + of the RC receiver (only powered when the board is supplied over USB, not from the battery)
GND -> - of the RC receiver
IO4 -> Steering signal | IO3 -> Throttle/Brake signal | IO1 -> Turbo signal | IO2 -> Reverse signal
Optional buttons to GND (no resistor needed): IO5 = CAL (same as BOOT), IO7 = NEXT, IO8 = OK

12.2) Buttons
CAL/BOOT: as described in chapter 5 (the display shows each step, a short instruction and the live values of all channels)
NEXT short: next page (Drive, Channels, Info) | NEXT long: display off | In the menu: NEXT short = next item, NEXT long = previous item
OK short: open the settings menu / change the selected value | OK long: close the menu

12.3) Settings menu
Brightness, screen off time, rotation, mirroring (for the prism case), language (German/English),
combos (same as chapter 5.7.1), combo speed (same as chapter 5.6.4), expo steering and expo throttle (same as chapter 5.7.0).
Combo and expo settings are stored permanently like at the end of a calibration. The menu is blocked during the calibration.

12.4) Switch
"lcd_display_enabled 0" in the section "Display edition" below the pin assignment builds exactly the original behavior with the same pins.

12.5) Battery operation
The 5V pin of the board is connected directly to USB VBUS. It has no power from the battery.
For battery operation: 1S LiPo -> on/off switch -> battery plug of the board (MX1.25, check the polarity!) and in parallel to a 5V step up module.
The 5V module supplies the RC receiver (+ and -). The 5V pin of the board stays free. All GND are connected.
The board has no on/off switch. Charging over the USB-C of the board works only while the switch is on.
"lcd_battery_display 0" hides the battery symbol. "battery_low_sleep 0" disables the deep sleep at empty battery.
"rx_power_hw_pin": optional GPIO to the EN pin of the 5V module (if it has one). High while running, low in deep sleep.

12.6) Bluetooth
With NimBLE-Arduino 2.x the box did not send its name and did not advertise again after a disconnect.
"bt_advertising_fix 1" (default) fixes both. The phone shows the box as "CH Control Box <ID>".

Have fun and good race.""")

# 2) Pin Zuordnung
rep("""#define steering_hw_pin 4//Digital Board Pin connected to the analog steering channel of the RC receiver
#define throttle_brake_hw_pin 3//Digital Board Pin connected to the analog throttle/brake channel of the RC receiver
#define turbo_hw_pin 1//Digital Board Pin connected to the digital channel used for turbo. Can be a butto nor switch of the RC receiver (can also be physically unconnected)
#define reverse_hw_pin 2//Digital Board Pin connected to the digital channel used for reverse setting. Can be a button or switch of the RC receiver (can also be physically unconnected)
#define status_led_hw_pin 21//Digital Board Pin of Onboard LED (Called LED in the documentation) -> A negative Value will invert the LED!
#define internal_boot_button_hw_pin 0//Digital Board Pin of Onboard boot button (Called CAL_BUTTON in the documentation)

#define internal_led_is_rgb_led 1//If the internal LED is a RGB LED, set this to 1 to get the LED working. Otherwise set to 0!
#define use_usb_controler_support 1//""",
"""//[TESTED] Waveshare ESP32-S3-LCD-1.3 (Display edition, see chapter 12) (5V, GND, GPIO1, GPIO2, GPIO3, GPIO4 on the pin header) --> steering_hw_pin->4 | throttle_brake_hw_pin->3 | turbo_hw_pin->1 | reverse_hw_pin->2 | status_led_hw_pin->15 | internal_boot_button_hw_pin->0 | internal_led_is_rgb_led->1 | use_usb_controler_support->0 --> In Arduino use "ESP32S3 Dev Module" board, Flash Size 16MB, PSRAM "OPI PSRAM"
#define steering_hw_pin 4//Digital Board Pin connected to the analog steering channel of the RC receiver
#define throttle_brake_hw_pin 3//Digital Board Pin connected to the analog throttle/brake channel of the RC receiver
#define turbo_hw_pin 1//Digital Board Pin connected to the digital channel used for turbo. Can be a butto nor switch of the RC receiver (can also be physically unconnected)
#define reverse_hw_pin 2//Digital Board Pin connected to the digital channel used for reverse setting. Can be a button or switch of the RC receiver (can also be physically unconnected)
#define status_led_hw_pin 15//Digital Board Pin of Onboard LED (Called LED in the documentation) -> A negative Value will invert the LED! (Waveshare ESP32-S3-LCD-1.3: RGB LED on GPIO15)
#define internal_boot_button_hw_pin 0//Digital Board Pin of Onboard boot button (Called CAL_BUTTON in the documentation)

#define internal_led_is_rgb_led 1//If the internal LED is a RGB LED, set this to 1 to get the LED working. Otherwise set to 0!
#define use_usb_controler_support 0//NOT POSSIBLE on the Waveshare ESP32-S3-LCD-1.3 (USB goes over a CH343 chip). Original description: """)

rep("""

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Needed libraries to be included at first in the Code (See above links for downloading!!)""",
"""
#define bt_advertising_fix 1//1=Send the Bluetooth name while advertising and advertise again after a disconnect (needed with NimBLE-Arduino 2.x). 0=Original behavior

//------------- Display edition (Waveshare ESP32-S3-LCD-1.3) ------------- --> See chapter 12
#ifndef lcd_display_enabled
#define lcd_display_enabled 1//1=Display, menu and additional buttons are active. 0=Exactly the original behavior (display stays dark)
#endif
#define ext_cal_button_hw_pin 5//Optional external CAL button (to GND), works in parallel to the BOOT button. -1=not used
#define ext_cal_button_autodetect 1//1=If the external CAL button is closed at start, it is inverted (normally closed button or wrong wiring). 0=off
#define btn_next_hw_pin 7//Optional button NEXT (to GND): next page / next menu item. -1=not used
#define btn_ok_hw_pin 8//Optional button OK (to GND): open menu / change value. -1=not used
#define battery_adc_hw_pin 6//Battery voltage measurement of the board (fixed on the board)
#define battery_divider_factor 2.0//Voltage divider of the battery measurement (board: 100K/100K)
#define lcd_battery_display 1//1=Battery symbol with percent in the status bar and warning when low. 0=off
#define battery_low_sleep 1//1=Deep sleep when the battery is empty (protects the battery). 0=off
#define rx_power_hw_pin -1//Optional: GPIO to the EN pin of the 5V module of the receiver. High while running, low in deep sleep. -1=not used



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Needed libraries to be included at first in the Code (See above links for downloading!!)""")

rep("""#include <Preferences.h>//Don't change anything here
""", """#include <Preferences.h>//Don't change anything here
#if lcd_display_enabled
#include "lcd_ui.h"//Display edition. Needs the library LovyanGFX (v1.1.16 tested)
#endif
""")

# 3) RcReceiverReader: Signal-Zeitstempel und Zugriffe fuer das Display
rep("""        valid_delta_time=delta_time;//Store new valid delta time
""", """        valid_delta_time=delta_time;//Store new valid delta time
        last_valid_ms=millis();//Display edition: time of the last valid pulse
""")
rep("""    unsigned long valid_delta_time_last=0;//Last valid delta time which was processed""",
"""    volatile unsigned long last_valid_ms=0;//Display edition: time of the last valid pulse (set in the interrupt routine)
    unsigned long valid_delta_time_last=0;//Last valid delta time which was processed""")
rep("""    bool get_channel_connected_once()//Get the information, if the channel is connected and received a valid value""",
"""    bool get_signal_ok()//Display edition: true, if valid pulses arrived within the last 300 ms
    {return valid_delta_time>0 && (millis()-last_valid_ms)<300;}

    int get_cal_short_presses()//Display edition: number of short CAL presses in the last calibration step
    {return erase_esp32_counter;}

    void save_settings()//Display edition: store the actual settings of this channel permanently (same as at the end of the calibration)
    {write_esp32_pref();}

    bool get_channel_connected_once()//Get the information, if the channel is connected and received a valid value""")

# 4) setup(): externe CAL Taste und Display starten
rep("""  esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);//Disable all wakeup sources
""", """  esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);//Disable all wakeup sources

  #if lcd_display_enabled
  if(ext_cal_button_hw_pin>=0) {pinMode(ext_cal_button_hw_pin,INPUT_PULLUP);}//Optional external CAL button
  if(rx_power_hw_pin>=0) {gpio_hold_dis((gpio_num_t)rx_power_hw_pin);pinMode(rx_power_hw_pin,OUTPUT);digitalWrite(rx_power_hw_pin,HIGH);}//Optional: switch on the 5V module of the receiver
  {
    const int lcd_pins[4]={steering_hw_pin,throttle_brake_hw_pin,turbo_hw_pin,reverse_hw_pin};
    lcd_begin(compositeHID.deviceName.c_str(),"v1-6-0 " LCD_UI_VERSION,lcd_pins,btn_next_hw_pin,btn_ok_hw_pin,ext_cal_button_hw_pin);
  }
  #else
  pinMode(20,OUTPUT);digitalWrite(20,LOW);//Waveshare ESP32-S3-LCD-1.3: keep the display backlight off, if the display is not used
  #endif
""")

# 5) loop(): externe CAL Taste
rep("""  if(invert_pcb_boot_button)//In case invert the button state, if necesarry
  {PCB_button_state=!PCB_button_state;}
""", """  if(invert_pcb_boot_button)//In case invert the button state, if necesarry
  {PCB_button_state=!PCB_button_state;}
  #if bt_advertising_fix
  bt_advertising_fix_check();//Bluetooth name in the advertising and advertising after a disconnect
  #endif
  #if lcd_display_enabled
  static bool ext_cal_inverted=false;
  #if ext_cal_button_autodetect
  if(first_loop_active && ext_cal_button_hw_pin>=0 && digitalRead(ext_cal_button_hw_pin)==LOW)//External CAL button closed at start: invert it, otherwise the calibration would start by itself and never go on
  {ext_cal_inverted=true;}
  #endif
  bool boot_button_pressed=PCB_button_state;//Only BOOT, for the display
  bool ext_cal_pressed=(ext_cal_button_hw_pin>=0) && ((digitalRead(ext_cal_button_hw_pin)==LOW)!=ext_cal_inverted);
  if(ext_cal_pressed)//Optional external CAL button (to GND) works like the BOOT button
  {PCB_button_state=true;}
  #endif
""")

# 6) loop(): Display vor dem Tiefschlaf, Daten an das Display
rep("""  if(sleep_timer.get_output())//Going to deepsleep mode after a long time without input (Wakup will be performed by pressing EN Button again, or repower on the ESP Board)
  {esp_deep_sleep_start();}
""", """  #if lcd_display_enabled
  lcd_loop_update(PCB_button_state,old_physical_reverse_condition,turbo_condition,use_combined_turbo_reverse_channel,receiver_was_never_connected,time_until_sleep,boot_button_pressed,ext_cal_pressed,ext_cal_inverted);
  if(sleep_timer.get_output() || lcd_battery_empty())//Display edition: show the sleep screen and switch off display, LED and receiver power before the deep sleep
  {
    lcd_enter_sleep(lcd_battery_empty());
    if(internal_led_is_rgb_led==1) {rgbLedWrite(abs(status_led_hw_pin),0,0,0);} else {digitalWrite(abs(status_led_hw_pin),status_led_hw_pin<0);}
    pinMode(LCD_PIN_BL,OUTPUT);digitalWrite(LCD_PIN_BL,LOW);gpio_hold_en((gpio_num_t)LCD_PIN_BL);
    if(rx_power_hw_pin>=0) {digitalWrite(rx_power_hw_pin,LOW);gpio_hold_en((gpio_num_t)rx_power_hw_pin);}
    gpio_deep_sleep_hold_en();
    esp_deep_sleep_start();
  }
  #endif
  if(sleep_timer.get_output())//Going to deepsleep mode after a long time without input (Wakup will be performed by pressing EN Button again, or repower on the ESP Board)
  {esp_deep_sleep_start();}
""")

# 7) Hilfsfunktion am Ende anhaengen
s = s.rstrip() + """



//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//------------------ Display edition: collect the data for the display and apply settings from the display menu ------------------
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#if bt_advertising_fix
#include <NimBLEDevice.h>
//The Bluetooth server is started by the library in its own task. As soon as it runs, add the name and enable advertising after a disconnect
void bt_advertising_fix_check()
{
  static bool server_done=false;
  static bool name_done=false;
  if(server_done && name_done) {return;}
  if(!NimBLEDevice::isInitialized()) {return;}
  NimBLEServer* server=NimBLEDevice::getServer();
  if(server==nullptr) {return;}
  if(!server_done) {server->advertiseOnDisconnect(true);server_done=true;}
  NimBLEAdvertising* adv=NimBLEDevice::getAdvertising();
  if(adv==nullptr) {return;}
  if(adv->isAdvertising())//Library has started the advertising: restart it with the name in the scan response
  {
    adv->stop();
    adv->enableScanResponse(true);
    adv->setName(compositeHID.deviceName);
    adv->start();
    name_done=true;
  }
  else if(compositeHID.isConnected())//Already connected: only prepare the name for the next advertising
  {
    adv->enableScanResponse(true);
    adv->setName(compositeHID.deviceName);
    name_done=true;
  }
}
#endif

#if lcd_display_enabled
void lcd_fill_channel(LcdChannel& c, RcReceiverReader& ir)
{
  c.active=ir.get_channel_is_active();
  c.signal=ir.get_signal_ok();
  c.raw=ir.get_delta_time();
  c.pre=ir.get_prescaled_value();
  c.steps=ir.get_output_discretize_steps();
  c.cal_min=ir.get_cal_delta_min_time();
  c.cal_max=ir.get_cal_delta_max_time();
  c.neu_min=ir.get_cal_neutral_min_time();
  c.neu_max=ir.get_cal_neutral_max_time();
  c.toggle_btn=ir.get_discrete_button_is_toogle_button();
  c.expo=ir.get_channel_exp_factor();
}

void lcd_loop_update(bool cal_button, bool reverse_hold, bool turbo, bool combined_tr, bool receiver_never_connected, unsigned long time_until_sleep, bool boot_pressed, bool ext_cal_pressed, bool ext_cal_inverted)
{
  static LcdTele tele;
  static unsigned long cal_press_start=0;
  static bool cal_button_last=false;
  static bool bt_last=false;
  static unsigned long last_publish=0;
  unsigned long now=millis();

  //Remember the last activity (wakes up the display)
  bool bt=compositeHID.isConnected();
  if(ir1.get_prescaled_value_delta()!=0 || ir2.get_prescaled_value_delta()!=0 || ir3.get_prescaled_value_delta()!=0 || ir4.get_prescaled_value_delta()!=0 || cal_button!=cal_button_last || bt!=bt_last)
  {tele.activity_ms=now;}
  if(cal_button && !cal_button_last) {cal_press_start=now;}
  cal_button_last=cal_button;
  bt_last=bt;

  //Apply settings changed in the display menu (never during the calibration)
  int sid; long sval;
  if(lcd_take_setting(sid,sval) && ir1.get_cal_step()==0)
  {
    if(sid==LCD_SET_COMBOS) {ir1.set_use_combos(sval);ir1.save_settings();}
    else if(sid==LCD_SET_SPEED) {ir2.set_additional_channel_option(sval);ir2.save_settings();}
    else if(sid==LCD_SET_EXPO_STEER) {ir1.set_channel_exp_factor(sval);ir1.save_settings();}
    else if(sid==LCD_SET_EXPO_THROTTLE) {ir2.set_channel_exp_factor(sval);ir2.save_settings();}
  }

  //Publish not more often than every 15 ms, except for short reverse pulses
  if(now-last_publish<15 && !reverse_press_timer.get_output()) {return;}
  last_publish=now;

  tele.ms=now;
  tele.bt_connected=bt;
  tele.rx_seen=!receiver_never_connected;
  lcd_fill_channel(tele.ch[0],ir1);
  lcd_fill_channel(tele.ch[1],ir2);
  lcd_fill_channel(tele.ch[2],ir3);
  lcd_fill_channel(tele.ch[3],ir4);
  tele.cal_step_ext=ir1.get_cal_step_external();
  tele.cal_presses=ir1.get_cal_short_presses();
  tele.cal_btn=cal_button;
  tele.btn_boot=boot_pressed;
  tele.btn_cal=ext_cal_pressed;
  tele.btn_cal_inverted=ext_cal_inverted;
  tele.cal_hold_ms=cal_button ? (now-cal_press_start) : 0;
  tele.turbo=turbo;
  tele.reverse_pulse=reverse_press_timer.get_output();
  tele.reverse_hold=reverse_hold;
  tele.c_launch=combo_launch_control.get_output();
  tele.c_light=combo_light.get_output();
  tele.c_motor=combo_motorstart.get_output();
  tele.c_menu=combo_menue.get_output();
  tele.c_turbo=combo_turbo.get_output();
  tele.c_reverse=combo_reverse.get_output();
  tele.use_combos=ir1.get_use_combos();
  tele.combo_speed=ir2.get_additional_channel_option();
  tele.combined_tr=combined_tr;
  if(time_until_sleep>0 && sleep_timer.get_running())
  {tele.sleep_left_ms=(time_until_sleep>(unsigned long)sleep_timer.get_et()) ? (time_until_sleep-sleep_timer.get_et()) : 0;}
  else
  {tele.sleep_left_ms=0;}
  lcd_publish(tele);
}
#endif
//-------------------------------------------------------------------
"""

open(dst, "w", encoding="utf-8", newline="\r\n").write(s)
print("ok", len(s))
